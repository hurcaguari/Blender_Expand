这是一个小工具整合的blender插件项目
我想要做一些实用的极简小功能加入到这个插件中
所有功能都简化到仅需要一个按钮即可实现所需功能
暂时仅存在两个小功能
欢迎有人提出小功能的提议
# 现存的两个小功能
# 1.全自动的全摄像机批量渲染(仅渲染启用渲染开关的摄像机)
# 2.全自动的可视几何到网格这将处理场景内所有可选对象包括链接几何体和实例对象
This is a blender plugin project that integrates with a widget
I'd like to make some useful minimalist little features to add to this plugin
All functions are simplified to just one button to achieve the desired function
For the time being, there are only two small features
Proposals for small features are welcome
# There are two small functions that exist
# 1.Fully automatic full-camera batch rendering (only render cameras with render switch enabled)
# 2.Fully automatic visual geometry to mesh: This will handle all optional objects in the scene, including linked geometry and instance objects
