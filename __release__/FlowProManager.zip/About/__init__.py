import bpy
import os
from .. import Icons
from ..Utils.IconUtils import header

class FLOW_Basic_AboutPanel(bpy.types.Panel):
    bl_idname = 'FLOWBASIC_PT_About'
    bl_label = 'About'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Flow"
    bl_context = "objectmode"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        header(self, context, preview_collections)

    def draw(self, context):
        layout = self.layout
        pcoll = preview_collections['main']
        
        col = layout.column()
        row = col.row(align=True)
        row.scale_y = 2.0
        flow_logo = pcoll['flow_logo']
        row.label(text='Flow4 Pro', icon_value=flow_logo.icon_id)
        row = col.row(align=True)
        row.label(text='Workflow Tool for Blender 4.0+')

        row = col.row(align=True)
        row.label(text='v.4.1.0')
        row.label(text='June 2024')

        row = col.row()
        psp_logo = pcoll['psp_logo']
        row.label(text='created by polyspaace', icon_value=psp_logo.icon_id)

        col = layout.column(align=True)

        row = col.row(align=True)
        row.scale_y = 2.0
        yt_logo = pcoll['yt_logo']
        op = row.operator('wm.url_open', text='Youtube', icon_value=yt_logo.icon_id)
        op.url = 'https://www.youtube.com/channel/UCty_0CZWrfHLHJs9_zedE-Q'
        row = col.row(align=True)
        row.scale_y = 1.5
        op = row.operator('wm.url_open', text='Documentation', icon='HELP')
        op.url = 'https://3d.polyspaace.com/products/flow/docs/'
        op = row.operator('wm.url_open', text='Tutorials & News', icon='MONKEY')
        op.url = 'https://blog.polyspaace.com/'

preview_collections = {}

def register():
    
    import bpy.utils.previews
    pcoll = bpy.utils.previews.new()
    icons_dir = os.path.dirname(Icons.__file__)
    pcoll.load('flow_logo', os.path.join(icons_dir, "flow_logo.png"), 'IMAGE')
    pcoll.load('yt_logo', os.path.join(icons_dir, "yt_logo.png"), 'IMAGE')
    pcoll.load('psp_logo', os.path.join(icons_dir, "ps_favicon.png"), 'IMAGE')
    preview_collections['main'] = pcoll

    bpy.utils.register_class(FLOW_Basic_AboutPanel)

def unregister():

    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)

    preview_collections.clear()

    bpy.utils.unregister_class(FLOW_Basic_AboutPanel)
