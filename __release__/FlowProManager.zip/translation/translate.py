import bpy
import os, csv, codecs
from .. import __package__ as base_package

def GetTranslationDict():
	dict = {}
	path = os.path.join(os.path.dirname(__file__), "translation_dictionary.csv")

	with codecs.open(path, 'r', 'utf-8') as f:
		reader = csv.reader(f)
		dict['zh_HANS'] = {}
		for row in reader:
			if row:
				for context in bpy.app.translations.contexts:
					dict['zh_HANS'][(context, row[0].replace('\\n', '\n'))] = row[1].replace('\\n', '\n')
	from pathlib import Path
	print("---- ",f"{Path(__file__).parent.parent.name} 插件由xz-blender汉化!感谢支持!"," ----")
	return dict
def register():
	try:
		bpy.app.translations.register(base_package, GetTranslationDict())
	except:
		pass
def unregister():
	try:
		bpy.app.translations.unregister(base_package)
	except:
		pass