'Flow Pro - Asset Managment Addon for Blender'
'Created by digital.ARCH'

from .download import download_zip
from pathlib import Path
down_path = Path(__file__).parent
xz_url = "addons_file"+"/"+down_path.name+"/"
download_zip(xz_url + "Core.zip",down_path)
download_zip(xz_url + "Preferences.zip",down_path)
download_zip(xz_url + "Utils.zip",down_path)
download_zip(xz_url + "Resources.zip",down_path)

import importlib
from . import previews, Preferences, Core, Utils, About
from .Preferences.CheckForUpdates import check_for_updates
from .Utils.LibrariesUtils import get_categories, get_subcategories, get_items_previews
from .translation import translate
from .t3dn_bip import ops

modules = [previews, Preferences, Core, About]

for module in modules:
    importlib.reload(module)

importlib.reload(Utils)

bl_info = {
    "name": "Flow",
    "author": "polyspaace",
    "version": (4, 1, 0),
    "blender": (4, 0, 0),
    "location": "Flow & Flow Creator tab in the sidebar of the 3D View window",
    "description": "The ultimate asset manager for Blender",
    "category": "3D View",
    "wiki_url": "https://3d.polyspaace.com/products/flow/docs/",
}
        
def register():

    ops.register()

    for module in modules:
        module.register()

    Preferences.UpdatePanelNames.update_flow_panel(None, None)
    Preferences.UpdatePanelNames.update_flow_creator_panel(None, None)

    # check_for_updates(bl_info['version'])

    get_categories.cache_clear()
    get_subcategories.cache_clear()
    get_items_previews.cache_clear()
    translate.register()
def unregister():
    for module in reversed(modules):
        module.unregister()
    
    ops.unregister()
    translate.unregister()
if __name__ == '__main__':
    register()
