import bpy
from .utils import install_pillow

class FLOW_Free_InstallPillow(bpy.types.Operator):
    bl_label = 'Install Pillow'
    bl_description = '.\n'.join((
        'Install the Python Imaging Library',
        'This could take a few minutes',
    ))
    bl_idname = 'file.flow_t3dn_install_pillow'
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context) -> set:
        if install_pillow():
            self.report({'INFO'}, 'Successfully installed Pillow')
        else:
            self.report({'WARNING'}, 'Failed to install Pillow')

        return {'FINISHED'}

def register():
    bpy.utils.register_class(FLOW_Free_InstallPillow)
def unregister():
    bpy.utils.unregister_class(FLOW_Free_InstallPillow)
