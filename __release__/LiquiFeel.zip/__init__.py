from . import download
download.downloading()

bl_info = {
    "name" : "Liquifeel",
    "author" : "BlenderMight",
    "description" : "Fill recipient models with liquid.",
    "blender" : (4, 1, 0),
    "version" : (1, 1),
    "location" : "View3D > UI",
    "warning" : "",
    "category" : "Interface",
}

import bpy
import mathutils
# from mathutils import Vector

import os
import shutil
import pathlib
import json
import webbrowser
import functools as ft
import sys
import subprocess

from copy import deepcopy
from pprint import pprint
from . import translate
from .third_party.t3dn_bip import previews

import importlib

from bpy.app.handlers import persistent

# import properties
# importlib.reload(properties)

registerable_classes = []

## MISC FUNCTIONS --------------------------------------------------------------------------------

def key_from_name(name):
    return name.replace(' ', '_').lower().replace(';', '_').replace('/', '_').replace('.', '_')

def name_from_fname(fname):
    return '.'.join(fname.split('.')[:-1])

def name_from_key(key):
    return ' '.join(
        map(lambda elem: elem.capitalize(),
            key.split('_')))

def class_name_from_key(key):
    return ''.join(
        map(lambda elem: elem.capitalize(),
            key.split('_')))

def bl_version_lesser(v1, v2):
    if v1[0] > v2[0]:
        return False
    elif v1[1] > v2[1]:
        return False
    else:
        return v1[2] < v2[2]

def bl_version_greater(v1, v2):
    if v1[0] < v2[0]:
        return False
    elif v1[1] < v2[1]:
        return False
    else:
        return v1[2] > v2[2]

def strip_name(name):
    elems = name.split(' ')
    return ' '.join(
        filter(lambda elem: elem != '', elems)
    )

# This generates a dictionary with correlates stripped keys with unstripped keys.
# it is useful for aiding in the access to data refferenced by keys with accidentally
# included leading or trailing whitespace
def stripped_correlator(data):
    corr = {}
    for key in data.keys():
        corr[strip_name(key)] = key
    return corr

# Read the comment to the function defined above.
def index_stripped(data, key):
    corr = stripped_correlator(data)
    return data[corr[strip_name(key)]]

def does_dict_have_key_path(data, key_path):
    if len(key_path) == 1:
        return key_path[0] in data.keys()
    elif key_path[0] in data.keys():
        return does_dict_have_key_path(data[key_path[0]], key_path[1:])
    else:
        return False
        
## JSON  -------------

def parse_json_string(json_string):
    data = json.loads(json_string)
    return data

## WEB -------------

def make_single_user_and_apply_transforms(context, obj__):
    select_and_set_active(context, obj__, deselect_all=True)
    bpy.ops.object.make_single_user(object=True, obdata=True, material=True)
    # Apparently we don't have to apply the rotation
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

## WEB -------------

def open_webpage(url):
    webbrowser.open(url)

## PIP -----------------

def upgrade_pip():
    try:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'], check=True)
        print(f"pip upgraded successfully.")
    except subprocess.CalledProcessError:
        print(f"Failed to upgrade pip. Please do it manually.")

def install_package(package_name):
    """
    Attempts to install a package using pip and sys.executable to ensure
    compatibility across Windows, Linux, and macOS.
    """
    try:
        subprocess.run([sys.executable, '-m', 'pip', 'install', package_name], check=True)
        print(f"{package_name} installed successfully.")
    except subprocess.CalledProcessError:
        print(f"Failed to install {package_name}. Please install it manually.")

def check_and_install_package(package_name, package_import_name=None):
    try:
        # Attempt to import the package
        if package_import_name:
            __import__(package_import_name)
        else:
            __import__(package_name)
        print(f"{package_name} is already installed.")
    except ImportError:
        # The package is not installed; attempt to install
        upgrade_pip()
        print(f"{package_name} is not installed. Attempting to install...")
        install_package(package_name)

# def install_python_package(package_name):
#     import pip._internal
#     pip._internal.main(['install', package_name])

# def remove_python_package(package_name):
#     import pip._internal
#     pip._internal.main(['remove', package_name])

# remove_python_package('pillow')

# # List installed
# subprocess.run([sys.executable, '-m', 'pip', 'list'], check=True)
# # Uninstall
# subprocess.run([sys.executable, '-m', 'pip', 'uninstall', 'pillow'], check=True)

check_and_install_package('Pillow', package_import_name='PIL')

## BLENDER -------------

def undo_push(n):
    if n == 1:
        def decorator(f):
            def wrapper(arg):
                bpy.ops.ed.undo_push()
                return f(arg)
            return wrapper
        return decorator
    if n == 2:
        def decorator(f):
            def wrapper(instance, context):
                bpy.ops.ed.undo_push()
                return f(instance, context)
            return wrapper
        return decorator
    elif n == 3:
        def decorator(f):
            def wrapper(a, b, c):
                bpy.ops.ed.undo_push()
                return f(a, b, c)
            return wrapper
        return decorator
    elif n == 4:
        def decorator(f):
            def wrapper(a, b, c, d):
                bpy.ops.ed.undo_push()
                return f(a, b, c, d)
            return wrapper
        return decorator

# def undo_push(f):
#     def wrapper(instance, context):
#         bpy.ops.ed.undo_push()
#         return f(instance, context)
#     return wrapper

@undo_push(1)
def unused_data_purge(context):
    bpy.ops.outliner.orphans_purge(
        do_local_ids=True, do_linked_ids=True, do_recursive=True)

def is_active_selected_ob(context):
    ob = context.active_object
    if ob:
        return ob.select_get()
    return False        

def deselect_all_objects(context):
    for ob in context.selected_objects:
        ob.select_set(False)

def select_and_set_active(context, ob, deselect_all=False):
    if deselect_all:
        deselect_all_objects(context)
    context.view_layer.objects.active = ob
    ob.select_set(True)

heavy_render_bounce_params = {
    'max_bounces': 24,
    'transmission_bounces': 24,
    'volume_bounces': 2
}

light_render_bounce_params = {
    'max_bounces': 8,
    'transmission_bounces': 8,
    'volume_bounces': 0
}

def adjust_render_settings(context, light=False):
    if light:
        params = light_render_bounce_params
        for key, val in params.items():
            if getattr(context.scene.cycles, key) > val:
                setattr(context.scene.cycles, key, val)
    else:
        params = heavy_render_bounce_params
        for key, val in params.items():
            if getattr(context.scene.cycles, key) < val:
                setattr(context.scene.cycles, key, val)

## RNA SYSTEM -------

def getattr_rec(obj__, attr_key_path):
    try:
        return ft.reduce(getattr, attr_key_path, obj__)
    except:
        return None

# obsolet, old system, now we use REDUX_INPUT_DATA and it has a
# different hierarchy.
def getattr_rec__by_names(
        obj__, shading_modality_key, library_key, mat_name, target_type, group_name, input_name, prop_key=None):
    lib_key, mat_key, trgt_key, group_key, prop_key__ = map(
        key_from_name,
        [library_key, mat_name, target_type, group_name, input_name])
    if not(prop_key):
        prop_key = prop_key__
    prop_key_chain = [
        f'liquifeel_field_inputs',
        f'{shading_modality_key}_shading',
        f'{lib_key}_inputs',
        f'{mat_key}',
        f'{trgt_key}',
        f'{group_key}',
        f'{prop_key}',
    ]
    return getattr_rec(obj__, prop_key_chain)

# CONCESSION START --------------------------------------------------
# We refference hierarchically placed properties by recursing up the path.

def ref_ob_key_pair_rec__(obj__, key_chain):
    if len(key_chain) == 1:
        return obj__, key_chain[-1]
    else:
        key = key_chain.pop()
        return ref_ob_key_pair_rec__(
            getattr(obj__, key),
            key_chain)

def ref_ob_key_pair(obj__, key_chain):
    key_chain__ = key_chain.copy()
    key_chain__.reverse()
    return ref_ob_key_pair_rec__(obj__, key_chain__)

def ref_input_field_property(
        obj__, shading_modality_key, library_key, mat_name, target_type, group_name, input_name, prop_key=None):
    lib_key, mat_key, trgt_key, group_key, prop_key__ = map(
        key_from_name,
        [library_key, mat_name, target_type, group_name, input_name])
    if not(prop_key):
        prop_key = prop_key__
    prop_key_chain = [
        f'liquifeel_field_inputs',
        f'{shading_modality_key}_shading',
        f'{lib_key}_inputs',
        f'{mat_key}',
        f'{trgt_key}',
        f'{group_key}',
        f'{prop_key}',
    ]
    return ref_ob_key_pair(obj__, prop_key_chain)

# CONCESSION STOP --------------------------------------------------

def load_image(path):
    im = bpy.data.images.load(str(path))
    return im

def maybe_load_image(path):
    fname = path.name
    if fname in bpy.data.images.keys():
        return bpy.data.images[fname]
    else:
        im = bpy.data.images.load(str(path))
        return im

## MESH ISLAND COUNT ---

def get_vert_graph(verts, edges):
    # Initialize the path with all vertices indices
    graph = {v.index: set() for v in verts}
    # Add the possible paths via edges
    for e in edges:
        graph[e.vertices[0]].add(e.vertices[1])
        graph[e.vertices[1]].add(e.vertices[0])
    return graph

def follow_edges(starting_index, paths):
    current_selected_vert_indices = [starting_index]
    follow = True
    while follow:
        # Get indices that are still in the paths
        eligible = set([ind for ind in current_selected_vert_indices if ind in paths])
        if len(eligible) == 0:
            follow = False # Stops if no more
        else:
            # Get the corresponding links
            next = [paths[i] for i in eligible]
            # Remove the previous from the paths
            for key in eligible: paths.pop( key )
            # Get the new links as new inputs
            current_selected_vert_indices = set([ind for sub in next for ind in sub])

def count_mesh_islands(obj__):
    # Prepare the paths/links from each vertex to others
    graph = get_vert_graph(obj__.data.vertices, obj__.data.edges)
    found = True
    n = 0
    while found:
        try:
            # Get one input as long there is one
            starting_index = next(iter(graph.keys() ) )
            n = n + 1
            # Deplete the graph dictionary following this starting index
            follow_edges(starting_index, graph)               
        except:
            found = False
    return n

## CONSTANT DATA --------------------------------------------------------------------------------

## SIMPLE -----------------------------

DEV = False
if DEV:
    debug_buffer = []

SPACING_H = 0.4
SML_H = 1.2
MID_H = 1.8
LRG_H = 2.4

SELECT_OUTER_NG_NAME = 'LiquiFeel_Select Outer'
# FILL_NG_NAME = 'LiquiFeelv1.2'
FILL_NG_NAME = 'LiquiFeelv1.3'
HIDE_RECIPIENT_NG_NAME = 'Hide_Recipient'
DROPLET_GEN_NG_NAME  = 'DropletGen'

UI_THUMB_SCALE = 13.2 * 0.75
POPUP_THUMB_SCALE = 13.2 / 2

LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR = 0.6

## COMPOUND -----------------------------

LQFL_OBJECT_TAG_ATTACHED_DATA_KEYS = [
    'liquifeel',
]

PATTERN_RES_KEYS = ['256', '512', '1k', '2k']

image_file_extensions = ['png', 'jpg']

## DYNAMIC -----------------------------

## MAIN TABS ----------

# MAIN_TAB_KEYS = ['fill', 'shading', 'condensation']
# MAIN_TAB_KEYS = ['geometry', 'shading', 'effects', 'recipients']
MAIN_TAB_KEYS = ['geometry', 'shading', 'recipients']
MAIN_TAB_NAMES = {key: key.capitalize() for key in MAIN_TAB_KEYS}
MAIN_TAB_NAMES['recipients'] = 'Recipients'
MAIN_TAB_BUILTIN_ICONS = {
    'shading': 'MATERIAL',
}

## FILEPATH ----------

def has_extension(fname, extension):
    return get_extension(fname).lower() == extension

def has_image_extension(fname):
    return any(
        map(lambda ext: has_extension(fname, ext),
            image_file_extensions))

def get_fname_with_name(patterns_folderpath, img_name, extension=None, img_extension=False):
    fnames = filter(lambda fname: name_from_fname(fname) == img_name,
                    os.listdir(patterns_folderpath))
    if extension:
        return next(filter(lambda fname: has_extension(fname, extension),
                           fnames))
    elif img_extension:
        return next(filter(has_image_extension,fnames))
    else:
        return next(fnames)

## PATH DATA ---

def assemble_flat_path_data(root_path, gen_key=True):
    path_data = {}
    if gen_key:
        for fname in os.listdir(root_path):
            key = key_from_name(name_from_fname(fname))
            path_data[key] = root_path / fname
    else:
        for fname in os.listdir(root_path):
            key = name_from_fname(fname)
            path_data[key] = root_path / fname
    return path_data

# two layer deep data structure (flat sub-dictionaries)
# {K:{K:V}}
def assemble_recipient_pattern_path_data(fpaths_data):
    recipient_patterns = {}
    for pattern_key in os.listdir(fpaths_data['recipient_pattern_textures_root']):
        recipient_patterns[pattern_key] = {}
        for res_key in PATTERN_RES_KEYS:
            recipient_patterns[pattern_key][res_key] = fpaths_data['recipient_pattern_textures_root'].joinpath(
                pattern_key, f'{pattern_key}_{res_key}.png')
    return recipient_patterns

FPATHS = {}
FPATHS['addon_root'] = pathlib.Path(
    os.path.dirname(os.path.realpath(__file__)))

FPATHS['data_root'] = FPATHS['addon_root'] / 'data'

FPATHS['urls'] = FPATHS['data_root'] / 'urls.json'
FPATHS['blendfs_root'] = FPATHS['data_root'] / 'blendfs'
FPATHS['blend_assets'] = FPATHS['blendfs_root'] / 'LiquidFeel_MASTER.blend'

# Filepath data for input data
FPATHS['input_field_data'] = FPATHS['data_root'] / 'ui_control_inputs.json'
# FPATHS['material_input_data'] = FPATHS['data_root'] / 'material_input_data.json'

# Filepath data for icons
FPATHS['icons_root'] = FPATHS['data_root'] / 'icons'
FPATHS['icons'] = assemble_flat_path_data(FPATHS['icons_root'])

# Filepath data for material thumbnails
FPATHS['material_thumbnails_root'] = FPATHS['data_root'] / 'material_thumbnails'
FPATHS['material_thumbnails'] = assemble_flat_path_data(FPATHS['material_thumbnails_root'])

# Filepath data for recipient pattern textures
FPATHS['recipient_pattern_textures_root'] = FPATHS['data_root'] / 'recipient_pattern_textures'
FPATHS['recipient_pattern_textures'] = assemble_recipient_pattern_path_data(FPATHS)

# Filepath data for recipient thumbnails
FPATHS['recipient_asset_thumbnails_root'] = FPATHS['data_root'] / 'recipient_asset_thumbnails'
FPATHS['recipient_asset_thumbnails'] = assemble_flat_path_data(FPATHS['recipient_asset_thumbnails_root'], gen_key=False)
# FPATHS['recipient_asset_append_fpath'] = FPATHS['blendfs_root'] / 'LiquiFeel_Glass_Assets.blend'
FPATHS['recipient_asset_parenting_data'] = FPATHS['data_root'] / 'recipient_asset_parenting_data.json'

FPATHS['node_socket_data'] = FPATHS['data_root'] / 'node_socket_data.json'
FPATHS['input_ui_type_data'] = FPATHS['data_root'] / 'input_ui_type_data.json'


# : [(THUMBNAIL_NAME, OBJECT_NAME)]
recipient_asset_namess = [
    ('American Pint Glass', 'American_Pint_Glass'),
    ('Bordeaux Wine Glass', 'Bordeaux Wine Glass'),
    ('Beer Bottle 22oz', 'Bomber 22oz Bottle'),
    ('Beer Mug', 'Beer_Mug'),
    ('Large Bowl', 'Bowl_2in'),
    ('Bowl 6.5in', 'Bowl_6in'),
    ('Bowl 7.5in', 'Bowl_7.5in'),
    ('Bowl 9in', 'Bowl_9in'),
    ('Champagne Bottle', 'Champagne 750mL'),
    ('Hurricane Glass', 'Hurricane Glass'),
    ('Ikea Carafe', 'Ikea 365+ Carafe'),
    ('Pitcher', 'Pitcher'),
    ('Soda Bottle 16.9oz', 'Soda Bottle'),
    ('Whiskey Glass', 'Whiskey Glass'),
    ('Liquifeel Carafe', 'LiquifeelCarafe'),
]
# # : [(THUMBNAIL_NAME, OBJECT_NAME)]
# recipient_asset_namess = [
#     ('American Pint Glass', 'American_Pint_Glass'),
#     ('Bordeaux Wine Glass', 'Bordeaux Wine Glass'),
#     ('Beer Bottle 22oz', 'Bomber 22oz Bottle'),
#     ('Beer Mug', 'Beer_Mug'),
#     ('Bowl_2in', 'Bowl_2in'),
#     ('Bowl_6.5in', 'Bowl_6in'),
#     ('Bowl_7.5in', 'Bowl_7.5in'),
#     ('Bowl_9in', 'Bowl_9in'),
#     ('Champagne Bottle', 'Champagne 750mL'),
#     ('Hurricane Glass', 'Hurricane Glass'),
#     ('Ikea Carafe', 'Ikea 365+ Carafe'),
#     ('Pitcher', 'Pitcher'),
#     ('Soda Bottle 16.9oz', 'Soda Bottle'),
#     ('Whiskey Glass', 'Whiskey Glass'),
#     ('Liquifeel Carafe', 'LiquifeelCarafe'),
# ]

# # manual rename operation data
# # : [(THUMBNAIL_NAME, PREVIEW_NAME)]
# preview_recipient_asset_names = {
#     'American Pint Glass': None,
#     'Bordeaux Wine Glass': None,
#     'Beer Bottle 22oz': None,
#     'Beer Mug': None,
#     'Bowl_2in': 'Large Bowl',
#     'Bowl_6.5in': 'Bowl 6.5in',
#     'Bowl_7.5in': 'Bowl 7.5in',
#     'Bowl_9in': 'Bowl 9in',
#     'Champagne Bottle': None,
#     'Hurricane Glass': None,
#     'Ikea Carafe': None,
#     'Pitcher': None,
#     'Soda Bottle 16.9oz': None,
#     'Whiskey Glass': None,
#     'Liquifeel Carafe': None,
# }

with open(str(FPATHS['recipient_asset_parenting_data']), 'r') as f:
    RECIPIENT_ASSET_PARENTING_DATA = json.load(f)
RECIPIENT_ASSET_NAME_DATA = {}

# print()
# print('RECIPIENT_ASSET_PARENTING_DATA')
# pprint(RECIPIENT_ASSET_PARENTING_DATA)
# print()

for thumbnail_name, obj_name in recipient_asset_namess:
    key = key_from_name(thumbnail_name)
    RECIPIENT_ASSET_NAME_DATA[key] = {
        'thumbnail': thumbnail_name,
        'object': obj_name,
    }
print()
print('RECIPIENT_ASSET_NAME_DATA')
pprint(RECIPIENT_ASSET_NAME_DATA)
print()

## LIBRARY MATERIALS ----------

# with open(str(FPATHS['input_field_data']), 'r') as f:
#     INPUT_FIELD_DATA__PRESERVING_ORDER = json.load(f)

INPUT_FIELD_DATA__PRESERVING_ORDER = [
    {
        'data': [
            {
                'data': [
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50,
                                                        'underlying_input_name': 'Liquid Level',
                                                        'ui_input_name': 'Liquid Amount',
                                                        'key': 'liquid_amount',
                                                        'ui_category_key': 'fill',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Liquid Amount',
                                                    'key_type': 'input_name'},
                                                {
                                                    # This socket type's items can't seem to be
                                                    # deducible from the socket object at
                                                    # runtime. We are stuck with having to manually
                                                    # place the items in this data structure.
                                                    # The value which needs to be passed has to be
                                                    # an integer representing the position of the
                                                    # menu item in question. The only way of
                                                    # figuring out which iteger corresponds to which
                                                    # menu string is empirically, accordingly the
                                                    # items entry in this dictionary has to be in
                                                    # the correct order.
                                                    'data': {
                                                        'underlying_input_default_val': 0, # 'Concave Meniscus'
                                                        'underlying_input_name': 'Meniscus Type',
                                                        'ui_input_name': 'Meniscus Type',
                                                        'key': 'meniscus_type',
                                                        'ui_category_key': 'fill',
                                                        'items': ['Concave Meniscus', 'Convex Meniscus'],
                                                        'default_val': 'Concave Meniscus',
                                                        'type': 'enum'},
                                                    'key': 'Meniscus Type',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 'straight',
                                                        'ui_to_underlying_val_mapping': [
                                                            'Straight',
                                                            'Irregular'],
                                                        'key': 'opening_shape',
                                                        'ui_category_key': 'fill',
                                                        'type': 'enum'},
                                                    'key': 'Opening '
                                                    'Shape',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'dependency': {
                                                #             'group_name': FILL_NG_NAME,
                                                #             'input_name': 'Opening Shape',
                                                #             'target_type': 'Fill'},
                                                #         'underlying_input_name': 'Lip Threshold',
                                                #         'key': 'lip_threshold',
                                                #         'linked_update_index': 0.0,
                                                #         'ui_category_key': 'fill',
                                                #         'type': 'float',
                                                #         'update_f': 'lip_threshold_update'},
                                                #     'key': 'Lip Threshold',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Seal',
                                                        'key': 'seal_container',
                                                        'ui_category_key': 'fill',
                                                        'type': 'bool'},
                                                    'key': 'Seal Container',
                                                    'key_type': 'input_name'}],
                                            'key': FILL_NG_NAME,
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Hide Recipient',
                                                        'key': 'hide_recipient',
                                                        'ui_category_key': 'fill',
                                                        'type': 'bool'},
                                                    'key': 'Hide Recipient',
                                                    'key_type': 'input_name'}],
                                            'key': 'Hide_Recipient',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': FILL_NG_NAME,
                                                            'input_name': 'Opening Shape',
                                                            'target_type': 'Fill'},
                                                        'underlying_input_name': 'Lip Threshold',
                                                        'key': 'lip_threshold',
                                                        'linked_update_index': 0.0,
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'float',
                                                        # 'update_f': 'lip_threshold_update'
                                                    },
                                                    'key': 'Lip Threshold',
                                                    'key_type': 'input_name'}],
                                            'key': 'LiquiFeel_Select Outer',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Liquid Amount',
                                'Meniscus Type',
                                'Opening Shape',
                                'Lip Threshold',
                                'Seal Container',
                                'Hide Recipient']},
                        'key': 'fill',
                        'key_type': 'material/func_name'}],
                'key': 'fill',
                'key_type': 'library'}],
        'key': 'geometry',
        'key_type': 'main_tab'},
    {
        'data': [
            {
                'data': [
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.569447,
                                                            0.0,
                                                            0.838913],
                                                        'underlying_input_name': 'Liquid Color',
                                                        'key': 'liquid_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Liquid Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 25.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Turbidity',
                                                        'key': 'turbidity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Turbidity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.1,
                                                        'underlying_input_name': 'Subsurface',
                                                        'key': 'subsurface',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Subsurface',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Particles Opacity',
                                                        'key': 'particles_opacity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Particles Opacity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            0.292314,
                                                            0.756792],
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Color',
                                                        'key': 'foam_color',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'color'},
                                                    'key': 'Foam Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            0.683388,
                                                            0.650549],
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Secondary Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Secondary Foam Color',
                                                        'key': 'secondary_foam_color',
                                                        'ui_category_key': 'Secondary Foam',
                                                        'type': 'color'},
                                                    'key': 'Secondary Foam Color',
                                                    'key_type': 'input_name'}],
                                            'key': 'UberLiquid_Shader',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'Transmission',
                                                        'key': 'transmission',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Transmission',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'ui_to_underlying_val_mapping': {
                                                            False: 0.0,
                                                            True: 1.0},
                                                        'underlying_input_name': 'Smoothie',
                                                        'key': 'smoothie',
                                                        'ui_category_key': 'Smoothie',
                                                        'type': 'float'},
                                                    'key': 'Smoothie',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Smoothie',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Pulp',
                                                        'key': 'pulp',
                                                        'ui_category_key': 'Smoothie',
                                                        'type': 'float'},
                                                    'key': 'Pulp',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Secondary Foam',
                                                        'key': 'secondary_foam',
                                                        'ui_category_key': 'Secondary Foam',
                                                        'type': 'bool'},
                                                    'key': 'Secondary Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Secondary Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Secondary Foam Opacity',
                                                        'key': 'secondary_foam_opacity',
                                                        'ui_category_key': 'Secondary Foam',
                                                        'type': 'float'},
                                                    'key': 'Secondary Foam Opacity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 25.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Secondary Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Secondary Foam Size',
                                                        'key': 'secondary_foam_scale',
                                                        'ui_category_key': 'Secondary Foam',
                                                        'type': 'float'},
                                                    'key': 'Secondary Foam Size',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 150.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Value',
                                                        'key': 'bubbles_value',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Value',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Small Bubbles Presence',
                                                        'key': 'small_bubbles_presence',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Small Bubbles Presence',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Medium Bubbles Presence',
                                                        'key': 'medium_bubbles_presence',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Medium Bubbles '
                                                    'Presence',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Large Bubbles Presence',
                                                        'key': 'large_bubbles_presence',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Large Bubbles Presence',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Seed',
                                                        'key': 'foam_seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Seed',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 48,
                                                        'underlying_input_name': 'Bubbles Seed',
                                                        'key': 'bubbles_seed',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'int'},
                                                    'key': 'Bubbles Seed',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Carbonation Bubbles',
                                                        'key': 'carbonation_bubbles',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonation Bubbles',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Carbonation Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Carbonation Bubbles Density',
                                                        'key': 'carbonation_bubbles_quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Carbonation Bubbles Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'UberLiquid',
                                                            'input_name': 'Carbonation Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Carbonation Bubbles Scale',
                                                        'key': 'carbonation_bubbles_size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Carbonation Bubbles Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'UberLiquid',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Liquid Color',
                                'Transmission',
                                'Intensity',
                                'Turbidity',
                                'Subsurface',
                                'Smoothie',
                                'Pulp',
                                'Particles Opacity',
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Foam Color',
                                'Secondary Foam',
                                'Secondary Foam Color',
                                'Secondary Foam Opacity',
                                'Secondary Foam Size',
                                'Bubbles Scale',
                                'Bubbles Value',
                                'Small Bubbles Presence',
                                'Medium Bubbles Presence',
                                'Large Bubbles Presence',
                                'Normal Strength',
                                'Foam Seed',
                                'Bubbles Seed',
                                'Carbonation Bubbles',
                                'Carbonation Bubbles Quantity',
                                'Carbonation Bubbles Size']},
                        'key': 'UberLiquid',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 2.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 315.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Carbonated',
                                'Quantity',
                                'Size',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Beer',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 2.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 315.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Carbonated',
                                'Quantity',
                                'Size',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Black Beer',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.806952,
                                                            0.665387,
                                                            0.412543],
                                                        'underlying_input_name': 'Tea Color',
                                                        'key': 'tea_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Tea Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 200.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Tea Shader',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Tea Color', 'Intensity']},
                        'key': 'Black Tea',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.603826,
                                                            0.955973,
                                                            1.0],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 415.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Blue Lagoon',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color', 'Intensity']},
                        'key': 'Blue Lagoon',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 220.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Blueberry Juice',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.440597,
                                                            0.300089,
                                                            0.140131],
                                                        'underlying_input_name': 'Liquid Color',
                                                        'key': 'liquid_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Liquid Color',
                                                    'key_type': 'input_name'}],
                                            'key': 'Cappuccino',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 850.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed',
                                'Liquid Color']},
                        'key': 'Cappuccino',
                        'key_type': 'material/func_name'},
                    # {
                    #     'data': {
                    #         'data': [
                    #             {
                    #                 'data': [
                    #                     {
                    #                         'data': [
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': [
                    #                                         0.440597,
                    #                                         0.300089,
                    #                                         0.140131],
                    #                                     'underlying_input_name': 'Liquid Color',
                    #                                     'key': 'liquid_color',
                    #                                     'ui_category_key': 'Liquid',
                    #                                     'type': 'color'},
                    #                                 'key': 'Liquid Color',
                    #                                 'key_type': 'input_name'}],
                    #                         'key': 'Cappuccino',
                    #                         'key_type': 'group_name'}],
                    #                 'key': 'Shader NG',
                    #                 'key_type': 'target_type'},
                    #             {
                    #                 'data': [
                    #                     {
                    #                         'data': [
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 0.025,
                    #                                     'dependency': {
                    #                                         'group_name': 'Cappuccino Utils',
                    #                                         'input_name': 'Foam',
                    #                                         'target_type': 'GeoNode'},
                    #                                     'underlying_input_name': 'Foam Amount',
                    #                                     'key': 'foam_amount',
                    #                                     'ui_category_key': 'Foam',
                    #                                     'subtype': 'percentage',
                    #                                     'type': 'float'},
                    #                                 'key': 'Foam Amount',
                    #                                 'key_type': 'input_name'}],
                    #                         'key': 'Foam Utils',
                    #                         'key_type': 'group_name'},
                    #                     {
                    #                         'data': [
                    #                             # # " Ideea cu cappuccino e ca nu are sens sa fie fara spuma, that's the point of it :)) " -- Alex
                    #                             # {
                    #                             #     'data': {
                    #                             #         'underlying_input_default_val': True,
                    #                             #         'underlying_input_name': 'Foam',
                    #                             #         'key': 'foam',
                    #                             #         'ui_category_key': 'Foam',
                    #                             #         'type': 'bool'},
                    #                             #     'key': 'Foam',
                    #                             #     'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 850.0,
                    #                                     # 'dependency': {
                    #                                     #     'group_name': 'Cappuccino Utils',
                    #                                     #     'input_name': 'Foam',
                    #                                     #     'target_type': 'GeoNode'},
                    #                                     'underlying_input_name': 'Bubbles Scale',
                    #                                     'key': 'bubbles_scale',
                    #                                     'ui_category_key': 'Foam',
                    #                                     'type': 'float'},
                    #                                 'key': 'Bubbles Scale',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 1.0,
                    #                                     # 'dependency': {
                    #                                     #     'group_name': 'Cappuccino Utils',
                    #                                     #     'input_name': 'Foam',
                    #                                     #     'target_type': 'GeoNode'},
                    #                                     'underlying_input_name': 'Bubbles',
                    #                                     'key': 'bubbles',
                    #                                     'ui_category_key': 'Foam',
                    #                                     'type': 'float'},
                    #                                 'key': 'Bubbles',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 1.0,
                    #                                     # 'dependency': {
                    #                                     #     'group_name': 'Cappuccino Utils',
                    #                                     #     'input_name': 'Foam',
                    #                                     #     'target_type': 'GeoNode'},
                    #                                     'underlying_input_name': 'Normal Strength',
                    #                                     'key': 'normal_strength',
                    #                                     'ui_category_key': 'Foam',
                    #                                     'type': 'float'},
                    #                                 'key': 'Normal Strength',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 0,
                    #                                     # 'dependency': {
                    #                                     #     'group_name': 'Cappuccino Utils',
                    #                                     #     'input_name': 'Foam',
                    #                                     #     'target_type': 'GeoNode'},
                    #                                     'underlying_input_name': 'Seed',
                    #                                     'key': 'seed',
                    #                                     'ui_category_key': 'Foam',
                    #                                     'type': 'int'},
                    #                                 'key': 'Seed',
                    #                                 'key_type': 'input_name'}],
                    #                         'key': 'Cappuccino Utils',
                    #                         'key_type': 'group_name'}],
                    #                 'key': 'GeoNode',
                    #                 'key_type': 'target_type'}],
                    #         'input_order': [
                    #             # 'Foam',
                    #             'Foam Amount',
                    #             'Liquid Color',
                    #             'Bubbles Scale',
                    #             'Bubbles',
                    #             'Normal Strength',
                    #             'Seed']},
                    #     'key': 'Cappuccino',
                    #     'key_type': 'material/func_name'}
                    # ,
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 110.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Carbonated',
                                'Quantity',
                                'Size',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Champagne',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.2,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.3,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Chocolate Milk',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 175.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 5.0,
                                                        'underlying_input_name': 'Coffee Intensity',
                                                        'key': 'coffee_intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Coffee Intensity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Coffee',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Coffee Intensity',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Coffee',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 110.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Carbonated',
                                'Quantity',
                                'Size',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Coke',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 175.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.2,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'Pulp Amount',
                                                        'key': 'pulp_amount',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Pulp Amount',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.114435,
                                                            0.005605,
                                                            0.005605],
                                                        'underlying_input_name': 'Juice Color',
                                                        'key': 'juice_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Juice Color',
                                                    'key_type': 'input_name'}],
                                            'key': 'Juice Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed',
                                'Pulp Amount',
                                'Juice Color']},
                        'key': 'Cranberry Juice',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 110.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles '
                                                    'Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Carbonated',
                                'Quantity',
                                'Size',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Energy Drink',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.806952,
                                                            0.48515,
                                                            0.0],
                                                        'underlying_input_name': 'Liquid Color',
                                                        'key': 'liquid_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Liquid Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Ginger Ale',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 10.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Liquid Color',
                                'Intensity',
                                'Carbonated',
                                'Quantity',
                                'Size']},
                        'key': 'Ginger Ale',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.2,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 400.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.270498,
                                                            0.445201,
                                                            0.030714],
                                                        'underlying_input_name': 'Juice Color',
                                                        'key': 'juice_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Juice Color',
                                                    'key_type': 'input_name'},
                                            {
                                                    'data': {
                                                        'underlying_input_default_val': 1,
                                                        # 'dependency': {
                                                        #     'group_name': 'Foam Shader Utils',
                                                        #     'input_name': 'Foam',
                                                        #     'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Pulp Amount',
                                                        'key': 'pulp_amount',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Pulp Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Juice Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed',
                                'Juice Color',
                                'Pulp Amount']},
                        'key': 'Green Apple Juice',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 120.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'Pulp Amount',
                                                        'key': 'pulp_amount',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Pulp Amount',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.270498,
                                                            0.445201,
                                                            0.030714],
                                                        'underlying_input_name': 'Juice Color',
                                                        'key': 'juice_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Juice Color',
                                                    'key_type': 'input_name'}],
                                            'key': 'Juice Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 2.8,
                                                        'underlying_input_name': 'Smoothie Chunks',
                                                        'key': 'smoothie_chunks',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Smoothie Chunks',
                                                    'key_type': 'input_name'}],
                                            'key': 'Smoothie Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed',
                                'Pulp Amount',
                                'Juice Color',
                                'Smoothie Chunks']},
                        'key': 'Greenies Smoothie',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            0.925581,
                                                            0.634816],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 70.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Crystallization',
                                                        'key': 'crystallization',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Crystallization',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 2.0,
                                                        'underlying_input_name': 'Crystallization Scale',
                                                        'key': 'crystallization_scale',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Crystallization Scale',
                                                    'key_type': 'input_name'}],
                                            'key': 'Honey',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Static Bubbles',
                                                        'key': 'static_bubbles',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'bool'},
                                                    'key': 'Static Bubbles',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 10.0,
                                                        'dependency': {
                                                            'group_name': 'Static Bubbles',
                                                            'input_name': 'Static Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Static Bubbles',
                                                            'input_name': 'Static Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Static Bubbles',
                                                            'input_name': 'Static Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Static Bubbles',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'Intensity',
                                'Turbidity',
                                'Crystallization',
                                'Crystallization Scale',
                                'Static Bubbles',
                                'Quantity',
                                'Size',
                                'Seed']},
                        'key': 'Honey',
                        'key_type': 'material/func_name'},
                    # {
                    #     'data': {
                    #         'data': [
                    #             {
                    #                 'data': [
                    #                     {
                    #                         'data': [
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': [
                    #                                         1.0,
                    #                                         0.904783,
                    #                                         0.571125],
                    #                                     'underlying_input_name': 'Color',
                    #                                     'key': 'color',
                    #                                     'ui_category_key': 'Liquid',
                    #                                     'type': 'color'},
                    #                                 'key': 'Color',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 70.0,
                    #                                     'underlying_input_name': 'Intensity',
                    #                                     'key': 'intensity',
                    #                                     'ui_category_key': 'Liquid',
                    #                                     'type': 'float'},
                    #                                 'key': 'Intensity',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 0.3,
                    #                                     'underlying_input_name': 'Turbidity',
                    #                                     'key': 'turbidity',
                    #                                     'ui_category_key': 'Liquid',
                    #                                     'type': 'float'},
                    #                                 'key': 'Turbidity',
                    #                                 'key_type': 'input_name'}],
                    #                         'key': 'Honey',
                    #                         'key_type': 'group_name'}],
                    #                 'key': 'Shader NG',
                    #                 'key_type': 'target_type'},
                    #             {
                    #                 'data': [
                    #                     {
                    #                         'data': [
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 0.0,
                    #                                     'underlying_input_name': 'Crystallization',
                    #                                     'key': 'crystallization',
                    #                                     'ui_category_key': 'Liquid',
                    #                                     'type': 'float'},
                    #                                 'key': 'Crystallization',
                    #                                 'key_type': 'input_name'}],
                    #                         'key': 'Honey Utils',
                    #                         'key_type': 'group_name'},
                    #                     {
                    #                         'data': [
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': True,
                    #                                     'underlying_input_name': 'Static Bubbles',
                    #                                     'key': 'static_bubbles',
                    #                                     'ui_category_key': 'Bubbles',
                    #                                     'type': 'bool'},
                    #                                 'key': 'Static Bubbles',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 10.0,
                    #                                     'underlying_input_name': 'Density',
                    #                                     'key': 'density',
                    #                                     'ui_category_key': 'Bubbles',
                    #                                     'type': 'float'},
                    #                                 'key': 'Density',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 1.0,
                    #                                     'underlying_input_name': 'Scale',
                    #                                     'key': 'scale',
                    #                                     'ui_category_key': 'Bubbles',
                    #                                     'type': 'float'},
                    #                                 'key': 'Scale',
                    #                                 'key_type': 'input_name'},
                    #                             {
                    #                                 'data': {
                    #                                     'underlying_input_default_val': 0,
                    #                                     'underlying_input_name': 'Seed',
                    #                                     'key': 'seed',
                    #                                     'ui_category_key': 'Bubbles',
                    #                                     'type': 'int'},
                    #                                 'key': 'Seed',
                    #                                 'key_type': 'input_name'}],
                    #                         'key': 'Static Bubbles',
                    #                         'key_type': 'group_name'}],
                    #                 'key': 'GeoNode',
                    #                 'key_type': 'target_type'}],
                    #         'input_order': [
                    #             'Color',
                    #             'Intensity',
                    #             'Turbidity',
                    #             'Crystallization',
                    #             'Static Bubbles',
                    #             'Density',
                    #             'Scale',
                    #             'Seed']},
                    #     'key': 'Honey',
                    #     'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.955973,
                                                            0.814846,
                                                            0.401978],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 120.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Ice Tea',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color', 'Intensity']},
                        'key': 'Ice Tea',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            0.98225,
                                                            0.226966],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'underlying_input_name': 'Pulp Particles Opacity',
                                                        'key': 'pulp_particles_opacity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Pulp Particles Opacity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Lemonade',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'Pulp Particles Opacity']},
                        'key': 'Lemonade',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Milk',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.854992,
                                                            0.799102,
                                                            0.114436],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 40.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.1,
                                                        'underlying_input_name': 'Turbidity',
                                                        'key': 'turbidity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Turbidity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Olive Oil',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Static Bubbles',
                                                        'key': 'static_bubbles',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'bool'},
                                                    'key': 'Static Bubbles',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 10.0,
                                                        'dependency': {
                                                            'group_name': 'Static Bubbles',
                                                            'input_name': 'Static Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Static Bubbles',
                                                            'input_name': 'Static Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Static Bubbles',
                                                            'input_name': 'Static Bubbles',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Bubbles',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Static Bubbles',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'Intensity',
                                'Turbidity',
                                'Static Bubbles',
                                'Quantity',
                                'Size',
                                'Seed']},
                        'key': 'Olive Oil',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 200.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.3,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            0.337163,
                                                            0.026241],
                                                        'underlying_input_name': 'Juice Color',
                                                        'key': 'juice_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Juice Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 3.0,
                                                        'underlying_input_name': 'Pulp Amount',
                                                        'key': 'pulp_amount',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Pulp Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Juice Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed',
                                'Juice Color',
                                'Pulp Amount']},
                        'key': 'Orange Juice',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.2,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 110.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.396755,
                                                            0.088655,
                                                            0.135633],
                                                        'underlying_input_name': 'Juice Color',
                                                        'key': 'juice_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Juice Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'Pulp Amount',
                                                        'key': 'pulp_amount',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Pulp Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Juice Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed',
                                'Juice Color',
                                'Pulp Amount']},
                        'key': 'Red Fruit Smoothie',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.603827,
                                                            0.0,
                                                            0.038204],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 100.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.1,
                                                        'underlying_input_name': 'Turbidity',
                                                        'key': 'turbidity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Turbidity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Wine',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'Intensity',
                                'Turbidity']},
                        'key': 'Red Wine',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            0.396755,
                                                            0.187821],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 40.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.1,
                                                        'underlying_input_name': 'Turbidity',
                                                        'key': 'turbidity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Turbidity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Wine',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'Intensity',
                                'Turbidity']},
                        'key': 'Rose Wine',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 150.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Carbonated',
                                'Quantity',
                                'Size']},
                        'key': 'Water',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 110.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.3,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal '
                                                    'Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.114435,
                                                            0.005605,
                                                            0.005605],
                                                        'underlying_input_name': 'Juice Color',
                                                        'key': 'juice_color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Juice Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'Pulp Amount',
                                                        'key': 'pulp_amount',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Pulp Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Juice Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed',
                                'Juice Color',
                                'Pulp Amount']},
                        'key': 'Tomato Juice',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Carbonated',
                                                        'key': 'carbonated',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'bool'},
                                                    'key': 'Carbonated',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 50.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Quantity',
                                                        'key': 'quantity',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Quantity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Carbonation_Static',
                                                            'input_name': 'Carbonated',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Size',
                                                        'key': 'size',
                                                        'ui_category_key': 'Carbonation',
                                                        'type': 'float'},
                                                    'key': 'Size',
                                                    'key_type': 'input_name'}],
                                            'key': 'Carbonation_Static',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 2.5,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Amount',
                                                        'key': 'foam_amount',
                                                        'ui_category_key': 'Foam',
                                                        'subtype': 'percentage',
                                                        'type': 'float'},
                                                    'key': 'Foam Amount',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Utils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'underlying_input_name': 'Foam',
                                                        'key': 'foam',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'bool'},
                                                    'key': 'Foam',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Foam Center Distribution',
                                                        'key': 'foam_center_distribution',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Foam Center Distribution',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 315.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Bubbles Scale',
                                                        'key': 'bubbles_scale',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Bubbles Scale',
                                                    'key_type': 'input_name'},
                                                # {
                                                #     'data': {
                                                #         'underlying_input_default_val': 1.0,
                                                #         'underlying_input_name': 'Bubbles',
                                                #         'key': 'bubbles',
                                                #         'ui_category_key': 'Foam',
                                                #         'type': 'float'},
                                                #     'key': 'Bubbles',
                                                #     'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Normal Strength',
                                                        'key': 'normal_strength',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'float'},
                                                    'key': 'Normal Strength',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0,
                                                        'dependency': {
                                                            'group_name': 'Foam Shader Utils',
                                                            'input_name': 'Foam',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Seed',
                                                        'key': 'seed',
                                                        'ui_category_key': 'Foam',
                                                        'type': 'int'},
                                                    'key': 'Seed',
                                                    'key_type': 'input_name'}],
                                            'key': 'Foam Shader Utils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Foam',
                                'Foam Amount',
                                'Carbonated',
                                'Quantity',
                                'Size',
                                'Foam Center Distribution',
                                'Bubbles Scale',
                                'Bubbles',
                                'Normal Strength',
                                'Seed']},
                        'key': 'Unfiltered Beer',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.955973,
                                                            0.879622,
                                                            0.514918],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 230.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Whiskey',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'Intensity']},
                        'key': 'Whiskey',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            0.814846,
                                                            0.122139],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 10.0,
                                                        'underlying_input_name': 'Intensity',
                                                        'key': 'intensity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Intensity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Turbidity',
                                                        'key': 'turbidity',
                                                        'ui_category_key': 'Liquid',
                                                        'type': 'float'},
                                                    'key': 'Turbidity',
                                                    'key_type': 'input_name'}],
                                            'key': 'Wine',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'Intensity',
                                'Turbidity']},
                        'key': 'White Wine',
                        'key_type': 'material/func_name'}],
                'key': 'liquids',
                'key_type': 'library'},
            {
                'data': [
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            1.0,
                                                            1.0,
                                                            1.0],
                                                        'underlying_input_name': 'Glass Color',
                                                        'key': 'glass_color',
                                                        'ui_category_key': 'Glass',
                                                        'type': 'color'},
                                                    'key': 'Glass Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'GlassDensity',
                                                        'key': 'glassdensity',
                                                        'ui_category_key': 'Glass',
                                                        'type': 'float'},
                                                    'key': 'GlassDensity',
                                                    'key_type': 'input_name'}],
                                            'key': 'PatternedGlass',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            'abstract_01',
                                                            '1k',
                                                            'liquifeel'],
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'enum_source_fpath_key': 'recipient_pattern_textures',
                                                        'underlying_input_name': 'Pattern Texture; Pattern Texture Resolution; Pattern Library; User Pattern Texture',
                                                        'key': [
                                                            'pattern_texture',
                                                            'pattern_texture_resolution',
                                                            'pattern_library',
                                                            'user_pattern_texture'],
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'imgtex'},
                                                    'key': 'Pattern Texture; Pattern Texture Resolution; Pattern Library; User Pattern Texture',
                                                    'key_type': 'input_name'}],
                                            'key': 'PatternImage_UV; PatternImage_Box',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader Node',
                                    'key_type': 'target_type'},
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'underlying_input_name': 'Pattern',
                                                        'key': 'pattern',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'bool'},
                                                    'key': 'Pattern',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': True,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'ui_to_underlying_val_mapping': {
                                                            'Box': True,
                                                            'UV': False},
                                                        'underlying_input_name': 'UV/Box',
                                                        'key': 'mapping',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'bool'},
                                                    'key': 'Mapping',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 'UVMap',
                                                        'dependency': [
                                                            {
                                                                'group_name': 'PatternUtils',
                                                                'input_name': 'Pattern',
                                                                'target_type': 'GeoNode'},
                                                            {
                                                                'eqv': 'UV',
                                                                'group_name': 'PatternUtils',
                                                                'input_name': 'Mapping',
                                                                'target_type': 'GeoNode'}],
                                                        'items_gen_f': 'get_object_uv_maps_items_f()',
                                                        'underlying_input_name': 'UV Name',
                                                        'key': 'uv_name',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'string'},
                                                    'key': 'UV Name',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': False,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Use Vertex Group',
                                                        'key': 'use_vertex_group',
                                                        'ui_category_key': 'Pattern',
                                                        'tandem_default_set': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Vertex Group',
                                                            'target_type': 'GeoNode'},
                                                        'type': 'bool'},
                                                    'key': 'Use Vertex Group',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'dependency': [
                                                            {
                                                                'group_name': 'PatternUtils',
                                                                'input_name': 'Pattern',
                                                                'target_type': 'GeoNode'},
                                                            {
                                                                'group_name': 'PatternUtils',
                                                                'input_name': 'Use Vertex Group',
                                                                'target_type': 'GeoNode'}],
                                                        'items_gen_f': 'get_object_vertex_groups_items_f()',
                                                        'underlying_input_name': 'Vertex Group',
                                                        'key': 'vertex_group',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'string'},
                                                    'key': 'Vertex Group',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Upper Limit',
                                                        'key': 'upper_limit',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'float'},
                                                    'key': 'Upper Limit',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Lower Limit',
                                                        'key': 'lower_limit',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'float'},
                                                    'key': 'Lower Limit',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Pattern Falloff',
                                                        'key': 'pattern_falloff',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'float'},
                                                    'key': 'Pattern Falloff',
                                                    'key_type': 'input_name'}],
                                            'key': 'PatternUtils',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Lip Threshold',
                                                        'key': 'lip_threshold',
                                                        'linked_update_index': 0.0,
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'float',
                                                        # 'update_f': 'lip_threshold_update'
                                                    },
                                                    'key': 'Lip Threshold',
                                                    'key_type': 'input_name'}],
                                            'key': 'LiquiFeel_Select Outer',
                                            'key_type': 'group_name'},
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.5,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Patttern Extrusion',
                                                        'key': 'patttern_extrusion',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'float'},
                                                    'key': 'Patttern Extrusion',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'dependency': {
                                                            'group_name': 'PatternUtils',
                                                            'input_name': 'Pattern',
                                                            'target_type': 'GeoNode'},
                                                        'underlying_input_name': 'Pattern Tiling',
                                                        'key': 'pattern_size',
                                                        'ui_category_key': 'Pattern',
                                                        'type': 'float'},
                                                    'key': 'Pattern Tiling',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.55,
                                                        'underlying_input_name': 'IoR',
                                                        'key': 'ior',
                                                        'ui_category_key': 'Glass',
                                                        'type': 'float'},
                                                    'key': 'IoR',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Rim Darkness',
                                                        'key': 'rim_darkness',
                                                        'ui_category_key': 'Glass',
                                                        'type': 'float'},
                                                    'key': 'Rim Darkness',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Dispersion',
                                                        'key': 'dispersion',
                                                        'ui_category_key': 'Glass',
                                                        'type': 'float'},
                                                    'key': 'Dispersion',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.01,
                                                        'underlying_input_name': 'Glass Roughness',
                                                        'key': 'glass_roughness',
                                                        'ui_category_key': 'Glass',
                                                        'type': 'float'},
                                                    'key': 'Glass Roughness',
                                                    'key_type': 'input_name'}],
                                            'key': 'GlassUtils',
                                            'key_type': 'group_name'}],
                                    'key': 'GeoNode',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Glass Color',
                                'GlassDensity',
                                'Pattern Texture; Pattern Texture Resolution; Pattern Library; User Pattern Texture',
                                'Pattern',
                                'Mapping',
                                'UV Name',
                                'Use Vertex Group',
                                'Vertex Group',
                                'Lip Threshold',
                                'Patttern Extrusion',
                                'Upper Limit',
                                'Lower Limit',
                                'Pattern Falloff',
                                'Pattern Tiling',
                                'IoR',
                                'Rim Darkness',
                                'Dispersion',
                                'Glass Roughness']},
                        'key': 'Uber Glass',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': [
                                                            0.630863,
                                                            1.0,
                                                            0.964617],
                                                        'underlying_input_name': 'Color',
                                                        'key': 'color',
                                                        'ui_category_key': 'Controls',
                                                        'type': 'color'},
                                                    'key': 'Color',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.45,
                                                        'underlying_input_name': 'IOR',
                                                        'key': 'ior',
                                                        'ui_category_key': 'Controls',
                                                        'type': 'float'},
                                                    'key': 'IOR',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Roughness',
                                                        'key': 'roughness',
                                                        'ui_category_key': 'Controls',
                                                        'type': 'float'},
                                                    'key': 'Roughness',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.2,
                                                        'underlying_input_name': 'Color Intensity',
                                                        'key': 'color_intensity',
                                                        'ui_category_key': 'Controls',
                                                        'type': 'float'},
                                                    'key': 'Color Intensity',
                                                    'key_type': 'input_name'},
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 0.0,
                                                        'underlying_input_name': 'Cloudiness',
                                                        'key': 'cloudiness',
                                                        'ui_category_key': 'Controls',
                                                        'type': 'float'},
                                                    'key': 'Cloudiness',
                                                    'key_type': 'input_name'}],
                                            'key': 'PET',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color',
                                'IOR',
                                'Roughness',
                                'Color Intensity',
                                'Cloudiness']},
                        'key': 'PET',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'Color Brightness',
                                                        'key': 'color_brightness',
                                                        'ui_category_key': 'Controls',
                                                        'type': 'float'},
                                                    'key': 'Color Brightness',
                                                    'key_type': 'input_name'}],
                                            'key': 'Brown Bottle',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color Brightness']},
                        'key': 'Brown Bottle Glass',
                        'key_type': 'material/func_name'},
                    {
                        'data': {
                            'data': [
                                {
                                    'data': [
                                        {
                                            'data': [
                                                {
                                                    'data': {
                                                        'underlying_input_default_val': 1.0,
                                                        'underlying_input_name': 'Color Brightness',
                                                        'key': 'color_brightness',
                                                        'ui_category_key': 'Controls',
                                                        'type': 'float'},
                                                    'key': 'Color Brightness',
                                                    'key_type': 'input_name'}],
                                            'key': 'Green Bottle Glass',
                                            'key_type': 'group_name'}],
                                    'key': 'Shader NG',
                                    'key_type': 'target_type'}],
                            'input_order': [
                                'Color Brightness']},
                        'key': 'Green Bottle Glass',
                        'key_type': 'material/func_name'}],
                'key': 'solids',
                'key_type': 'library'}],
        'key': 'shading',
        'key_type': 'main_tab'}]

def lose_order__(data_in):
    if isinstance(data_in, dict) and 'input_order' in data_in.keys():
        return lose_order__(data_in['data'])
    elif isinstance(data_in, list): # I have to skip the dict !!!
        data_out = {}
        for e in data_in:
            data_out[e['key']] = lose_order__(e['data'])
        return data_out
    return data_in 

INPUT_FIELD_DATA = lose_order__(INPUT_FIELD_DATA__PRESERVING_ORDER)

## NODE SOCKET DATA --------------------------------------------------

socket_type_2_type_mapping = {'NodeSocketFloat': 'float',
                              'NodeSocketInt': 'int'}

with open(str(FPATHS['node_socket_data']), 'r') as f:
    NODE_SOCKET_DATA = json.load(f)

# AUGMENTATION WITH NODE SOCKET DATA -----------------------------

# for main_tab_key, main_tab_data in NODE_SOCKET_DATA.items():
#     for library_key, library_data in main_tab_data.items():
#         for mat_name, mat_data in library_data.items():
#             for target_type_key, target_type_data in mat_data.items():
#                 for group_name, group_data in target_type_data.items():
#                     for input_name, ns_input_data in group_data.items():
#                         socket_type = ns_input_data['socket_type']
#                         if socket_type in socket_type_2_type_mapping.keys():
#                             ns_input_data['type'] = socket_type_2_type_mapping[
#                                 socket_type]
#                         print()
#                         print(INPUT_FIELD_DATA[main_tab_key][library_key].keys())
#                         print()
#                         INPUT_FIELD_DATA[main_tab_key][library_key][target_type_key][group_name][input_name][
#                             'node_socket_data'] = ns_input_data

# print()
# print('INPUT_FIELD_DATA')
# pprint(INPUT_FIELD_DATA)
# print()

with open(str(FPATHS['input_ui_type_data']), 'r') as f:
    INPUT_UI_TYPE_DATA = json.load(f)

# !!! This probably needs to be changed to conserve the sorting_tag box category order in the input field ui
def get_sorting_tags(targets):
    sorting_tags = []
    for target in targets:
        for group in target['data']:
            for inpt in group['data']:
                sorting_tag = inpt['data']['ui_category_key']
                if sorting_tag not in sorting_tags:
                    sorting_tags.append(sorting_tag)
    return sorting_tags

# def get_sorting_tags(mat):
#     sorting_tags = set()
#     for target in mat['data']:
#         for group in target['data']:
#             sorting_tags.update(
#                 {inpt['data']['ui_category_key'] for inpt in group['data']})
#     return sorting_tags

def filter_input_data_by_sorting_tag(lib_key, mat_name, mat_data, sorting_tag):
    # print()
    # print('filter_input_data_by_sorting_tag')
    # print('mat_data:')
    # pprint(mat_data)
    # print()
    inputs_data = []
    targets = mat['data']['data']
    for target in targets:
        target_key = target['key']
        for group in target['data']:
            group_name = group['key']
            for inpt in group['data']:
                input_key = inpt['key']
                if inpt['data']['ui_category_key'] == sorting_tag:
                    inputs_data.append({
                        'input_key': input_key,
                        'library_key': lib_key,
                        'material_name': mat_name,
                        'target_type': target_key,
                        'group_name': group_name,
                        'input_data': inpt['data']
                    })
    inputs_data.sort(
        key=lambda e_dat: mat_data['data']['input_order'].index(e_dat['input_key']))
    return inputs_data

# print()
# print('INPUT_FIELD_DATA__PRESERVING_ORDER')
# pprint(INPUT_FIELD_DATA__PRESERVING_ORDER)
# print()

SHADING_INPUT_FIELD_DATA_BY_SORTING_TAG = {}
for tab in INPUT_FIELD_DATA__PRESERVING_ORDER:
    tab_key = tab['key']
    for lib in tab['data']:
        lib_key = lib['key']
        SHADING_INPUT_FIELD_DATA_BY_SORTING_TAG[lib_key] = {}
        for mat in lib['data']:
            mat_name = mat['key']
            SHADING_INPUT_FIELD_DATA_BY_SORTING_TAG[lib_key][mat_name] = {}
            sorting_tags = get_sorting_tags(mat['data']['data']) # the target_data list (Shader NG, Shader Node, Geonode)
            for s_tag in sorting_tags:
                SHADING_INPUT_FIELD_DATA_BY_SORTING_TAG[lib_key][mat_name][s_tag] = filter_input_data_by_sorting_tag(
                    lib_key, mat_name, mat, s_tag)

# print()
# print('SHADING_INPUT_FIELD_DATA_BY_SORTING_TAG')
# pprint(SHADING_INPUT_FIELD_DATA_BY_SORTING_TAG)
# print()

## URL ----------

with open(str(FPATHS['urls']), 'r') as f:
    URLS = json.load(f)

## ANIMATION ----------

def prop_value_update_f(obj__, data_path):
    def f():
        prop_parent, key = ref_ob_key_pair(obj__, data_path.split('.'))
        setattr(prop_parent, key, getattr(prop_parent, key))
    return f

def execute_update_hooks_from_obj(obj__):
    if obj__.animation_data and obj__.animation_data.action:
        for fcurve in obj__.animation_data.action.fcurves:
            if 'liquifeel' in fcurve.data_path:
                hook = prop_value_update_f(obj__, fcurve.data_path)
                hook()
    if any([is_obj_library_slot_shaded(obj__, lib_key) for lib_key in ['liquids', 'solids']]):
        slot_mat = get_asset_material(obj__, shading_modality_key='slot')
        if slot_mat.animation_data and slot_mat.animation_data.action:
            for fcurve in slot_mat.animation_data.action.fcurves:
                if 'liquifeel' in fcurve.data_path:
                    hook = prop_value_update_f(slot_mat, fcurve.data_path)
                    hook()
    if any([is_obj_library_fill_shaded(obj__, lib_key) for lib_key in ['liquids', 'solids']]):
        fill_mat = get_asset_material(obj__, shading_modality_key='fill')
        if fill_mat.animation_data and fill_mat.animation_data.action:
            for fcurve in fill_mat.animation_data.action.fcurves:
                if 'liquifeel' in fcurve.data_path:
                    hook = prop_value_update_f(fill_mat, fcurve.data_path)
                    hook()
# def update_hooks_from_obj(obj__):
#     hooks = []
#     if obj__.animation_data and obj__.animation_data.action:
#         for fcurve in obj__.animation_data.action.fcurves:
#             hooks.append(
#                 prop_value_update_f(obj__, fcurve.data_path))
#     return hooks

@persistent
def animation_prop_update_handler(scene):
    # print('animation_prop_update_handler')
    for obj__ in filter(is_obj_liquifeel_asset, list(scene.objects)):
        execute_update_hooks_from_obj(obj__)
# def animation_prop_update_handler(scene):
#     update_hooks = []
#     for obj__ in filter(is_obj_liquifeel_asset, list(scene.objects)):
#         update_hooks.extend(
#             update_hooks_from_obj(obj__))
#     for hook in update_hooks:
#         hook()

# @persistent
# def animation_prop_update_handler(scene):
#     animation_prop_update_handler__(scene)

## REDUX_INPUT_DATA ----------

INPUT_SET_DATA = {}
for tab_key in INPUT_FIELD_DATA.keys():
    tab_input_set_data = {
        'object_attached': {},
        'material_attached': {},
    }
    for library_key, library_data in INPUT_FIELD_DATA[tab_key].items():
        for mat_name, mat_data in library_data.items():
            for target_key, target_data in mat_data.items(): # GeoNode, Shader NG, Shader Node
                if target_key == 'GeoNode':
                    target_attachment_key = 'object_attached'
                else:
                    target_attachment_key = 'material_attached'
                for group_name, group_data in target_data.items():
                    for input_name, input_data in group_data.items():
                        out_input_data = {
                            'path': [tab_key, library_key, mat_name, target_key,
                                     group_name, input_name],
                            'name': input_name,
                            'data': input_data,
                        }
                        if input_name in tab_input_set_data[target_attachment_key].keys():
                            tab_input_set_data[target_attachment_key][input_name].append(
                                out_input_data)
                        else:
                            tab_input_set_data[target_attachment_key][input_name] = [out_input_data]
    INPUT_SET_DATA[tab_key] = tab_input_set_data

def most_common(elems):
    return sorted(elems,
                  key=lambda elem: elems.count(elem),
                  reverse=True)[0]

path_as_mapping_keys = [
    "main_tab",
    "library",
    "material/func_name",
    "target_type",
    "group_name",
]
def path_as_mapping_from_path(path):
    return dict(zip(path_as_mapping_keys, path[:-1]))
data_branch_key_mapping = {
    'underlying_input_name': 'underlying_input_name',
    'prop_key': 'key',
    'ui_category_key': 'ui_category_key',
    'underlying_input_type': 'type',
    'underlying_input_subtype': 'subtype',
    # 'dependency': 'dependency',
}
def reduce_input_data(inputs_data):
    data = {
        'ui_input_name': most_common(
            [d['name'] for d in inputs_data]),
        'paths': [],
    }
    for d in inputs_data:
        data['paths'].append(
            {'list': d['path'],
             'mapping': path_as_mapping_from_path(d['path'])})
    for new_key, old_key in data_branch_key_mapping.items():
        if old_key in d['data'].keys():
            data[new_key] = most_common(
                [d['data'][old_key] for d in filter(
                    lambda d: old_key in d['data'].keys(),
                    inputs_data)])
    return data
# data_branch_key_mapping = {
#     'underlying_input_name': 'underlying_input_name',
#     'prop_key': 'key',
#     'ui_category_key': 'ui_category_key',
#     'underlying_input_type': 'type',
#     'underlying_input_subtype': 'subtype',
#     # 'dependency': 'dependency',
# }
# def reduce_input_data(inputs_data):
#     data = {
#         'ui_input_name': most_common(
#             [d['name'] for d in inputs_data]),
#         'paths': [],
#     }
#     for d in inputs_data:
#         data['paths'].append(
#             {'list': d['path'],
#              'mapping': path_as_mapping_from_path(d['path'])})
#     for new_key, old_key in data_branch_key_mapping.items():
#         if old_key in d['data'].keys():
#             data[new_key] = most_common(
#                 [d['data'][old_key] for d in filter(
#                     lambda d: old_key in d['data'].keys(),
#                     inputs_data)])
#     return data

# This is a function which recurses down a dictionary hierarchy and
# returns the leaf. If the leaf or some node is non existent, None is
# returned
def index_hierarchy_by_path(data, path):
    if path:
        key = path[0]
        if key in data.keys():
            return index_hierarchy_by_path(data[key],
                                           path[1:])
        else:
            # print('index_hierarchy_by_path')
            # print(f'key error: {key}')
            return None
    else:
        return data

def reduce_bounds_data_per_input(input_name, prop_scaffold, node_socket_data):
    redux_input_data = prop_scaffold[input_name]
    boundss = list(
        filter(bool,
               map(lambda i: index_hierarchy_by_path(node_socket_data,
                                                     redux_input_data['paths'][i]['list']),
                   range(len(redux_input_data['paths'])))))
    if boundss:
        if all(['max' in bounds for bounds in boundss]) and all(
                ['min' in bounds for bounds in boundss]):
            return {
                'max': max(map(lambda bounds: bounds['max'], boundss)),
                'min': min(map(lambda bounds: bounds['min'], boundss)),
            }

def augment_scaffold_with_reduced_node_socket_data(prop_scaffold, bounds_data):
    for input_name, redux_input_data in prop_scaffold.items():
        bounds = reduce_bounds_data_per_input(
            input_name, prop_scaffold, bounds_data)
        if bounds:
            redux_input_data['bounds'] = bounds

REDUX_INPUT_DATA = {
    'geometry': {'object_attached': {},
                 'material_attached': {}},
    'shading': {'object_attached': {},
                'material_attached': {}}}
for main_tab_key, main_tab_data in REDUX_INPUT_DATA.items():
    for target_attachment_key, target_attachment_data in main_tab_data.items():
        for input_name, inputs_data in INPUT_SET_DATA[main_tab_key][target_attachment_key].items():
            target_attachment_data[input_name] = reduce_input_data(inputs_data)
        # We add the elements which are common in the paths of the
        # different control inputs represented by the general inputs
        # we declare in these structures.
        for input_name, redux_input_data in target_attachment_data.items():
            paths_as_mappings = [path['mapping'] for path in redux_input_data['paths']]
            unanimous_path_data = {}
            for key in paths_as_mappings[0].keys():
                reference = paths_as_mappings[0][key]
                if all([mapping[key] == reference for mapping in paths_as_mappings]):
                    unanimous_path_data[key] = reference
            redux_input_data['unanimous_path_elems'] = unanimous_path_data
            # Now we add the ui types to the REDUX data structure.
            if input_name in INPUT_UI_TYPE_DATA[main_tab_key][target_attachment_key].keys():
                redux_input_data['ui_input_type'] = INPUT_UI_TYPE_DATA[
                    main_tab_key][target_attachment_key][input_name]
        # Here we attach input bounding data (to permit enabling
        # sliders on numeric props).
        augment_scaffold_with_reduced_node_socket_data(
            target_attachment_data, NODE_SOCKET_DATA)

# INPUT_FIELD_DATA augmentation with the data held by REDUX_INPUT_DATA

def invert_dict_mapping(mapping_dict):
    out_mapping = {}
    for k, v in mapping_dict.items():
        assert len(list(filter(lambda a: a==v, mapping_dict.values()))) == 1
        out_mapping[v] = k
    return out_mapping

for main_tab_key, main_tab_data in REDUX_INPUT_DATA.items():
    for target_attachment_key, target_attachment_data in main_tab_data.items():
        for input_name, redux_input_data in target_attachment_data.items():
            for path in redux_input_data['paths']:
                # augment INPUT_FIELD_DATA at path with redux_input_data.
                input_field_data = index_hierarchy_by_path(INPUT_FIELD_DATA, path['list'])
                input_field_data['redux_input_data_path'] = [
                    main_tab_key, target_attachment_key, input_name]
                input_field_data['prop_key'] = input_field_data['key']
                input_field_data['underlying_input_type'] = input_field_data['type']
                if 'subtype' in input_field_data.keys():
                    input_field_data['underlying_input_subtype'] = input_field_data['subtype']
                for redux_indat_key in ['ui_input_name', 'ui_input_type']:
                    input_field_data[redux_indat_key] = redux_input_data[redux_indat_key]
                input_field_data['path'] = path
                if 'ui_to_underlying_val_mapping' in input_field_data.keys() and isinstance(
                        input_field_data['ui_to_underlying_val_mapping'], dict):
                    input_field_data['underlying_to_ui_val_mapping'] = invert_dict_mapping(
                        input_field_data['ui_to_underlying_val_mapping'])
                # Augmenting with the ui prop default vals
                if 'underlying_input_default_val' in input_field_data.keys():
                    if input_field_data['underlying_input_type'] == input_field_data[
                            'ui_input_type']:
                        input_field_data['ui_input_default_val'] = input_field_data[
                            'underlying_input_default_val']
                    elif 'underlying_to_ui_val_mapping' in input_field_data.keys():
                        input_field_data['ui_input_default_val'] = input_field_data[
                            'underlying_to_ui_val_mapping'][
                                input_field_data['underlying_input_default_val']]
                    else:
                        # as of 23.03.2024, the only inputs falling
                        # into this case are:
                        # ['UV Name',
                        #  'Pattern Texture; Pattern Texture Resolution; Pattern Library; User Pattern Texture']
                        # Which don't even need default setting. we
                        # won't set defaults for them.
                        pass

# -----------------------------------------------------------------------------
# UNDERLYING INPUT IDENTIFICATION AT RUNTIME

def get_input_field_data_and_path(obj__, redux_input_data, shading_modality_key):
    if len(redux_input_data['paths']) == 1:
        # In the case that there is only one underlying input for the ui
        # input in question, the solution is simple, we just take the
        # first (and only) input_field_data path.
        path = redux_input_data['paths'][0]
    else:
        # In case there are multiple underlying input for the ui input
        # in question, we will use the material name to figure which one
        # of the input_field_data paths represents it.
        material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
        material_name = material['liquifeel']['name']
        path = next(filter(
            lambda path_: path_['mapping']['material/func_name'] == material_name,
            redux_input_data['paths']))
    return (
        index_hierarchy_by_path(INPUT_FIELD_DATA, path['list']),
        path
    )

# -----------------------------------------------------------------------------
# INPUT SETTING FUNCTION AUGMENTATION
# We're augmenting the INPUT_FIELD_DATA structure with input setters.

# Why write functions when we can write data?
get_target_attachment_key = {
    'Shader Node': 'material_attached',
    'Shader NG': 'material_attached',
    'GeoNode': 'object_attached',
}

# We're supposed to take the material from the object. The question
# is: what do we do when the material is not in the object's material
# slots, but instead assigned through geometry nodes?
# I guess that instead of taking it from the slots, we shall take it
# from the fill modififer.

def get_library_key_and_material_name(obj__, path_as_mapping=None, shading_modality_key=None):
    if not(path_as_mapping) and shading_modality_key:
        prop_key_chain = [
            'liquifeel_input_field_props',
            'shading', shading_modality_key, 'manual', 'material_selector']
        # prop_key_chain = [
        #     'liquifeel_input_field_props', 'shading', 'manual',
        #     f'{shading_modality_key}_material_selector']
        library_key = getattr_rec(
            obj__, prop_key_chain + ['library'])
        material_name = getattr_rec(
            obj__, prop_key_chain + [f'{library_key}_material'])
    else:
        library_key = path_as_mapping['library']
        material_name = path_as_mapping['material/func_name']
    return library_key, material_name

def get_asset_material(obj__, path_as_mapping=None, shading_modality_key=None):
    # print()
    # print(f'get_asset_material(obj__={obj__}, path_as_mapping={path_as_mapping}, shading_modality_key={shading_modality_key})')
    library_key, material_name = get_library_key_and_material_name(
        obj__, path_as_mapping=path_as_mapping, shading_modality_key=shading_modality_key)
    # print(library_key, material_name)
    # print()
    if shading_modality_key == 'slot':
        material_pool = list(obj__.data.materials)
        for mat in material_pool:
            if 'liquifeel' in mat.keys():
                # if material_name in mat['liquifeel']['name']:
                if mat['liquifeel']['name'] == material_name:
                    return mat
        # print(f"material {mat_name} not found in the material slots of object {obj__.name}!")
    elif shading_modality_key == 'fill':
        mat = get_geonode_mod_input(obj__, FILL_NG_NAME, 'Liquid Shader')
        return mat

def get_prop_vals(prop_parent, key):
    if isinstance(key, list):
        return {k:getattr(prop_parent, k) for k in key}
    else:
        return getattr(prop_parent, key)

def are_user_defined_patterns_present():
    return any(map(is_user_defined_pattern_image, bpy.data.images))

# def filter_path_by_material_name(redux_input_data, mat_name):
#     return next(filter(
#         lambda path: path['mapping']['material/func_name'] == mat_name,
#         map(lambda path_: path_,
#             redux_input_data['paths'])))

def filter_path_as_mapping_by_material_name(redux_input_data, mat_name):
    return next(filter(
        lambda pam: pam['material/func_name'] == mat_name,
        map(lambda path: path['mapping'],
            redux_input_data['paths'])))

# GEONODE v

def set_vectorial_prop_value(prop_parent, prop_key, value):
    input_ = getattr(prop_parent, prop_key)
    for i in range(len(value)):
        input_[i] = value[i]

def set_scalar_prop_value(prop_parent, prop_key, value):
    # print(f'set_scalar_prop_value({prop_parent}, {prop_key}, {value})')
    setattr(prop_parent, prop_key, value)

def set_prop_value(prop_parent, prop_key, value, ui_input_type):
    if ui_input_type in ['vector', 'color']:
        set_vectorial_prop_value(prop_parent, prop_key, value)
    else: # int, float, bool, string
        set_scalar_prop_value(prop_parent, prop_key, value)

def set_geonode_mod_vectorial_input(mod, identifier, value):
    for i in range(len(value)):
        mod[identifier][i] = value[i]

def set_geonode_mod_scalar_input(mod, identifier, value):
    mod[identifier] = value

geonode_mod_setters = {
    'bool': set_geonode_mod_scalar_input,
    'int': set_geonode_mod_scalar_input,
    'float': set_geonode_mod_scalar_input,
    'color': set_geonode_mod_vectorial_input, # only vec. thus far
    'string': set_geonode_mod_scalar_input,
}

def set_geonode_mod_input_to_value(mod, identifier, value, underlying_input_type):
    geonode_mod_setters[underlying_input_type](
        mod, identifier, value)

# All of the setters below should take these params:
# obj__, material, prop_parent, val, input_field_data, redux_input_data, target_attachment_key, shading_modality_key

def set_geonode_mod_input_to_value__general_params(
        obj__, material, prop_parent, val,
        input_field_data, redux_input_data,
        target_attachment_key, shading_modality_key):
    mod = get_geonodes_mod_by_ng_name(
        obj__, input_field_data['path']['mapping']['group_name']) 
    identifier = get_geonodes_field_identifier(
        mod, input_field_data['underlying_input_name'])
    if input_field_data['ui_input_type'] != input_field_data['underlying_input_type']:
        val = input_field_data['ui_to_underlying_val_mapping'][val]
    set_geonode_mod_input_to_value(
        mod, identifier, val, input_field_data['underlying_input_type'])

def set_geonode_mod_input(obj__, mod_name, input_name, input_type_key, value):
    mod = get_geonodes_modifier(obj__, mod_name)
    identifier = get_geonodes_field_identifier(mod, input_name)
    if input_type_key == 'color':
        set_color_input_field(mod, identifier, value)
    else:
        mod[identifier] = value

# def set_geonode_mod_input__at_prop_update(
#         obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key):
#     # debug_buffer.append(redux_input_data) # DEBUG !!!
#     if 'material/func_name' in redux_input_data['unanimous_path_elems'].keys():
#         # ng_name = redux_input_data['paths'][0]['mapping']['group_name']
#         ng_name = redux_input_data['unanimous_path_elems']['group_name']
#         path = redux_input_data['paths'][0]['list']
#     else: # It's shading input
#         material = get_asset_material(
#             obj__,
#             shading_modality_key=shading_modality_key)
#         # debug_buffer.append(
#         #     {'obj__': obj__,
#         #      'shading_modality_key': shading_modality_key,
#         #      'material': material}
#         # ) # !!! DEBUG
#         mat_name = material['liquifeel']['name']
#         path = filter_path_by_material_name(redux_input_data, mat_name)
#         ng_name = path['mapping']['group_name']
#     input_field_data = index_hierarchy_by_path(INPUT_FIELD_DATA, path)
#     val__ = get_prop_vals(prop_parent, redux_input_data['prop_key'])
#     mod = get_geonodes_mod_by_ng_name(obj__, ng_name)
#     identifier = get_geonodes_field_identifier(mod, redux_input_data['underlying_input_name'])
#     if input_data['type'] == 'color': # or <in ['vector', 'color']> but we have no vectors so far
#         set_color_input_field(mod, identifier, val__)
#     else:
#         mod[identifier] = val__

def set_geonode_mod_input__at_prop_update(
        obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key):
    input_field_data, path = get_input_field_data_and_path(obj__, redux_input_data, shading_modality_key)
    ng_name = path['mapping']['group_name']
    mod = get_geonodes_mod_by_ng_name(obj__, ng_name)
    identifier = get_geonodes_field_identifier(mod, redux_input_data['underlying_input_name'])
    val = get_prop_vals(prop_parent, redux_input_data['prop_key'])
    if input_field_data['ui_input_type'] != input_field_data['underlying_input_type']:
        val = input_field_data['ui_to_underlying_val_mapping'][val]
    geonode_mod_setters[input_field_data['underlying_input_type']](
        mod, identifier, val)

# def set_geonode_mod_input__at_prop_update(
#         obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key):
#     # debug_buffer.append(redux_input_data) # DEBUG !!!
#     if 'material/func_name' in redux_input_data['unanimous_path_elems'].keys():
#         # ng_name = redux_input_data['paths'][0]['mapping']['group_name']
#         ng_name = redux_input_data['unanimous_path_elems']['group_name']
#     else: # It's shading input
#         material = get_asset_material(
#             obj__,
#             shading_modality_key=shading_modality_key)
#         # debug_buffer.append(
#         #     {'obj__': obj__,
#         #      'shading_modality_key': shading_modality_key,
#         #      'material': material}
#         # ) # !!! DEBUG
#         mat_name = material['liquifeel']['name']
#         path_as_mapping = filter_path_as_mapping_by_material_name(redux_input_data, mat_name)
#         ng_name = path_as_mapping['group_name']
#     val__ = get_prop_vals(prop_parent, redux_input_data['prop_key'])
#     mod = get_geonodes_mod_by_ng_name(obj__, ng_name)
#     identifier = get_geonodes_field_identifier(mod, redux_input_data['underlying_input_name'])
#     if input_data['type'] == 'color': # or <in ['vector', 'color']> but we have no vectors so far
#         set_color_input_field(mod, identifier, val__)
#     else:
#         mod[identifier] = val__

def set_shader_node_input(
        obj__, prop_parent, input_name, redux_input_data, material, val=None):
    mat_name = material['liquifeel']['name']
    path_as_mapping = filter_path_as_mapping_by_material_name(redux_input_data, mat_name)
    node_names = path_as_mapping['group_name']
    # This is because an input can affect multiple nodes simultaneouslty
    nodes = [get_material_node(material, node_name.strip()) for node_name in node_names.split(';')]
    # I thik that checking this edge case every time the function runs
    # is not ergonomic. There is a single input of this type in the
    # whole program and the best couse of action would be to handle it
    # on it's own. But i;m letting it be for now because this function
    # is only called for one input (pattern imgtex), because that is
    # the only material node input in the whole program.
    if input_data['type'] == 'imgtex':
        if not val:
            val_data = get_prop_vals(prop_parent, ["pattern_texture_resolution", "pattern_library"])
        else:
            val_data = val
        res_key = val_data['pattern_texture_resolution']
        pat_lib_key = val_data['pattern_library']
        if pat_lib_key == 'user_defined' and are_user_defined_patterns_present():
            img_key = get_prop_vals(prop_parent, "user_pattern_texture")
            img = bpy.data.images[img_key]
            img_tex_fpath = img.filepath_from_user()
            assign_pattern(obj__, nodes, img, img_tex_fpath)
        elif pat_lib_key == 'liquifeel':
            img_key = get_prop_vals(prop_parent, "pattern_texture")
            img_tex_fpath = FPATHS[
                input_data['enum_source_fpath_key']][img_key][res_key]
            img = maybe_load_image(img_tex_fpath)
            assign_pattern(obj__, nodes, img, img_tex_fpath)
    if input_data['type'] == 'color':
        pass
    if input_data['type'] == 'vector':
        pass
    else:
        pass

def set_shader_node_input(
        obj__, prop_parent, input_name, redux_input_data, material, val=None):
    mat_name = material['liquifeel']['name']
    path_as_mapping = filter_path_as_mapping_by_material_name(redux_input_data, mat_name)
    node_names = path_as_mapping['group_name']
    # This is because an input can affect multiple nodes simultaneouslty
    nodes = [get_material_node(material, node_name.strip()) for node_name in node_names.split(';')]
    # I thik that checking this edge case every time the function runs
    # is not ergonomic. There is a single input of this type in the
    # whole program and the best couse of action would be to handle it
    # on it's own. But i;m letting it be for now because this function
    # is only called for one input (pattern imgtex), because that is
    # the only material node input in the whole program.
    if input_data['type'] == 'imgtex':
        if not val:
            val_data = get_prop_vals(prop_parent, ["pattern_texture_resolution", "pattern_library"])
        else:
            val_data = val
        res_key = val_data['pattern_texture_resolution']
        pat_lib_key = val_data['pattern_library']
        if pat_lib_key == 'user_defined' and are_user_defined_patterns_present():
            img_key = get_prop_vals(prop_parent, "user_pattern_texture")
            img = bpy.data.images[img_key]
            img_tex_fpath = img.filepath_from_user()
            assign_pattern(obj__, nodes, img, img_tex_fpath)
        elif pat_lib_key == 'liquifeel':
            img_key = get_prop_vals(prop_parent, "pattern_texture")
            img_tex_fpath = FPATHS[
                input_data['enum_source_fpath_key']][img_key][res_key]
            img = maybe_load_image(img_tex_fpath)
            assign_pattern(obj__, nodes, img, img_tex_fpath)
    if input_data['type'] == 'color':
        pass
    if input_data['type'] == 'vector':
        pass
    else:
        pass

def set_shader_node_input__at_prop_update(
        obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key):
    material = get_asset_material(
        obj__, shading_modality_key=shading_modality_key
    )
    set_shader_node_input(
        obj__, prop_parent, input_name, redux_input_data, material)

def set_shader_ng_input(
        obj__, prop_parent, input_name, redux_input_data, material, val=None):
    if not val:
        val_data = get_prop_vals(prop_parent, redux_input_data['prop_key'])
    else:
        val_data = val
    mat_name = material['liquifeel']['name']
    path_as_mapping = filter_path_as_mapping_by_material_name(redux_input_data, mat_name)
    ng_name = path_as_mapping['group_name']
    ng = get_shader_ng_by_name(material, ng_name)
    field_name = redux_input_data['underlying_input_name']
    underlying_type = redux_input_data['underlying_input_type']
    # if DEV:
    #     debug_buffer.append(ng.inputs)
    if underlying_type == 'color' or underlying_type == 'vector':
        for i in range(len(val_data)):
            ng.inputs[field_name].default_value[i] = val_data[i]
    else:
        ng.inputs[field_name].default_value = val_data

def set_shader_ng_input__at_prop_update(
        obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key):
    material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
    set_shader_ng_input(
        obj__, prop_parent, input_name, redux_input_data, material)

def set_material_attached_input__at_setup(prop_parent, input_name,
                                          obj__, redux_input_data, material, val=None):
    if redux_input_data['unanimous_path_elems']['target_type'] == 'Shader Node':
        set_shader_node_input(
            obj__, prop_parent, input_name, redux_input_data, material, val=val)
    elif redux_input_data['unanimous_path_elems']['target_type'] == 'Shader NG':
        set_shader_ng_input(
            obj__, prop_parent, input_name, redux_input_data, material, val=val)

def set_input__at_prop_update(prop_parent, context, input_name, main_tab_key,
                              target_attachment_key, shading_modality_key):
    obj__ = context.active_object
    redux_input_data = REDUX_INPUT_DATA[main_tab_key][target_attachment_key][input_name]
    if redux_input_data['unanimous_path_elems']['target_type'] == 'GeoNode':
        set_geonode_mod_input__at_prop_update(
            obj__, prop_parent, input_name, redux_input_data,
            target_attachment_key, shading_modality_key)
    if redux_input_data['unanimous_path_elems']['target_type'] == 'Shader Node':
        set_shader_node_input__at_prop_update(
            obj__, prop_parent, input_name, redux_input_data,
            target_attachment_key, shading_modality_key)
    elif redux_input_data['unanimous_path_elems']['target_type'] == 'Shader NG':
        set_shader_ng_input__at_prop_update(
            obj__, prop_parent, input_name, redux_input_data,
            target_attachment_key, shading_modality_key)
    # We probably only need to pass the shading modality key to the
    # shader node setters.  This is because the geonode mods are all
    # together in the same stack regardless of shading modality. This
    # is unfortunate, because it prevents us from giving both the
    # glass and the recipient the same compound material
    # (i.e. beer). But this also means that when the geonode mod input
    # is set (either from it's corresponding slot or fill prop) the
    # same input should be altered regardless.


def set_shader_ng_input_to_value__general_params(
        obj__, material, prop_parent, val,
        input_field_data, redux_input_data,
        target_attachment_key, shading_modality_key):
    mat_name = material['liquifeel']['name']
    ng_name = input_field_data['path']['mapping']['group_name']
    ng = get_shader_ng_by_name(material, ng_name)
    field_name = redux_input_data['underlying_input_name']
    underlying_type = redux_input_data['underlying_input_type']
    if input_field_data['ui_input_type'] != input_field_data['underlying_input_type']:
        val = input_field_data['ui_to_underlying_val_mapping'][val]
    if underlying_type == 'color' or underlying_type == 'vector':
        for i in range(len(val_data)):
            ng.inputs[field_name].default_value[i] = val_data[i]
    else:
        ng.inputs[field_name].default_value = val_data

def set_shader_node_input_to_value__general_params(
        obj__, material, prop_parent, val,
        input_field_data, redux_input_data,
        target_attachment_key, shading_modality_key):
    set_shader_node_input(
        obj__, prop_parent, input_field_data['ui_input_name'], redux_input_data, material, val=val)

underlying_input_setters = {
    'GeoNode': set_geonode_mod_input_to_value__general_params,
    'Shader NG': set_shader_ng_input_to_value__general_params,
    'Shader Node': set_shader_node_input_to_value__general_params,
}

# GEONODE ^
# SHADER_NODE v

# def set_pattern_imgtex

# SHADER_NODE ^
# SHADER_NG v

# SHADER_NG ^

# def set_input_to_default_f(input_data):
#     pass

# def set_input_from_ui_prop_f(input_data):
#     pass

# 'int'
# 'enum'
# 'float'
# 'bool'
# 'float'
# 'color'
# 'bool'
# 'string'
# 'imgtex

# setter_pack_gens = {
#     ('int', 'int'): ,
#     ('enum', 'enum'): ,
#     ('float', 'float'): ,
#     ('bool', 'bool'): ,
#     ('bool', 'float'): ,
#     ('color', 'color'): ,
#     ('enum', 'bool'): ,
#     ('enum', 'string'): ,
#     ('enum', 'imgtex'): ,
# }

# This clojure and it's siblings should only be used on input data
# which does present default values. There are some inputs which
# don't.
def gen_setter__ui_prop_from_default_val(input_field_data):
    if input_field_data['ui_input_default_val'] in ['vector', 'color']:
        setter = set_vectorial_prop_value
    else:
        setter = set_scalar_prop_value
    default_val = input_field_data['ui_input_default_val']
    prop_key = input_field_data['prop_key']
    # odebug_buffer.append({
    #     'setter_type': 'ui_prop_from_default_val',
    #     'prop_key': prop_key,
    #     'default_val': default_val
    # }) # DEBUG !!!
    def set(prop_parent):
        setter(prop_parent, prop_key, default_val)
    return set

# geonode:     obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key
# shader_node: obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key
# shader_ng:   obj__, prop_parent, input_name, redux_input_data, target_attachment_key, shading_modality_key

# Actually, i don't think i need these
# below. gen_setter__ui_prop_from_default_val was the critical one.

def gen_setter__underlying_input_from_ui_prop(input_field_data, shading_modality_key):
    input_name = input_field_data['ui_input_name']
    redux_input_data = index_hierarchy_by_path(
        REDUX_INPUT_DATA, input_field_data['redux_input_data_path'])
    target_type_name = input_field_data['path']['mapping']['target_type']
    prop_key = input_field_data['prop_key']
    setter = underlying_input_setters[target_type_name]
    target_attachment_key = get_target_attachment_key[target_type_name]
    def set(prop_parent, context):
        obj__ = context.active_object
        material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
        val = getattr(prop_parent, prop_key)
        setter(obj__, material, prop_parent, val, input_field_data, redux_input_data, target_attachment_key, shading_modality_key)
    return set

# def gen_setter__underlying_input_from_ui_prop(input_field_data, shading_modality_key):
#     input_name = input_field_data['ui_input_name']
#     redux_input_data = index_hierarchy_by_path(
#         REDUX_INPUT_DATA, input_field_data['redux_input_data_path'])
#     target_type_name = input_field_data['path']['mapping']['target_type']
#     prop_key = input_field_data['prop_key']
#     setter = underlying_input_setters[target_type_name]
#     target_attachment_key = get_target_attachment_key[target_type_name]
#     def set(prop_parent, obj__, material):
#         # obj__ = context.active_object
#         # material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
#         val = getattr(prop_parent, prop_key)
#         setter(obj__, material, prop_parent, val, input_field_data, redux_input_data, target_attachment_key, shading_modality_key)
#     return set

def gen_setter__underlying_input_to_default(input_field_data, shading_modality_key):
    input_name = input_field_data['ui_input_name']
    redux_input_data = index_hierarchy_by_path(
        REDUX_INPUT_DATA, input_field_data['redux_input_data_path'])
    target_type_name = input_field_data['path']['mapping']['target_type']
    prop_key = input_field_data['prop_key']
    setter = underlying_input_setters[target_type_name]
    target_attachment_key = get_target_attachment_key[target_type_name]
    val = input_field_data['underlying_input_default_val']
    def set(prop_parent, obj__, material):
        # obj__ = context.active_object
        # material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
        setter(obj__, material, prop_parent, val, input_field_data, redux_input_data, target_attachment_key, shading_modality_key)
    return set

input_types_wo_default_ui_prop_setter = ['imgtex']
def gen_input_setters(input_field_data):
    setters = {}
    if 'ui_input_default_val' in input_field_data.keys() and input_field_data[
            'ui_input_default_val'] not in input_types_wo_default_ui_prop_setter:
        ui_prop_from_default_setter = gen_setter__ui_prop_from_default_val(
            input_field_data)
        setters['ui_prop_from_default'] = ui_prop_from_default_setter
    per_shading_modality = {'slot': {}, 'fill': {}}
    for shading_modality_key in ['slot', 'fill']:
        underlying_from_ui_prop_setter = gen_setter__underlying_input_from_ui_prop(
            input_field_data, shading_modality_key)
        per_shading_modality[shading_modality_key]['underlying_from_ui_prop'] = underlying_from_ui_prop_setter
        if 'underlying_input_default_val' in input_field_data.keys():
            underlying_to_default_setter = gen_setter__underlying_input_to_default(
                input_field_data, shading_modality_key)
            per_shading_modality[shading_modality_key]['underlying_from_default'] = underlying_to_default_setter
    setters['per_shading_modality'] = per_shading_modality
    return setters

for main_tab_key, main_tab_data in REDUX_INPUT_DATA.items():
    for target_attachment_key, target_attachment_data in main_tab_data.items():
        for input_name, redux_input_data in target_attachment_data.items():
            for path in [p['list'] for p in redux_input_data['paths']]:
                # augment INPUT_FIELD_DATA at path with setters
                input_field_data = index_hierarchy_by_path(INPUT_FIELD_DATA, path)
                input_field_data['setters'] = gen_input_setters(input_field_data)

#!# MANAGERS --------------------------------------------------------------------------------
## DYNAMIC DATA --------------------------------------------------------------------------------

## PREVIEW -----------------------------

def new_preview_collection(*args):
    preview = previews.new()
    if len(args) == 1:
        path = args[0]
        preview.images_location = str(path)
    return preview

def load_image_and_get_id(preview_collection, fpath, img_key):
    img = preview_collection.load(
        img_key,
        str(fpath),
        'IMAGE')
    return img.icon_id

def load_images_and_assemble_ids(preview_collection, filepath_data, fpath_preprocess_f=None, img_key_f=None):
    ids = {}
    for img_key in filepath_data.keys():
        if fpath_preprocess_f:
            fpath = fpath_preprocess_f(filepath_data, img_key)
        else:
            fpath = filepath_data[img_key]
        k = img_key_f(img_key) if img_key_f else img_key
        ids[k] = load_image_and_get_id(preview_collection,
                                       fpath,
                                       k)
    return ids

preview_collections = {}
preview_img_ids = {}

preview_collections['icons'] = new_preview_collection(FPATHS['icons_root'])
preview_img_ids['icons'] = load_images_and_assemble_ids(preview_collections['icons'],
                                                        FPATHS['icons'])

preview_collections['material_thumbnails'] = new_preview_collection(FPATHS['material_thumbnails_root'])
preview_img_ids['material_thumbnails'] = load_images_and_assemble_ids(preview_collections['material_thumbnails'],
                                                                      FPATHS['material_thumbnails'])

preview_collections['pattern_thumbnails'] = new_preview_collection(FPATHS['recipient_pattern_textures_root'])
preview_img_ids['pattern_thumbnails'] = load_images_and_assemble_ids(
    preview_collections['pattern_thumbnails'],
    FPATHS['recipient_pattern_textures'],
    fpath_preprocess_f=lambda fpath_data, key: fpath_data[key]['256'])

# These data structures are to be populated dynamically. At init time, they are empty.
preview_collections['user_defined_pattern_thumbnails'] = new_preview_collection()
preview_img_ids['user_defined_pattern_thumbnails'] = {}

# def get_recipient_asset_key_from_thumbnail_name(thumbnail_name):
#     if preview_recipient_asset_names[thumbnail_name]:
#         return preview_recipient_asset_names[thumbnail_name]
#     else:
#         return thumbnail_name
def get_recipient_asset_key_from_thumbnail_name(thumbnail_name):
    # print(f'def get_recipient_asset_key_from_thumbnail_name({thumbnail_name}):')
    return next(filter(lambda key: RECIPIENT_ASSET_NAME_DATA[key]['thumbnail'] == thumbnail_name,
                       RECIPIENT_ASSET_NAME_DATA.keys()))

preview_collections['recipient_asset_thumbnails'] = new_preview_collection(FPATHS['recipient_asset_thumbnails_root'])
preview_img_ids['recipient_asset_thumbnails'] = load_images_and_assemble_ids(
    preview_collections['recipient_asset_thumbnails'],
    FPATHS['recipient_asset_thumbnails'],
    img_key_f=get_recipient_asset_key_from_thumbnail_name)

preview_data = {
    'collections': preview_collections,
    'ids': preview_img_ids
}

# print()
# print('preview_data')
# pprint(preview_data)
# print()

## PREDICATES ------------------------------------------------------

def is_lqfl_modifier(mod):
    return has_lqfl_data_structure_attached(mod)

# 21_nov_2023
def has_geonode_mod_name_f(name):
    def f(mod):
        if mod.type == 'NODES' and mod.node_group:
            v = mod.node_group.name == name
        else:
            v = False
        # print(f'has_geonode_mod_name_f({name})({mod.name}): {v}')
        return v
    return f

# # 16_nov_2023
# def has_geonode_mod_name_f(name):
#     def f(mod):
#         if mod.type == 'NODES':
#             return mod.node_group.name == name
#         return False
#     return f

is_mod_select_outer = has_geonode_mod_name_f(SELECT_OUTER_NG_NAME)
is_mod_main_fill = has_geonode_mod_name_f(FILL_NG_NAME)
is_mod_hide_recipient = has_geonode_mod_name_f(HIDE_RECIPIENT_NG_NAME)

def is_obj_filled(obj__):
    has_fill_mod = any([is_mod_main_fill(mod) for mod in obj__.modifiers])
    has_hide_recipient_mod = any([is_mod_hide_recipient(mod) for mod in obj__.modifiers])
    return has_fill_mod and has_hide_recipient_mod

# 21_nov_2023
def is_material_from_liquifill_library(material, library_key):
    if material and 'liquifeel' in material.keys():
        v = material['liquifeel']['library'] == library_key
    else:
        v = False
    # print(f'is_material_from_liquifill_library({material.name}, {library_key}): {v}')
    return v

# # 16_nov_2023
# def is_material_from_liquifill_library(material, library_key):
#     if 'liquifeel' in material.keys():
#         return material['liquifeel']['library'] == library_key
#     else:
#         return False

# 21_nov_2023
def is_obj_library_slot_shaded(obj__, library_key):
    if obj__.data.materials:
        # filter out the None material Slots (empty)
        materials = filter(bool, obj__.data.materials)
        v = any(
            [is_material_from_liquifill_library(mat, library_key) for mat in materials])
        # print(f'is_obj_library_slot_shaded({obj__.name}): {v}')
        return v
    return False

# # 16_nov_2023
# def is_obj_library_slot_shaded(obj__, library_key):
#     if obj__.data.materials:
#         if obj__.data.materials:
#             return any([is_material_from_liquifill_library(mat, library_key) for mat in obj__.data.materials])
#     return False

def is_obj_library_fill_shaded(obj__, library_key):
    mat = get_geonode_mod_input(obj__, FILL_NG_NAME, 'Liquid Shader')
    if mat:
        return is_material_from_liquifill_library(mat, library_key)
    return False

def is_obj_library_shaded(obj__, library_key, shading_modality_key):
    if shading_modality_key == 'slot':
        return is_obj_library_slot_shaded(obj__, library_key)
    elif shading_modality_key == 'fill':
        return is_obj_library_fill_shaded(obj__, library_key)

def has_any_lqfl_tagged_data_attached(obj__):
    return any([key in obj__.keys() for key in LQFL_OBJECT_TAG_ATTACHED_DATA_KEYS])

# We neet to check if it has attached data too. there are instances where the object is library slot shaded
# As it has kept it's shader and the shade is part of the lqfl library, but the asset has been applied
# and thus, we don't want to display the shading ui or any ui for that matter.
def is_obj_liquifeel_asset(obj__):
    if obj__.type == 'MESH':
        vs = [is_obj_filled(obj__)]
        for lib_key in INPUT_FIELD_DATA['shading'].keys():
            vs.append(
                is_obj_library_slot_shaded(obj__, lib_key))
        return any(vs) and has_any_lqfl_tagged_data_attached(obj__)

def has_lqfl_data_structure_attached(mod):
    try:
        v = 'liquifeel' in mod.node_group.keys()
        return v
    except:
        return False

def is_mod_shader_aux__fs(prev_mat_library_key, prev_mat_name):
    return [
        lambda mod: mod.type == 'NODES',
        has_lqfl_data_structure_attached,
        lambda mod: all([key in mod.node_group['liquifeel'].keys() for key in ['library', 'material_name']]),
        lambda mod: all(
            map(lambda kv: mod.node_group['liquifeel'][kv[0]] == kv[1],
                zip(['library', 'material_name'],
                    [prev_mat_library_key, prev_mat_name])))
    ]

def is_modifier_shader_auxilliary_f(prev_mat_library_key, prev_mat_name):
    disc_fs = is_mod_shader_aux__fs(prev_mat_library_key, prev_mat_name)
    def is_it__(mod):
        for f in disc_fs:
            if not(f(mod)):
                return False
        return True
    return is_it__

def has_dict_path(data, keys):
    if len(keys) == 0:
        return True
    elif keys[0] not in data.keys():
        return False
    else:
        return has_dict_path(data[keys[0]], keys[1:])

# 21_nov_2023
def is_user_defined_pattern_image(im):
    if im and 'liquifeel' in im.keys():
        v = im['liquifeel'] == 'user_defined'
    else:
        v = False
    # print(f'is_user_defined_pattern_image({im.name}): {v}')
    return v

# # 16_nov_2023
# def is_user_defined_pattern_image(im):
#     if 'liquifeel' in im.keys():
#         return im['liquifeel'] == 'user_defined'
#     else:
#         return False

def modifier_slot_vs_shade_discriminator_f(shading_modality_key):
    def disc__(mod):
        if mod and has_dict_path(mod, ['liquifeel', 'slot_vs_fill']):
            return mod.node_group['liquifeel']['liquifeel']['shading_modality_key']
        else:
            return False
    return disc__

## PROPERTIES --------------------------------------------------------------------------------

def gen_pattern_imgtex_img_items(instance, context):
    items = []
    for pattern_key, pattern_icon_id in preview_data['ids']['pattern_thumbnails'].items():
        items.append(
            (
                pattern_key, # key
                pattern_key, # name
                name_from_key(pattern_key), # description
                pattern_icon_id, # icon_id
                len(items) # order index
            )
        )
    return items

imgtex_res_items = [
    ('256', '256', '256'),
    ('512', '512', '512'),
    ('1k', '1K', '1K'),
    ('2k', '2K', '2K'),
]
def gen_pattern_imgtex_res_items(instance, context):
    return imgtex_res_items

def items_from_data(items_data):
    items = []
    for img_fname, data in items_data.items():
        items.append(
            (
                img_fname, # key
                img_fname, # name
                img_fname, # description
                data['thumbnail_id'], # icon_id
                len(items) # order index
            ))
    return items

def get_loaded_user_defined_pattern_images():
    return list(filter(is_user_defined_pattern_image,
                       bpy.data.images))

def gen_pattern_user_imgtex_img_items__(items_data):
    preview_collection = preview_data['collections']['user_defined_pattern_thumbnails']
    imgs = get_loaded_user_defined_pattern_images()
    for img in imgs:
        img_key = img.name
        if img_key not in items_data.keys():
            img_fpath = img.filepath_from_user()
            if img_key not in preview_collection.keys():
                preview_image = preview_collection.load(
                    img_key,
                    str(img_fpath),
                    'IMAGE')
            else:
                preview_image = preview_collection.get(img_key)
            items_data[img_key] = {
                'filepath': img_fpath,
                'thumbnail_id': preview_image.icon_id
            }
    return items_from_data(items_data)

def gen_pattern_user_imgtex_img_items_f():
    items_data = {}
    def f(instance, context):
        try:
            return gen_pattern_user_imgtex_img_items__(items_data)
        except AttributeError as e:
            # empty preview collection
            return items_from_data(items_data)
    return f

gen_pattern_user_imgtex_img_items = gen_pattern_user_imgtex_img_items_f()

def get_object_uv_maps_items_f():
    def f(slf, context):
        obj__ = context.active_object
        items = []
        for uv_layer in obj__.data.uv_layers:
            items.append((uv_layer.name, uv_layer.name, uv_layer.name))
        return items
    return f

def get_object_vertex_groups_items_f():
    def f(slf, context):
        obj__ = context.active_object
        items = []
        for vg in obj__.vertex_groups:
            items.append((vg.name, vg.name, vg.name))
        return items
    return f

@undo_push(2)
def lip_threshold_update(slf, context):
    if is_obj_filled(context.active_object):
        set_geonode_mod_input(
            context.active_object, FILL_NG_NAME, 'Lip Threshold', 'float', getattr(slf, 'lip_threshold'))
    set_geonode_mod_input(
        context.active_object, SELECT_OUTER_NG_NAME, 'Lip Threshold', 'float', getattr(slf, 'lip_threshold'))

## NEW PROPERTY SYSTEM (EXECD) ---------------------

def gen_update_f_name(redux_input_data, tab_key, target_attachment_key):
    return f'{tab_key}_{target_attachment_key}_{redux_input_data["prop_key"]}_updt'

# def gen_update_f_name(redux_input_data, tab_key, target_attachment_key):
#     group_name_key = get_prop_key(path_as_mapping['group_name'])
#     target_type_key = get_prop_key(path_as_mapping['target_type'])
#     if isinstance(input_data['key'], list):
#         input_key = input_data['key'][0]
#     else:
#         input_key = input_data['key']
#     return f'{input_key}_{group_name_key}_{target_type_key}_updt'

def gen_update_f_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
    update_code = f'''
@undo_push(2)
def {gen_update_f_name(redux_input_data, tab_key, target_attachment_key)}(slf, context):
    set_input__at_prop_update(
        slf,
        context,
        \'{input_name}\',
        \'{tab_key}\',
        \'{target_attachment_key}\',
        \'{shading_modality_key}\')'''
    return update_code

def gen_int_prop_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
    if DEV:
        pprint(redux_input_data)
    update_f_code = gen_update_f_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)
    # # I might need to use the bounds data if i want to implement sliders.
    bounds_data = redux_input_data['bounds']
    if 'underlying_input_subtype' in redux_input_data:
        subtype = redux_input_data['underlying_input_subtype'].upper()
    else:
        subtype = 'NONE'
    prop_rows = [
        f'    {redux_input_data["prop_key"]}: bpy.props.IntProperty(',
        f'        name=\'{input_name}\',',
        # f'        default={input_data["default_val"]},',
        f'        min={bounds_data["min"]},',
        f'        soft_min={bounds_data["min"]},',
        f'        max={bounds_data["max"]},',
        f'        soft_max={bounds_data["max"]},',
        f'        subtype=\'{subtype}\',',
        f'        update={gen_update_f_name(redux_input_data, tab_key, target_attachment_key)},',
        f'    )',
    ]
    prop_code = '\n'.join(prop_rows)
    return prop_code, update_f_code

# Apparently, for floats I've used custom functions defined
# classically, maybe i should implement this functionality for all
# types.
def gen_float_prop_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
    # This code chunk commented below was for using custom defined
    # functions (functions defined manually in this file (like for
    # example lip_threshold_update)) as the update functions of the
    # synthetically defined property (synthetized by this function
    # (gen_float_prop_code)). input_data was not referenced before
    # being accessed and such, the input_data variable was containing
    # some residual data which didn't have the 'update_f' key in
    # it. If custom functions are needed, this needs to be rectified,
    # the redux_input_data strcture has the path to access the
    # required data.
    # if DEV:
    #     debug_buffer.append(redux_input_data) # DEBUG
    # # input_data = index_hierarchy_by_path(INPUT_FIELD_DATA, redux_input_data['paths'][0]['list'])
    # # print(input_data.keys()) # DEBUG
    # if not('update_f' in input_data.keys()):
    #     update_f_code = gen_update_f_code(
    #         input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)
    #     update_func_name = gen_update_f_name(redux_input_data, tab_key, target_attachment_key)
    # else:
    #     update_f_code = []
    #     update_func_name = input_data['update_f']
    update_f_code = gen_update_f_code(
        input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)
    # if DEV:
    #     pprint(redux_input_data)
    update_func_name = gen_update_f_name(redux_input_data, tab_key, target_attachment_key)
    bounds_data = redux_input_data['bounds']
    if 'underlying_input_subtype' in redux_input_data:
        subtype = redux_input_data['underlying_input_subtype'].upper()
    else:
        subtype = 'NONE'
    prop_rows = [
        f'    {redux_input_data["prop_key"]}: bpy.props.FloatProperty(',
        f'        name=\'{input_name}\',',
        f'        update={update_func_name},',
        # f'        default={input_data["default_val"]},',
        f'        min={bounds_data["min"]},',
        f'        soft_min={bounds_data["min"]},',
        f'        max={bounds_data["max"]},',
        f'        soft_max={bounds_data["max"]},',
        f'        subtype=\'{subtype}\',',
        f'        precision=3,',
        f'        step=0.1,',
        f'    )',
    ]
    prop_code = '\n'.join(prop_rows)
    return prop_code, update_f_code

def gen_bool_prop_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
    update_f_code = gen_update_f_code(
        input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)
    prop_rows = [
        f'    {redux_input_data["prop_key"]}: bpy.props.BoolProperty(',
        f'        name=\'{input_name}\',',
        f'        update={gen_update_f_name(redux_input_data, tab_key, target_attachment_key)},',
        # f'        default={input_data["default_val"]}',
        f'    )'
    ]
    prop_code = '\n'.join(prop_rows)
    return prop_code, update_f_code

def gen_vector_prop_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
    update_f_code = gen_update_f_code(
        input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)
    prop_rows = [
        f'    {redux_input_data["prop_key"]}: bpy.props.FloatVectorProperty(',
        f'        name=\'{input_name}\',',
        f'        update={gen_update_f_name(redux_input_data, tab_key, target_attachment_key)},',
        f'        min=0.0, max=1.0, soft_min=0.0, soft_max=1.0,',
        f'        subtype=\'XYZ\',',
        f'    )',
    ]
    prop_code = '\n'.join(prop_rows)
    return prop_code, update_f_code

def gen_color_prop_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
    update_f_code = gen_update_f_code(
        input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)
    prop_rows = [
        f'    {redux_input_data["prop_key"]}: bpy.props.FloatVectorProperty(',
        f'        name=\'{input_name}\',',
        f'        update={gen_update_f_name(redux_input_data, tab_key, target_attachment_key)},',
        # f'        default={tuple(input_data["default_val"])},',
        f'        min=0.0, max=1.0, soft_min=0.0, soft_max=1.0,',
        f'        subtype=\'COLOR\',',
        f'    )',
    ]
    prop_code = '\n'.join(prop_rows)
    return prop_code, update_f_code

# !!!
# def gen_enum_prop_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
#     if DEV:
#         pprint(redux_input_data)
#     update_f_code = gen_update_f_code(
#         input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)
#     # if 'default_val' in redux_input_data
#     prop_rows = [
#         f'    {redux_input_data["prop_key"]}: bpy.props.EnumProperty(',
#         f'        name=\'{input_name}\',',
#         f'        update={gen_update_f_name(redux_input_data, tab_key, target_attachment_key)},',
#         f'        default={tuple(redux_input_data["default_val"])},',
#         f'        items={items},',
#         f'    )',
#     ]
#     recipient_asset: bpy.props.EnumProperty(
#         name='Fill Material',
#         items=recipient_asset_items)

prop_gens_by_type = {
    'int': gen_int_prop_code,
    'float': gen_float_prop_code,
    'bool': gen_bool_prop_code,
    # 'vector': gen_vector_prop_code,
    # 'string': gen_string_prop_code,
    'color': gen_color_prop_code,
    # 'enum': gen_enum_prop_code, # !!!
    # 'bool_to_float': gen_bool_prop_code,
    # 'imgtex': gen_imgtex_props_code,
}
man_def_underlying_input_types = ['string', 'enum', 'imgtex']

def gen_prop_code(input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key):
    return prop_gens_by_type[redux_input_data['ui_input_type']](
        input_name, redux_input_data, tab_key, target_attachment_key, shading_modality_key)

# # The input property hierarchy follows this outline
# # - ObjectAttached
# #   - Geometry
# #     - Synthetic
# #     - Manual
# #   - Shading
# #     - Synthetic
# #     - Manual
# # - MaterialAttached
# #  - Slot
# #    - Synthetic
# #    - Manual
# #  - Fill
# #    - Synthetic
# #    - Manual

# object_attached_prop_hierarchy_karte = {
#     # ObjectAttached_InputProps
#     'liquifeel_input_field_props': {
#         # ObjectAttached_Geometry_InputProps
#         'geometry': {
#             # ObjectAttached_Synthetic_Geometry_InputProps
#             'synthetic': None,
#             # ObjectAttached_Manual_Geometry_InputProps
#             'manual': None
#         },
#         # ObjectAttached_Shading_InputProps
#         'shading': {
#             # ObjectAttached_Synthetic_Shading_InputProps
#             'synthetic': {},
#             # ObjectAttached_Manual_Shading_InputProps
#             'manual': {}
#         }
#     }
# }

# material_attached_prop_hierarchy_karte = {
#     # MaterialAttached_InputProps
#     'liquifeel_input_field_props': {
#         # MaterialAttached_SlotShading_InputProps
#         'slot': {
#             # MaterialAttached_Synthetic_SlotShading_InputProps
#             'synthetic': None,
#             # MaterialAttached_Manual_SlotShading_InputProps
#             'manual': None
#         },
#         # MaterialAttached_FillShading_InputProps
#         'fill': {
#             # MaterialAttached_Synthetic_FillShading_InputProps
#             'synthetic': {},
#             # MaterialAttached_Manual_FillShading_InputProps
#             'manual': {}
#         }
#     }
# }

# The input property hierarchy follows this outline
# - ObjectAttached
#   - Geometry
#     - Synthetic
#     - Manual
#   - Shading
#     - Synthetic
#     - Manual
# - MaterialAttached
#  - Slot
#    - Synthetic
#    - Manual
#  - Fill
#    - Synthetic
#    - Manual

object_attached_prop_hierarchy_karte = {
    # ObjectAttached_InputProps
    'liquifeel_input_field_props': {
        # ObjectAttached_Geometry_InputProps
        'geometry': {
            # ObjectAttached_Synthetic_Geometry_InputProps
            'synthetic': None,
            # ObjectAttached_Manual_Geometry_InputProps
            'manual': None
        },
        # ObjectAttached_Shading_InputProps
        'shading': {
            # ObjectAttached_SlotShading_InputProps
            'slot': {
                # ObjectAttached_Synthetic_SlotShading_InputProps
                'synthetic': {},
                # ObjectAttached_Manual_SlotShading_InputProps
                'manual': {}
            },
            # ObjectAttached_FillShading_InputProps
            'fill': {
                # ObjectAttached_Synthetic_FillShading_InputProps
                'synthetic': {},
                # ObjectAttached_Manual_FillShading_InputProps
                'manual': {}
            },
        }
    }
}

material_attached_prop_hierarchy_karte = {
    # MaterialAttached_InputProps
    'liquifeel_input_field_props': {
        # MaterialAttached_SlotShading_InputProps
        'slot': {
            # MaterialAttached_Synthetic_SlotShading_InputProps
            'synthetic': None,
            # MaterialAttached_Manual_SlotShading_InputProps
            'manual': None
        },
        # MaterialAttached_FillShading_InputProps
        'fill': {
            # MaterialAttached_Synthetic_FillShading_InputProps
            'synthetic': {},
            # MaterialAttached_Manual_FillShading_InputProps
            'manual': {}
        }
    }
}

def get_declaration_modality_key(redux_input_data):
    if redux_input_data['ui_input_type'] in prop_gens_by_type.keys():
        return 'synthetic'
    else:
        return 'manual'

def declare_and_register_synthetic_prop_parent(
        main_tab_key, target_attachment_key, shading_modality_key=None):
    # debug_buffer.append({
    #     'f': 'declare_and_register_synthetic_prop_parent',
    #     'main_tab_key': main_tab_key,
    #     'target_attachment_key': target_attachment_key,
    #     'shading_modality_key': shading_modality_key})
    properties_code = []
    update_funcs_code = []
    for input_name, redux_input_data in REDUX_INPUT_DATA[main_tab_key][target_attachment_key].items():
        if redux_input_data['ui_input_type'] in prop_gens_by_type.keys():
            prop_declaration_code, update_func_declaration_code = gen_prop_code(
                input_name, redux_input_data, main_tab_key, target_attachment_key, shading_modality_key)
            properties_code.append(prop_declaration_code)
            update_funcs_code.append(update_func_declaration_code)
    target_attachment_name = ''.join([e.capitalize() for e in target_attachment_key.split('_')])
    main_tab_name = main_tab_key.capitalize()
    code_blocks = []
    code_blocks.extend(update_funcs_code)
    lines = []
    if target_attachment_key == 'material_attached':
        shading_modality_name = shading_modality_key.capitalize()
        class_name = f'{target_attachment_name}_Synthetic_{shading_modality_name}Shading_InputProps'
    elif target_attachment_key == 'object_attached':
        if main_tab_key == 'geometry':
            class_name = f'{target_attachment_name}_Synthetic_{main_tab_key.capitalize()}_InputProps'
        elif main_tab_key == 'shading':
            shading_modality_name = shading_modality_key.capitalize()
            class_name = f'{target_attachment_name}_Synthetic_{shading_modality_name}Shading_InputProps'
    # if target_attachment_key == 'material_attached':
    #     shading_modality_name = shading_modality_key.capitalize()
    #     class_name = f'{target_attachment_name}_Synthetic_{shading_modality_name}Shading_InputProps'
    # elif target_attachment_key == 'object_attached':
    #     class_name = f'{target_attachment_name}_Synthetic_{main_tab_key.capitalize()}_InputProps'
    lines.append(
        f'\nclass {class_name}(bpy.types.PropertyGroup):')
    if properties_code:
        lines.extend(properties_code)
    else:
        lines.append('    pass')
        print(f'\nclass {class_name} has no properties!\n')
    lines.append(
        f'registerable_classes.append({class_name})'
    )
    prop_parent_code = "\n".join(lines)
    code_blocks.append(prop_parent_code)
    code = "\n".join(code_blocks)
    cc = compile(code, '<string>', 'exec')
    exec(cc, globals())

# key_chain: ['liquifeel_input_field_props', 'geometry', 'synthetic']
# path: liquifeel_input_field_props.geometry.synthetic
# class ObjectAttached_Synthetic_Geometry_InputProps
declare_and_register_synthetic_prop_parent(
        'geometry', 'object_attached')
# class ObjectAttached_Synthetic_Geometry_InputProps(bpy.types.PropertyGroup):
#     pass
# registerable_classes.append(ObjectAttached_Synthetic_Geometry_InputProps)

# This is not the main actor of the opening-shape selector
# functionality. the main function this property serves is to hide /
# unhide the lip threshold control. Setting it to 0 when deactivated
# is just a side.
def opening_shape_mandef_update(slf, context):
    if getattr(slf, 'opening_shape') == 'straight':
        setattr(slf, 'lip_threshold', 0.0)

@undo_push(2)
def hide_liquid_update(slf, context):
    obj__ = context.active_object
    mod = get_geonodes_mod_by_ng_name(obj__, FILL_NG_NAME)
    mod.show_viewport = not(getattr(slf, 'hide_liquid'))

@undo_push(2)
def hide_recipient_update(prop_parent, context):
    obj__ = context.active_object
    mod = get_geonodes_mod_by_ng_name(obj__, HIDE_RECIPIENT_NG_NAME)
    identifier = get_geonodes_field_identifier(
        mod, 'Hide Recipient')
    val = getattr(prop_parent, 'hide_recipient')
    mod[identifier] = val

# key_chain: ['liquifeel_input_field_props', 'geometry', 'manual']
# path: liquifeel_input_field_props.geometry.manual
class ObjectAttached_Manual_Geometry_InputProps(bpy.types.PropertyGroup):
    opening_shape: bpy.props.EnumProperty(
        name='Opening Shape',
        update=opening_shape_mandef_update,
        default='straight',
        items=[
            ('straight', 'Straight', 'The mouth of the recipient has no kink.'),
            ('irregular', 'Irregular', 'The mouth of the recipient has a kink.')])
    hide_recipient: bpy.props.BoolProperty(
        name='Hide Recipient',
        update=hide_recipient_update,
        default=False)
    hide_liquid: bpy.props.BoolProperty(
        name='Hide Liquid',
        update=hide_liquid_update,
        default=False)
registerable_classes.append(ObjectAttached_Manual_Geometry_InputProps)

# key_chain: ['liquifeel_input_field_props', 'geometry']
# path: liquifeel_input_field_props.geometry
class ObjectAttached_Geometry_InputProps(bpy.types.PropertyGroup):
    synthetic: bpy.props.PointerProperty(type=ObjectAttached_Synthetic_Geometry_InputProps)
    manual: bpy.props.PointerProperty(type=ObjectAttached_Manual_Geometry_InputProps)
registerable_classes.append(ObjectAttached_Geometry_InputProps)

# key_chain: ['liquifeel_input_field_props', 'shading', 'slot', 'synthetic']
# path: liquifeel_input_field_props.shading.slot.synthetic
# class ObjectAttached_Synthetic_SlotShading_InputProps
declare_and_register_synthetic_prop_parent(
        'shading', 'object_attached', shading_modality_key='slot')
# class ObjectAttached_Synthetic_SlotShading_InputProps(bpy.types.PropertyGroup):
#     pass
# registerable_classes.append(ObjectAttached_Synthetic_SlotShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'shading', 'fill', 'synthetic']
# path: liquifeel_input_field_props.shading.slot.synthetic
# class ObjectAttached_Synthetic_FillShading_InputProps
declare_and_register_synthetic_prop_parent(
        'shading', 'object_attached', shading_modality_key='fill')
# class ObjectAttached_Synthetic_FillShading_InputProps(bpy.types.PropertyGroup):
#     pass
# registerable_classes.append(ObjectAttached_Synthetic_FillShading_InputProps)

# # key_chain: ['liquifeel_input_field_props', 'shading', 'synthetic']
# # path: liquifeel_input_field_props.shading.synthetic
# # class ObjectAttached_Synthetic_Shading_InputProps
# declare_and_register_synthetic_prop_parent(
#         'shading', 'object_attached')
# # class ObjectAttached_Synthetic_Shading_InputProps(bpy.types.PropertyGroup):
# #     pass
# # registerable_classes.append(ObjectAttached_Synthetic_Shading_InputProps)

material_library_items = [
    ('solids', 'Solids', 'Shade object with materials from Liquifeel\'s solids library.'),
    ('liquids', 'Liquids', 'Shade object with materials from Liquifeel\'s liquid library.'),
    ('scene', 'Scene materials', 'Shade object with materials present in the scene.')
]

liquids_shader_items = []
for mat_name in INPUT_FIELD_DATA['shading']['liquids'].keys():
    liquids_shader_items.append((
        mat_name, mat_name,
        mat_name,
        # json.dumps(INPUT_FIELD_DATA['shading']['liquids'][mat_name],
        #            indent=2, sort_keys=True),
        preview_data['ids']['material_thumbnails'][
            key_from_name(mat_name)],
        len(liquids_shader_items)
    ))

solids_shader_items = []
for mat_name in INPUT_FIELD_DATA['shading']['solids'].keys():
    solids_shader_items.append((
        mat_name, mat_name,
        mat_name,
        # json.dumps(INPUT_FIELD_DATA['shading']['solids'][mat_name],
        #            indent=2, sort_keys=True),
        preview_data['ids']['material_thumbnails'][
            key_from_name(mat_name)],
        len(solids_shader_items)
    ))

def scene_shader_items(instance, context):
    try:
        items = []
        for mat in bpy.data.materials:
            icon_val = bpy.types.UILayout.icon(mat)
            if not(icon_val):
                icon_val = 'MATERIAL'
            items.append((
                mat.name, mat.name, mat.name,
                icon_val, len(items)
            ))
        return items
    except:
        return []

# @undo_push(2)
def slot_library_update(slf, context):
    pass

@undo_push(2)
def slot_shading_material_update(slf, context):
    obj__ = context.active_object
    library_key = getattr(slf, 'library')
    material_name = getattr(slf, f'{library_key}_material')
    slot_shade(context, obj__, library_key, material_name)

@undo_push(2)
def scene_slot_shading_material_update(slf, context):
    obj__ = context.active_object
    material_name = getattr(slf, 'scene_material')
    slot_shade(context, obj__, 'scene', material_name)


# key_chain: ['liquifeel_input_field_props', 'shading', 'slot', 'manual', 'material_selector']
# path: liquifeel_input_field_props.shading.slot.manual.material_selector
class ObjectAttached_Manual_SlotShading_MatSel_InputProps(
        bpy.types.PropertyGroup):
    library: bpy.props.EnumProperty(
        name='Opening Shape',
        update=slot_library_update,
        default='solids',
        items=material_library_items)
    # pattern_library: bpy.props.EnumProperty(
    #     name='Pattern Library',
    #     update=pattern_library_update,
    #     default='liquifeel',
    #     items=[
    #         ('liquifeel', 'Liquifeel', 'Patterns packaged with Liquifeel'),
    #         ('user_defined', 'User Defined', 'Patterns added by the user.'),
    #     ])
    liquids_material: bpy.props.EnumProperty( # formerly library_liquids_material
        name='Slot Material',
        update=slot_shading_material_update,
        default='Water',
        items=liquids_shader_items)
    solids_material: bpy.props.EnumProperty( # formerly library_solids_material
        name='Slot Material',
        update=slot_shading_material_update,
        items=solids_shader_items)
    scene_material: bpy.props.EnumProperty( # formerly scene_material
        name='Slot Material',
        update=scene_slot_shading_material_update,
        items=scene_shader_items)
registerable_classes.append(
    ObjectAttached_Manual_SlotShading_MatSel_InputProps)

# @undo_push(2)
def fill_library_update(slf, context):
    pass

@undo_push(2)
def fill_shading_material_update(slf, context):
    obj__ = context.active_object
    library_key = getattr(slf, 'library')
    material_name = getattr(slf, f'{library_key}_material')
    fill_shade(context, obj__, library_key, material_name)

@undo_push(2)
def scene_fill_shading_material_update(slf, context):
    obj__ = context.active_object
    material_name = getattr(slf, 'scene_material')
    fill_shade(context, obj__, 'scene', material_name)

# key_chain: ['liquifeel_input_field_props', 'shading', 'manual', 'fill_material_selector']
# path: liquifeel_input_field_props.shading.manual.fill_material_selector
class ObjectAttached_Manual_FillShading_MatSel_InputProps(
        bpy.types.PropertyGroup):
    library: bpy.props.EnumProperty(
        name='Opening Shape',
        update=fill_library_update,
        default='liquids',
        items=material_library_items)
    # pattern_library: bpy.props.EnumProperty(
    #     name='Pattern Library',
    #     update=pattern_library_update,
    #     default='liquifeel',
    #     items=[
    #         ('liquifeel', 'Liquifeel', 'Patterns packaged with Liquifeel'),
    #         ('user_defined', 'User Defined', 'Patterns added by the user.'),
    #     ])
    liquids_material: bpy.props.EnumProperty( # formerly library_liquids_material
        name='Fill Material',
        update=fill_shading_material_update,
        default='Water',
        items=liquids_shader_items)
    solids_material: bpy.props.EnumProperty( # formerly library_solids_material
        name='Fill Material',
        update=fill_shading_material_update,
        items=solids_shader_items)
    scene_material: bpy.props.EnumProperty( # formerly scene_material
        name='Fill Material',
        update=scene_fill_shading_material_update,
        items=scene_shader_items)
registerable_classes.append(
    ObjectAttached_Manual_FillShading_MatSel_InputProps)

# @undo_push(2)
def pattern_texture_updt(slf, context):
    obj__ = context.active_object
    # It's impossible to fill a recipient with patterned glass, so we
    # won't put the property wielding this callback in the
    # MaterialAttached_Synthetic_FillShading_InputProps
    # structure. Thus we can hard-code the shading_modality_key.
    material = get_asset_material(
        obj__, shading_modality_key='slot')
    redux_input_data = index_hierarchy_by_path(
        REDUX_INPUT_DATA,
        ['shading', 'material_attached',
         'Pattern Texture; Pattern Texture Resolution; Pattern Library; User Pattern Texture'])
    path_as_mapping = redux_input_data['paths'][0]['mapping']
    input_data = index_hierarchy_by_path(INPUT_FIELD_DATA, redux_input_data['paths'][0]['list'])
    node_names = path_as_mapping['group_name']
    nodes = [get_material_node(material, node_name.strip()) for node_name in node_names.split(';')]
    val_data = get_prop_vals(slf, ["pattern_texture_resolution", "pattern_library"])
    res_key = val_data['pattern_texture_resolution']
    pat_lib_key = val_data['pattern_library']
    if pat_lib_key == 'user_defined' and are_user_defined_patterns_present():
        img_key = get_prop_vals(slf, "user_pattern_texture")
        img = bpy.data.images[img_key]
        img_tex_fpath = img.filepath_from_user()
        assign_pattern(obj__, nodes, img, img_tex_fpath)
    elif pat_lib_key == 'liquifeel':
        img_key = get_prop_vals(slf, "pattern_texture")
        img_tex_fpath = FPATHS[
            input_data['enum_source_fpath_key']][img_key][res_key]
        img = maybe_load_image(img_tex_fpath)
        assign_pattern(obj__, nodes, img, img_tex_fpath)

# This is one of the manually defined prop update functions. The
# function should be as concrete and hard-coded as possible to reduce
# the run-time load of logic in the body of the function. These
# functions are stupidly simple.
mapping_patternutils_updt__mapping = {'Box': True, 'UV': False}
def mapping_patternutils_updt(prop_parent, context):
    obj__ = context.active_object
    # # DEV CRUTCH
    # prop_parent = obj__.liquifeel_field_inputs.slot_shading.solids_inputs.uber_glass.geonode.patternutils
    # REDUX_INPUT_DATA['shading'][target_attachment_key][input_name]
    redux_input_data = REDUX_INPUT_DATA['shading']['object_attached']['Mapping']
    prop_val_data = get_prop_vals(prop_parent, redux_input_data['prop_key'])
    ng_name = redux_input_data['unanimous_path_elems']['group_name']
    mod = get_geonodes_mod_by_ng_name(obj__, ng_name) 
    identifier = get_geonodes_field_identifier(mod, redux_input_data['underlying_input_name'])
    val = mapping_patternutils_updt__mapping[prop_val_data]
    mod[identifier] = val

def uv_name_patternutils_geonode_mandef_updt(prop_parent, context):
    obj__ = context.active_object
    # # DEV CRUTCH
    # prop_parent = obj__.liquifeel_field_inputs.slot_shading.solids_inputs.uber_glass.geonode.patternutils
    # REDUX_INPUT_DATA['shading'][target_attachment_key][input_name]
    redux_input_data = REDUX_INPUT_DATA['shading']['object_attached']['UV Name']
    val = get_prop_vals(prop_parent, redux_input_data['prop_key'])
    ng_name = redux_input_data['unanimous_path_elems']['group_name']
    mod = get_geonodes_mod_by_ng_name(obj__, ng_name) 
    identifier = get_geonodes_field_identifier(mod, redux_input_data['underlying_input_name'])
    mod[identifier] = val

def vertex_group_patternutils_geonode_mandef_updt(prop_parent, context):
    obj__ = context.active_object
    # # DEV CRUTCH
    # prop_parent = obj__.liquifeel_field_inputs.slot_shading.solids_inputs.uber_glass.geonode.patternutils
    # REDUX_INPUT_DATA['shading'][target_attachment_key][input_name]
    redux_input_data = REDUX_INPUT_DATA['shading']['object_attached']['Vertex Group']
    val = get_prop_vals(prop_parent, redux_input_data['prop_key'])
    ng_name = redux_input_data['unanimous_path_elems']['group_name']
    mod = get_geonodes_mod_by_ng_name(obj__, ng_name) 
    identifier = get_geonodes_field_identifier(mod, redux_input_data['underlying_input_name'])
    mod[identifier] = val

@undo_push(2)
def scene_slot_shading_material_update(slf, context):
    obj__ = context.active_object
    material_name = getattr(slf, 'slot_shading_scene_material')
    slot_shade(context, obj__, 'scene', material_name)

@undo_push(2)
def scene_fill_shading_material_update(slf, context):
    obj__ = context.active_object
    material_name = getattr(slf, 'fill_shading_scene_material')
    fill_shade(context, obj__, 'scene', material_name)

# key_chain: ['liquifeel_input_field_props', 'shading', 'slot', 'manual']
# path: liquifeel_input_field_props.shading.slot.manual
class ObjectAttached_Manual_SlotShading_InputProps(bpy.types.PropertyGroup):
    mapping: bpy.props.EnumProperty(
        name='Mapping',
        update=mapping_patternutils_updt,
        default='Box',
        items=[
            ('Box', 'Box', 'Box(True)'),
            ('UV', 'UV', 'UV(False)'),
        ])
    uv_name: bpy.props.EnumProperty(
        name='UV Name',
        update=uv_name_patternutils_geonode_mandef_updt,
        items=get_object_uv_maps_items_f())
    vertex_group: bpy.props.EnumProperty(
        name='Vertex Group',
        update=vertex_group_patternutils_geonode_mandef_updt,
        items=get_object_vertex_groups_items_f())
    # material selector properties
    material_selector: bpy.props.PointerProperty(
        type=ObjectAttached_Manual_SlotShading_MatSel_InputProps)
registerable_classes.append(ObjectAttached_Manual_SlotShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'shading', 'fill', 'manual']
# path: liquifeel_input_field_props.shading.fill.manual
class ObjectAttached_Manual_FillShading_InputProps(bpy.types.PropertyGroup):
    mapping: bpy.props.EnumProperty(
        name='Mapping',
        update=mapping_patternutils_updt,
        default='Box',
        items=[
            ('Box', 'Box', 'Box(True)'),
            ('UV', 'UV', 'UV(False)'),
        ])
    uv_name: bpy.props.EnumProperty(
        name='UV Name',
        update=uv_name_patternutils_geonode_mandef_updt,
        items=get_object_uv_maps_items_f())
    vertex_group: bpy.props.EnumProperty(
        name='Vertex Group',
        update=vertex_group_patternutils_geonode_mandef_updt,
        items=get_object_vertex_groups_items_f())
    # material selector properties
    material_selector: bpy.props.PointerProperty(
        type=ObjectAttached_Manual_FillShading_MatSel_InputProps)
registerable_classes.append(ObjectAttached_Manual_FillShading_InputProps)

# # key_chain: ['liquifeel_input_field_props', 'shading', 'manual']
# # path: liquifeel_input_field_props.shading.manual
# class ObjectAttached_Manual_Shading_InputProps(bpy.types.PropertyGroup):
#     mapping: bpy.props.EnumProperty(
#         name='Mapping',
#         update=mapping_patternutils_updt,
#         default='Box',
#         items=[
#             ('Box', 'Box', 'Box(True)'),
#             ('UV', 'UV', 'UV(False)'),
#         ])
#     uv_name: bpy.props.EnumProperty(
#         name='UV Name',
#         update=uv_name_patternutils_geonode_mandef_updt,
#         items=get_object_uv_maps_items_f())
#     vertex_group: bpy.props.EnumProperty(
#         name='Vertex Group',
#         update=vertex_group_patternutils_geonode_mandef_updt,
#         items=get_object_vertex_groups_items_f())
#     # material selector properties
#     slot_material_selector: bpy.props.PointerProperty(
#         type=ObjectAttached_Manual_SlotShading_MatSel_InputProps)
#     fill_material_selector: bpy.props.PointerProperty(
#         type=ObjectAttached_Manual_FillShading_MatSel_InputProps)
# registerable_classes.append(ObjectAttached_Manual_Shading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'shading', 'slot']
# path: liquifeel_input_field_props.shading.slot
class ObjectAttached_SlotShading_InputProps(bpy.types.PropertyGroup):
    synthetic: bpy.props.PointerProperty(type=ObjectAttached_Synthetic_SlotShading_InputProps)
    manual: bpy.props.PointerProperty(type=ObjectAttached_Manual_SlotShading_InputProps)
registerable_classes.append(ObjectAttached_SlotShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'shading', 'fill']
# path: liquifeel_input_field_props.shading.fill
class ObjectAttached_FillShading_InputProps(bpy.types.PropertyGroup):
    synthetic: bpy.props.PointerProperty(type=ObjectAttached_Synthetic_FillShading_InputProps)
    manual: bpy.props.PointerProperty(type=ObjectAttached_Manual_FillShading_InputProps)
registerable_classes.append(ObjectAttached_FillShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'shading']
# path: liquifeel_input_field_props.shading
class ObjectAttached_Shading_InputProps(bpy.types.PropertyGroup):
    slot: bpy.props.PointerProperty(type=ObjectAttached_SlotShading_InputProps)
    fill: bpy.props.PointerProperty(type=ObjectAttached_FillShading_InputProps)
registerable_classes.append(ObjectAttached_Shading_InputProps)

# # key_chain: ['liquifeel_input_field_props', 'shading']
# # path: liquifeel_input_field_props.shading
# class ObjectAttached_Shading_InputProps(bpy.types.PropertyGroup):
#     synthetic: bpy.props.PointerProperty(type=ObjectAttached_Synthetic_Shading_InputProps)
#     manual: bpy.props.PointerProperty(type=ObjectAttached_Manual_Shading_InputProps)
# registerable_classes.append(ObjectAttached_Shading_InputProps)

# key_chain: ['liquifeel_input_field_props']
# path: liquifeel_input_field_props
class ObjectAttached_InputProps(bpy.types.PropertyGroup):
    geometry: bpy.props.PointerProperty(type=ObjectAttached_Geometry_InputProps)
    shading: bpy.props.PointerProperty(type=ObjectAttached_Shading_InputProps)
registerable_classes.append(ObjectAttached_InputProps)

# key_chain: ['liquifeel_input_field_props', 'slot', 'synthetic']
# path: liquifeel_input_field_props.slot.synthetic
# class MaterialAttached_Synthetic_SlotShading_InputProps
declare_and_register_synthetic_prop_parent(
        'shading', 'material_attached', shading_modality_key='slot')
# class MaterialAttached_Synthetic_SlotShading_InputProps(bpy.types.PropertyGroup):
#     pass
# registerable_classes.append(MaterialAttached_Synthetic_SlotShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'slot', 'manual']
# path: liquifeel_input_field_props.slot.manual
class MaterialAttached_Manual_SlotShading_InputProps(bpy.types.PropertyGroup):
    # pattern properties
    pattern_texture: bpy.props.EnumProperty(
        name='Pattern Texture',
        update=pattern_texture_updt,
        items=gen_pattern_imgtex_img_items)
    user_pattern_texture: bpy.props.EnumProperty(
        name='User Pattern Texture',
        update=pattern_texture_updt,
        items=gen_pattern_user_imgtex_img_items)
    pattern_texture_resolution: bpy.props.EnumProperty(
        name='Pattern Texture Resolution',
        update=pattern_texture_updt,
        items=gen_pattern_imgtex_res_items)
    pattern_library: bpy.props.EnumProperty(
        name='Pattern Library',
        default='liquifeel',
        update=pattern_texture_updt,
        items=[
            ('liquifeel', 'Liquifeel', 'Patterns packaged with Liquifeel'),
            ('user_defined', 'User Defined', 'Patterns added by the user.'),
        ])
registerable_classes.append(MaterialAttached_Manual_SlotShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'slot']
# path: liquifeel_input_field_props.slot
class MaterialAttached_SlotShading_InputProps(bpy.types.PropertyGroup):
    synthetic: bpy.props.PointerProperty(type=MaterialAttached_Synthetic_SlotShading_InputProps)
    manual: bpy.props.PointerProperty(type=MaterialAttached_Manual_SlotShading_InputProps)
registerable_classes.append(MaterialAttached_SlotShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'fill', 'synthetic']
# path: liquifeel_input_field_props.fill.synthetic
# class MaterialAttached_Synthetic_FillShading_InputProps
declare_and_register_synthetic_prop_parent(
        'shading', 'material_attached', shading_modality_key='fill')
# class MaterialAttached_Synthetic_FillShading_InputProps(bpy.types.PropertyGroup):
#     pass
# registerable_classes.append(MaterialAttached_Synthetic_FillShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'fill', 'manual']
# path: liquifeel_input_field_props.fill.manual
class MaterialAttached_Manual_FillShading_InputProps(bpy.types.PropertyGroup):
    # pattern properties
    pattern_texture: bpy.props.EnumProperty(
        name='Pattern Texture',
        update=pattern_texture_updt,
        items=gen_pattern_imgtex_img_items)
    user_pattern_texture: bpy.props.EnumProperty(
        name='User Pattern Texture',
        update=pattern_texture_updt,
        items=gen_pattern_user_imgtex_img_items)
    pattern_texture_resolution: bpy.props.EnumProperty(
        name='Pattern Texture Resolution',
        update=pattern_texture_updt,
        items=gen_pattern_imgtex_res_items)
    pattern_library: bpy.props.EnumProperty(
        name='Pattern Library',
        default='liquifeel',
        update=pattern_texture_updt,
        items=[
            ('liquifeel', 'Liquifeel', 'Patterns packaged with Liquifeel'),
            ('user_defined', 'User Defined', 'Patterns added by the user.'),
        ])
    # library: bpy.props.EnumProperty(
    #     name='Library',
    #     update=fill_library_update,
    #     default='liquids',
    #     items=material_library_items)
registerable_classes.append(MaterialAttached_Manual_FillShading_InputProps)

# key_chain: ['liquifeel_input_field_props', 'fill']
# path: liquifeel_input_field_props.fill
class MaterialAttached_FillShading_InputProps(bpy.types.PropertyGroup):
    synthetic: bpy.props.PointerProperty(type=MaterialAttached_Synthetic_FillShading_InputProps)
    manual: bpy.props.PointerProperty(type=MaterialAttached_Manual_FillShading_InputProps)
registerable_classes.append(MaterialAttached_FillShading_InputProps)

# key_chain: ['liquifeel_input_field_props']
# path: liquifeel_input_field_props
class MaterialAttached_InputProps(bpy.types.PropertyGroup):
    slot: bpy.props.PointerProperty(type=MaterialAttached_SlotShading_InputProps)
    fill: bpy.props.PointerProperty(type=MaterialAttached_FillShading_InputProps)
registerable_classes.append(MaterialAttached_InputProps)

property_types = {
    'int': bpy.props.IntProperty,
    'float': bpy.props.FloatProperty,
    'bool': bpy.props.BoolProperty,
    'bool_to_float': bpy.props.BoolProperty,
    'enum': bpy.props.EnumProperty,
    'color': bpy.props.FloatVectorProperty,
}

main_tab_items = []
for n, tab_key in enumerate(MAIN_TAB_KEYS):
    if tab_key in MAIN_TAB_BUILTIN_ICONS.keys():
        icon_key = MAIN_TAB_BUILTIN_ICONS[tab_key]
    else:
        icon_key = preview_data['ids']['icons'][tab_key]
    name = MAIN_TAB_NAMES[tab_key]
    main_tab_items.append((
        tab_key, # key
        name, # name
        name, # description
        icon_key, # icon
        n # position
    ))

shading_target_items = [
    ('recipient', 'to Recipient',
     'Apply shader to the liquifeel recipient object'),
    ('liquid', 'to Liquid',
     'Apply shader to the liquifeel liquid object'),
]

recipient_asset_items = []
for asset_key, name_data in RECIPIENT_ASSET_NAME_DATA.items():
    recipient_asset_items.append((
        asset_key,
        RECIPIENT_ASSET_NAME_DATA[asset_key]['thumbnail'], RECIPIENT_ASSET_NAME_DATA[asset_key]['thumbnail'],
        preview_data['ids']['recipient_asset_thumbnails'][asset_key],
        len(recipient_asset_items)
    ))

# # KEEP
# @undo_push(2)
# def performance_render_mode_update(slf, context):
#     print(
#         f'performance_render_mode_update({slf}, context)',
#         ':',
#         getattr(slf, 'performance_render_mode'))
#     adjust_render_settings(
#         context, light=getattr(slf, 'performance_render_mode'))

## The properties which are not asset specific (i.e. main tabs)
class GeneralUIControls(bpy.types.PropertyGroup):
    # The main UI tabs (in the upper right corner of the liquifeel panel)
    # i.e. fill, shading, fx, etc...
    main_tabs: bpy.props.EnumProperty(
        items=main_tab_items,
        default='geometry')
    # The shading tabs (recipient vs liquid) they only appear when a lqfl filled object is selected.
    shading_target: bpy.props.EnumProperty(
        name='Shading for',
        items=shading_target_items)
    # The shading tabs (recipient vs liquid) they only appear when a lqfl filled object is selected.
    material_library: bpy.props.EnumProperty(
        name='Library',
        items=material_library_items)
    recipient_asset: bpy.props.EnumProperty(
        name='Fill Material',
        # No update function needed in this case, it's functionality has shifted to the operator:
        # AddAssetTo3DCursor
        # update=append_recipient_asset,
        items=recipient_asset_items)
    # # KEEP
    # performance_render_mode: bpy.props.BoolProperty(
    #     name='Performance Render Mode',
    #     update=performance_render_mode_update,
    #     default=False)
registerable_classes.append(GeneralUIControls)

## Messages and data
class MiscData(bpy.types.PropertyGroup):
    # Popup message
    info_popup_message: bpy.props.StringProperty(
        name='info_popup_message', default='info popup')
registerable_classes.append(MiscData)

## DISPLAY --------------------------------------------------------------------------------

def info_popup(context, message):
    setattr(context.scene.liquifeel_misc_data, 'info_popup_message', message)
    bpy.ops.wm.call_menu(name='OBJECT_MT_info_popup')

## APPEND ---------------------------------------------------------------------------------------

def levenshtein_distance(s1, s2):
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    return previous_row[-1]

def sorting_crit_f(name_substring):
    def sorting_key(target_string):
        return levenshtein_distance(name_substring, target_string)
    return sorting_key

# data_category is the attribute to data_from ('objects',
# 'node_groups', etc...)
def get_append_name(data_from, data_category_key, name_substring):
    return sorted(
        [obj_name for obj_name in getattr(
            data_from, data_category_key) if name_substring in obj_name],
        key=sorting_crit_f(name_substring)
    )[0]

def append_data(posix_filepath, category_key, name_substring):
    with bpy.data.libraries.load(str(posix_filepath)) as (data_from, data_to):
        dat_name = get_append_name(data_from, category_key, name_substring)
        setattr(data_to, category_key, [dat_name])
    dat = getattr(data_to, category_key)[0]
    return dat

def append_recipient_asset__(context, parenting_data):
    obj_name = parenting_data['name']
    # print(f'append_recipient_asset__(): obj_name: {obj_name}')
    asset_key = key_from_name(obj_name)
    glass_asset_append_fpath = FPATHS['blend_assets']
    obj__ = append_data(str(glass_asset_append_fpath), 'objects', obj_name)
    # with bpy.data.libraries.load(str(
    #         glass_asset_append_fpath)) as (data_from, data_to):
    #     print(obj_name)
    #     data_to.objects = [obj_name]
    # obj__ = data_to.objects[0]
    context.collection.objects.link(obj__)
    obj__.location = mathutils.Vector((0, 0, 0))
    obj__.name = obj_name
    if parenting_data['children']:
        children_objss = list(
            map(lambda child_data: append_recipient_asset__(context, child_data),
                parenting_data['children']))
        for child_obj, nephew_objss in children_objss:
            child_obj.parent = obj__
    else:
        children_objss = []
    return obj__, children_objss

def append_geonode_group(node_group_name, posix_filepath):
    return append_data(posix_filepath, 'node_groups', node_group_name)

# def append_geonode_group(node_group_name, posix_filepath):
#     with bpy.data.libraries.load(str(posix_filepath)) as (data_from, data_to):
#         data_to.node_groups = [node_group_name]
#     ng = data_to.node_groups[0]
#     return ng

def maybe_append_geonode_group(node_group_name, filepath):
    if node_group_name in bpy.data.node_groups.keys():
        return bpy.data.node_groups[node_group_name]
    else:
        return append_geonode_group(node_group_name, filepath)

def append_material(material_name, posix_filepath):
    return append_data(posix_filepath, 'materials', material_name)

def maybe_append_material(material_name, filepath):
    if material_name in bpy.data.materials.keys():
        return bpy.data.materials[material_name]
    else:
        return append_material(material_name, filepath)


## FUNCTIONALITY --------------------------------------------------------------------------------

## MODIFIERS ----------------------------

# I think that the cycles glitch where some materials appear blank
# till cycles is reloaded could be resolved by strategically deploying
# this function. !!!
def modifier_viewport_update_trigger(context, mod):
    mod.node_group.interface_update(context)

## RANKING / SORTING ---------

modifier_ranking = [
    {
        'type': 'non-lqfl',
        'discriminator': lambda mod: not(is_lqfl_modifier(mod))},
    {
        'type': 'select_outer',
        'discriminator': is_mod_select_outer},
    {
        'type': 'main_fill',
        'discriminator': is_mod_main_fill},
    {
        'type': 'lqfl-slot',
        'discriminator': modifier_slot_vs_shade_discriminator_f('slot')},
    {
        'type': 'lqfl-fill',
        'discriminator': modifier_slot_vs_shade_discriminator_f('fill')},
]

## ASSIGNING ---------

def load_node_group(ng_name, data_to_attach_as_id_prop):
    ng = maybe_append_geonode_group(
        ng_name,
        FPATHS['blend_assets'])
    ng['liquifeel'] = data_to_attach_as_id_prop
    return ng

def remove_mods(obj__, discriminator):
    # print()
    # print(f'remove_mods(obj__, discriminator):')
    # print('obj__.modifiers', obj__.modifiers)
    satisfactory_mods = [mod for mod in obj__.modifiers if discriminator(mod)]
    # print('satisfactory_mods: ', satisfactory_mods)
    if satisfactory_mods:
        for mod in satisfactory_mods:
            obj__.modifiers.remove(mod)

def move_mod_in_stack(obj__, mod_name, i):
    obj__.modifiers.move(
        obj__.modifiers.find(mod_name), i)

def assign_liquifeel_modifier(obj__, ng_name, remove_discriminator, get_pos_from_obj):
    remove_mods(obj__, remove_discriminator) # Remove any preexisting fill mods
    # assign the new mod
    ng = load_node_group(
        ng_name,
        {'feature': 'fill',
         'main_tab': ['fill', 'shading']})
    mod = obj__.modifiers.new(
        name=ng_name, type='NODES')
    mod.node_group = ng
    # place it second (after the select outer mod)
    move_mod_in_stack(obj__, mod.name, get_pos_from_obj(obj__))
    return mod

# Returns the first index after the non-lqfl modifiers. the lqfl modifiers should be placed after the
# original model's modifiers.
def get_first_lqfl_mod_index(obj__):
    return len([mod for mod in obj__.modifiers if not(is_lqfl_modifier(mod))])

def assign_select_outer_geonode_mod(obj__):
    mod = assign_liquifeel_modifier(
        obj__, SELECT_OUTER_NG_NAME, is_mod_select_outer, get_first_lqfl_mod_index)
    return mod

def get_fill_mod_pos_index(obj__):
    return get_first_lqfl_mod_index(obj__) + 1

def assign_fill_geonode_mod(obj__):
    mod = assign_liquifeel_modifier(
        obj__, FILL_NG_NAME, is_mod_main_fill, get_fill_mod_pos_index)
    # Just to make sure it's not decoupled from the actual value, we set it.
    setattr(obj__.liquifeel_input_field_props.geometry.manual,
            'hide_liquid',
            not(mod.show_viewport))
    return mod

def get_last_mod_index(obj__):
    return len(obj__.modifiers) - 1

def assign_hide_recipient_geonode_mod(obj__):
    mod = assign_liquifeel_modifier(
        obj__, HIDE_RECIPIENT_NG_NAME, has_geonode_mod_name_f(HIDE_RECIPIENT_NG_NAME), get_last_mod_index)
    return mod

## GEONODES ----------------------------

def get_geonodes_modifier(obj__, mod_name):
    return obj__.modifiers[mod_name]

# get_geonodes_mod_by_ng_name(Sphere, FILL_NG_NAME)
def get_geonodes_mod_by_ng_name(obj__, ng_name):
    return next(filter(lambda mod: mod.type == 'NODES' and mod.node_group.name == ng_name,
                       obj__.modifiers))

def get_geonodes_field_identifier(mod, field_name):
    return index_stripped(
        mod.node_group.interface.items_tree,  # bpy.data.objects["American Pint Glass"].modifiers["PatternUtils"]["Input_4"]
        field_name
    ).identifier

def get_geonode_mod_input(obj__, ng_name, field_name):
    mod = get_geonodes_mod_by_ng_name(obj__, ng_name)
    identifier = get_geonodes_field_identifier(mod, field_name)
    return mod[identifier]

def set_color_input_field(mod, identifier, value):
    # print(f'set_color_input_field({mod.name}, {identifier}, {value})')
    for i in range(len(value)):
        mod[identifier][i] = value[i]

# params: obj__, FILL_NG_NAME, 'Liquid Shader', 'material', material)
def set_geonode_mod_input(obj__, mod_name, input_name, input_type_key, value):
    mod = get_geonodes_modifier(obj__, mod_name)
    identifier = get_geonodes_field_identifier(mod, input_name)
    if input_type_key == 'color':
        set_color_input_field(mod, identifier, value)
    else:
        mod[identifier] = value

json_decoded_value_parser = {
    'bool': {'True': True, 'False': False},
    'bool_to_float': {'true': 1.0, 'false': 0.0}
}

def remove_material_auxiliary_modifiers(obj__, prev_mat_library_key, prev_mat_name):
    # print(f'remove_material_auxiliary_modifiers(obj__:{obj__.name}, {prev_mat_library_key}, {prev_mat_name})')
    filter_f = is_modifier_shader_auxilliary_f(
        prev_mat_library_key, prev_mat_name)
    mods_to_remove = list(filter(filter_f, obj__.modifiers))
    for mod in mods_to_remove:
        obj__.modifiers.remove(mod)

def is_geonode_mod_present(obj__, ng_name):
    return ng_name in map(lambda mod: mod.node_group.name,
                          filter(lambda mod: mod.type == 'NODES',
                                 list(obj__.modifiers)))

def install_material_aux_mod(obj__, library_key, material_name, ng_name, shading_modality_key):
    if not(is_geonode_mod_present(obj__, ng_name)):
        node_group = load_node_group(
            ng_name,
            {'slot_vs_fill': shading_modality_key,
             'main_tab': 'shading',
             'library': library_key,
             'material_name': material_name,})
        mod = obj__.modifiers.new(
            name=ng_name, type='NODES')
        mod.node_group = node_group
    else:
        mod = obj__.modifiers[ng_name]
    return mod

def maybe_install_material_auxiliary_modifiers(obj__, library_key, material_name, shading_modality_key):
    # print()
    # print('maybe_install_material_auxiliary_modifiers(obj__, library_key, material_name, shading_modality_key)')
    material_data = INPUT_FIELD_DATA['shading'][library_key][material_name]
    if 'GeoNode' in material_data.keys():
        for ng_name, geonode_mod_data in material_data['GeoNode'].items():
            mod = install_material_aux_mod(obj__, library_key, material_name, ng_name, shading_modality_key)
            # print('ng_name: ', ng_name)
        # reorder modifiers if neccessary
        if is_obj_filled(obj__):
            move_mod_in_stack(obj__, HIDE_RECIPIENT_NG_NAME, get_last_mod_index(obj__))

## MATERIALS ----------------------------

def is_shader_node_group(node):
    return type(node) == bpy.types.ShaderNodeGroup

def get_shader_ng_by_name(material, ng_name):
    # print()
    # print('material:', material)
    # print('material.name', material.name)
    # print('ng_name', ng_name)
    # print()
    return next(
        filter(lambda ng: ng_name in ng.node_tree.name,
               filter(is_shader_node_group,
                      material.node_tree.nodes)))

def get_material_node(material, node_name):
    # print(f'get_material_node(material: {material}, node_name: {node_name}):')
    return next(
        filter(lambda node: any([f(node) == node_name for f in [lambda n: n.name, lambda n: n.label]]),
               material.node_tree.nodes))

def assign_pattern(obj__, nodes, img, img_tex_fpath):
    img.filepath = str(img_tex_fpath)
    img.filepath_raw = str(img_tex_fpath)
    img.colorspace_settings.name = 'Non-Color'
    for img_node in nodes:
        img_node.image = img

def set_asset_material(obj__, material, shading_modality_key):
    library_key, material_name = get_library_key_and_material_name(
        obj__, shading_modality_key=shading_modality_key)
    if shading_modality_key == 'slot':
        if obj__.data.materials:
            obj__.data.materials[0] = material
        else:
            obj__.data.materials.append(material)
        obj__['liquifeel']['slot_shading']['material_name'] = material.name
    elif shading_modality_key == 'fill':
        set_geonode_mod_input(
            obj__, FILL_NG_NAME, 'Liquid Shader', 'material', material)
        obj__['liquifeel']['fill_shading']['material_name'] = material.name

## GEOMETRY ----------------------------

def assert_island_count_f(n):
    def assert_(context, obj__):
        island_c = count_mesh_islands(obj__)
        if island_c < n:
            info_popup(
                context, f'Active object has too few mesh islands.\nAmount should be {n}, but is {island_c}')
            return False
        elif island_c > n:
            info_popup(
                context, f'Active object has too many mesh islands.\nAmount should be {n}, but is {island_c}')
            return False
        else:
            return True
    return assert_

@undo_push(2)
def fill_object(context, obj__):
    if assert_island_count_f(1)(context, obj__):
        make_single_user_and_apply_transforms(context, obj__)
        if 'liquifeel' not in obj__.keys():
            obj__['liquifeel'] = {}
        obj__['liquifeel']['fill_shading'] = {
            'filled': True
        }
        assign_select_outer_geonode_mod(obj__)
        assign_fill_geonode_mod(obj__)
        assign_hide_recipient_geonode_mod(obj__)
        # Assigning default vals
        for ui_input_name, redux_input_data in REDUX_INPUT_DATA['geometry']['object_attached'].items():
            input_field_data = index_hierarchy_by_path(
                INPUT_FIELD_DATA, redux_input_data['paths'][0]['list'])
            declaration_modality_key = get_declaration_modality_key(redux_input_data)
            prop_key_chain = [
                'liquifeel_input_field_props', 'geometry', declaration_modality_key, input_field_data['prop_key']]
            prop_parent, prop_key = ref_ob_key_pair(obj__, prop_key_chain)
            # Assigning default values for the relevant ui input props.
            if 'ui_prop_from_default' in input_field_data['setters'].keys():
                input_field_data['setters']['ui_prop_from_default'](prop_parent)
            underlying_input_setters = input_field_data['setters']['per_shading_modality'][
                'slot'] # Random shading_modality_key, in this case, the same update f is in both.
            # Setting the underlying input with the default val
            # if all(['underlying_from_default' in underlying_input_setters.keys(),
            #         declaration_modality_key == 'synthetic']):
            if input_field_data['ui_input_name'] == 'Liquid Amount':
                underlying_input_setters['underlying_from_default'](
                    prop_parent, obj__, None)

## MENUS --------------------------------------------------------------------------------

class InfoPopup(bpy.types.Menu):
    bl_idname = f'OBJECT_MT_info_popup'
    bl_label = 'Info Popup'
    def draw(self, context):
        self.layout.label(
            text=getattr(context.scene.liquifeel_misc_data, 'info_popup_message'))
registerable_classes.append(InfoPopup)

## OPERATORS --------------------------------------------------------------------------------

class PurgeUnusedData(bpy.types.Operator):
    bl_idname = 'liquifeel.purge_unused_data'
    bl_label = 'Launch Feedback Form'
    def execute(self, context):
        unused_data_purge(context)
        return {'FINISHED'}
registerable_classes.append(PurgeUnusedData)

class UpdateRenderView(bpy.types.Operator):
    bl_idname = 'liquifeel.update_render_view'
    bl_label = 'Launch Feedback Form'
    def execute(self, context):
        update_render_view(context)
        return {'FINISHED'}
registerable_classes.append(UpdateRenderView)

class LaunchFeedbackForm(bpy.types.Operator):
    bl_idname = 'liquifeel.launch_feedback_form'
    bl_label = 'Launch Feedback Form'
    def execute(self, context):
        open_webpage(URLS['feedback'])
        return {'FINISHED'}
registerable_classes.append(LaunchFeedbackForm)

class LaunchGallery(bpy.types.Operator):
    bl_idname = 'liquifeel.launch_gallery'
    bl_label = 'Launch Gallery'
    def execute(self, context):
        open_webpage(URLS['gallery'])
        return {'FINISHED'}
registerable_classes.append(LaunchGallery)

class LaunchGuide(bpy.types.Operator):
    bl_idname = 'liquifeel.launch_guide'
    bl_label = 'Launch Guide'
    def execute(self, context):
        open_webpage(URLS['guide'])
        return {'FINISHED'}
registerable_classes.append(LaunchGuide)

class LaunchWebsite(bpy.types.Operator):
    bl_idname = 'liquifeel.launch_website'
    bl_label = 'Launch Website'
    def execute(self, context):
        open_webpage(URLS['liquifeel_website'])
        return {'FINISHED'}
registerable_classes.append(LaunchWebsite)

class LaunchWebsite(bpy.types.Operator):
    bl_idname = 'liquifeel.launch_discord'
    bl_label = 'Launch Discord'
    def execute(self, context):
        open_webpage(URLS['discord'])
        return {'FINISHED'}
registerable_classes.append(LaunchWebsite)

class CycleTabs(bpy.types.Operator):
    bl_idname = 'liquifeel.cycle_tabs'
    bl_label = 'Cycle Tabs'
    def execute(self, context):
        current_tab_key = getattr(context.scene.liquifeel_general_controls, 'main_tabs')
        current_tab_index = MAIN_TAB_KEYS.index(current_tab_key)
        if current_tab_index == len(MAIN_TAB_KEYS) - 1:
            next_tab_index = 0
        else:
            next_tab_index = current_tab_index + 1
        next_tab_key = MAIN_TAB_KEYS[next_tab_index]
        setattr(context.scene.liquifeel_general_controls, 'main_tabs', next_tab_key)
        return {'FINISHED'}
registerable_classes.append(CycleTabs)

class FillActive(bpy.types.Operator):
    bl_idname = 'liquifeel.fill_active_object'
    bl_label = 'Fill Selected'
    def execute(self, context):
        obj__ = context.active_object
        fill_object(context, obj__)
        return {'FINISHED'}
registerable_classes.append(FillActive)

@undo_push(1)
def append_recipient_asset(context):
    asset_key = context.scene.liquifeel_general_controls.recipient_asset
    obj__, children_objss = append_recipient_asset__(
        context,
        RECIPIENT_ASSET_PARENTING_DATA[asset_key])
    c_loc = context.scene.cursor.location
    obj__.location = c_loc
    obj__.name = RECIPIENT_ASSET_NAME_DATA[asset_key]['thumbnail']
    select_and_set_active(context, obj__, deselect_all=True)

class AddAssetTo3DCursor(bpy.types.Operator):
    bl_idname = 'liquifeel.add_asset_to_3d_cursor'
    bl_label = 'Add Asset To 3D Cursor'
    def execute(self, context):
        append_recipient_asset(context)
        return {'FINISHED'}
registerable_classes.append(AddAssetTo3DCursor)

@undo_push(1)
def clear_asset(context):
    obj__ = context.active_object
    # remove all liquifeel modifiers
    for mod in [mod for mod in obj__.modifiers if is_lqfl_modifier(mod)]:
        obj__.modifiers.remove(mod)
    # remove materials
    obj__.data.materials.clear()
    # remove object tags
    if 'liquifeel' in obj__:
        obj__.pop('liquifeel')

class ClearAsset(bpy.types.Operator):
    bl_idname = 'liquifeel.clear_asset'
    bl_label = 'Clear'
    def execute(self, context):
        clear_asset(context)
        return {'FINISHED'}
registerable_classes.append(ClearAsset)

def maybe_remove_lqfl_object_tags(obj__):
    for tag_key in LQFL_OBJECT_TAG_ATTACHED_DATA_KEYS:
        if tag_key in obj__:
            obj__.pop(tag_key)

@undo_push(1)
def apply_asset(context):
    obj__ = context.active_object
    # apply all liquifeel modifiers
    for mod in [mod for mod in obj__.modifiers if is_lqfl_modifier(mod)]:
        bpy.ops.object.modifier_apply(modifier=mod.name)
    # Ca să nu se mai schimbe inputurile din shader (care ar fi fost comun)
    # atunci când modifici un alt obiect: duplicăm materialul obiectului căruia-i
    # dăm apply.
    bpy.ops.object.make_single_user(material=True)
    # remove object tag attached data
    maybe_remove_lqfl_object_tags(obj__)

class ApplyAsset(bpy.types.Operator):
    bl_idname = 'liquifeel.apply_asset'
    bl_label = 'Apply'
    def execute(self, context):
        apply_asset(context)
        return {'FINISHED'}
registerable_classes.append(ApplyAsset)

def invoke_file_browser(operator_instance, context, event):
    context.window_manager.fileselect_add(
        operator_instance)

def load_user_defined_pattern(operator_instance, context):
    shading_modality_key = 'slot'
    fpath = pathlib.Path(operator_instance.filepath)
    fname = fpath.name
    img = maybe_load_image(fpath)
    img['liquifeel'] = 'user_defined'
    img.use_fake_user = True
    img.pack
    ## Assigning the pattern automatically when the user adds loads a new, custom, pattern
    obj__ = context.active_object
    library_key, material_name = get_library_key_and_material_name(
        obj__, path_as_mapping=None, shading_modality_key=shading_modality_key)
    material = get_asset_material(
        obj__, shading_modality_key=shading_modality_key)
    node_names = 'PatternImage_UV; PatternImage_Box'
    nodes = [get_material_node(material, node_name.strip()) for node_name in node_names.split(';')]
    prop_key_chain = [
        'liquifeel_input_field_props', shading_modality_key, 'manual', 'user_pattern_texture']
    # prop_key_chain = [
    #     'liquifeel_input_field_props', shading_modality_key, 'manual', 'user_pattern_texture']
    prop_parent, prop_key = ref_ob_key_pair(material, prop_key_chain)
    # prop_parent, prop_key = ref_ob_key_pair(obj__, prop_key_chain)
    set_prop_value(
        prop_parent, prop_key, fname, 'imgtex')
    assign_pattern(obj__, nodes, img, fpath)

class LoadUserDefinedPattern(bpy.types.Operator):
    bl_idname = 'liquifeel.load_user_defined_pattern'
    bl_label = 'Load User Defined Pattern'
    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    def execute(self, context):
        load_user_defined_pattern(self, context)
        return {'FINISHED'}
    def invoke(self, context, event):
        invoke_file_browser(self, context, event)
        return {'RUNNING_MODAL'}
registerable_classes.append(LoadUserDefinedPattern)

## SHADING ---------------------

def get_material(library_key, material_name):
    material = maybe_append_material(
        material_name, FPATHS['blend_assets'])
    material['liquifeel'] = {
        'name': material_name,
        'library': library_key}
    return material

## FILL SHADING ---

# I'm keeping all of these code blocks, as the tactic for redreawing
# render view after changing materials via goemetry nodes is a bit of
# hack / blender glitch, so we might have to change it in the future
# if blender changes.

# def render_view_update(context, obj__):
#     pass

# # This approach also does not work.
# def render_view_update(context, obj__):
#     context.view_layer.update()

# # This approach does not work...
# def render_view_update(context, obj__):
#     for area in context.screen.areas:
#         if area.type == 'VIEW_3D':
#             area.tag_redraw()

# # Still does not work
# def render_view_update(context, obj__):
#     obj__.data.update()

# # This approach works. i've used it in the function below defined.
# def render_view_update(context, obj__):
#     obj__.hide_viewport = True
#     obj__.hide_viewport = False

def update_obj_render_view(context, obj__):
    for mod in list(obj__.modifiers):
        if mod.type == 'NODES':
            modifier_viewport_update_trigger(context, mod)
    obj__.hide_viewport = True
    obj__.hide_viewport = False

def update_render_view(context):
    objs = set(context.selected_objects)
    objs.add(context.active_object)
    for obj__ in objs:
        update_obj_render_view(context, obj__)

# @undo_push(4)
def fill_shade(context, obj__, library_key, material_name):
    adjust_render_settings(context)
    # CLEAN THE SLATE
    clear_previous_material('fill', obj__)
    if 'liquifeel' not in obj__.keys():
        obj__['liquifeel'] = {}
    obj__['liquifeel']['fill_shading'] = {
        'library': library_key,
        'material_name': material_name
    }
    if library_key == 'scene':
        material = bpy.data.materials[material_name]
    else:
        material = get_material(library_key, material_name)
        # material = get_material(library_key, material_name).copy()
    set_geonode_mod_input(
        obj__, FILL_NG_NAME, 'Liquid Shader', 'material', material)
    if not(library_key == 'scene'):
        # remove_material_auxiliary_modifiers(obj__) This would probably remove the recipient mat aux mods.
        maybe_install_material_auxiliary_modifiers(obj__, library_key, material_name, 'fill')
        assign_default_values_to_target_inputs(obj__, material, 'fill', library_key, material_name)
    modifier_viewport_update_trigger(
        context,
        get_geonodes_mod_by_ng_name(obj__, FILL_NG_NAME))
    update_obj_render_view(context, obj__)

class ShadeActiveObjectViaFill(bpy.types.Operator):
    bl_idname = 'liquifeel.shade_active_object_via_fill'
    bl_label = 'Shade Active Object Via Fill'
    def execute(self, context):
        obj__ = context.active_object
        library_key, material_name = get_library_key_and_material_name(
            obj__, shading_modality_key='fill')
        # library_key = getattr(obj__.liquifeel_field_inputs.fill_shading, 'library')
        # material_name = getattr(obj__.liquifeel_field_inputs.fill_shading, f'library_{library_key}_material')
        fill_shade(context, obj__, library_key, material_name)
        return {'FINISHED'}
registerable_classes.append(ShadeActiveObjectViaFill)

## SLOT SHADING ---

# def assign_material(obj__, material):
#     if obj__.data.materials:
#         obj__.data.materials[0] = material
#     else:
#         obj__.data.materials.append(material)

# This function handles both the assignment of the underlying inputs
# and of the properties
def assign_default_values_to_target_inputs(
        obj__, material, shading_modality_key, library_key, material_name):
    # For the old system (obsolete), few days later, i don't think it's obsolete.
    main_tab_key = 'shading'
    material_data = INPUT_FIELD_DATA[main_tab_key][library_key][material_name]
    for target_type_name, target_type_data in material_data.items():
        target_attachment_key = get_target_attachment_key[target_type_name]
        for group_name, group_data in target_type_data.items():
            for input_name, input_field_data in group_data.items():
                redux_input_data = REDUX_INPUT_DATA[
                    main_tab_key][target_attachment_key][input_name]
                declaration_modality_key = get_declaration_modality_key(redux_input_data)
                prop_key_chain = get_prop_key_chain(
                    redux_input_data, target_attachment_key, main_tab_key,
                    declaration_modality_key, shading_modality_key)
                if target_attachment_key == 'material_attached':
                    top_level_prop_parent = material
                else: # if target_attachment_key == 'object_attached':
                    top_level_prop_parent = obj__
                prop_parent, prop_key = ref_ob_key_pair(
                    top_level_prop_parent, prop_key_chain)
                # Setting the ui prop with the default val
                if 'ui_prop_from_default' in input_field_data['setters'].keys():
                    # debug_buffer.append(input_field_data) # DEBUG !!!
                    input_field_data['setters']['ui_prop_from_default'](
                        prop_parent)
                # Setting the underlying input with the default val
                if 'underlying_from_default' in input_field_data['setters']['per_shading_modality'].keys():
                    input_field_data['setters']['per_shading_modality']['underlying_from_default'](
                        prop_parent, obj__, material)
                # if target_attachment_key == 'material_attached':
                #     set_material_attached_input__at_setup(
                #         prop_parent, input_name,
                #         obj__, redux_input_data, material)
                # else: # target_attachment_key == 'object_attached':
                #     set_geonode_mod_input__at_prop_update(
                #         obj__, prop_parent, input_name, redux_input_data,
                #         target_attachment_key, shading_modality_key)

# # This function handles both the assignment of the underlying inputs
# # and of the propertiesx
# inputs_wo_default_setting_requirement = ['imgtex']
# def assign_default_values_to_target_inputs(
#         obj__, material, shading_modality_key, library_key, material_name):
#     # For the old system (obsolete), few days later, i don't think it's obsolete.
#     main_tab_key = 'shading'
#     material_data = INPUT_FIELD_DATA[main_tab_key][library_key][material_name]
#     for target_type_name, target_type_data in material_data.items():
#         target_attachment_key = get_target_attachment_key[target_type_name]
#         for group_name, group_data in target_type_data.items():
#             for input_name, input_field_data in group_data.items():
#                 if input_field_data['type'] not in inputs_wo_default_setting_requirement:
#                     redux_input_data = REDUX_INPUT_DATA[
#                         main_tab_key][target_attachment_key][input_name]
#                     # For constructing the prop key chain used to
#                     # access the ui property of the input in question.
#                     declaration_modality_key = get_declaration_modality_key(redux_input_data)
#                     prop_key_chain = get_prop_key_chain(
#                         redux_input_data, target_attachment_key, main_tab_key,
#                         declaration_modality_key, shading_modality_key)
#                     if target_attachment_key == 'material_attached':
#                         top_level_prop_parent = material
#                     else: # if target_attachment_key == 'object_attached':
#                         top_level_prop_parent = obj__
#                     prop_parent, prop_key = ref_ob_key_pair(
#                         top_level_prop_parent, prop_key_chain)
#                     # To assign defaults to the props, We need the
#                     # default value in the ui_input_type, not in the
#                     # underlying_input_type, This is what the code
#                     # below tries to accomplish.
#                     # IT DOES NOT WORK IN ALL SITUATIONS, SOMETHING
#                     # SMARTER (OR DUMBER) NEEDS TO BE DEVELOPED !!!
#                     # if 'ui_to_underlying_val_mapping' in input_field_data.keys():
#                         # default_val = next(
#                         #     filter(lambda key_val: key_val[1] == default_val,
#                         #            [(key, json_decoded_value_parser['bool'][val]) for key, val in input_field_data[
#                         #                'ui_to_underlying_val_mapping'].items()]))[0]
#                     default_val = None
#                     if declaration_modality_key == 'synthetic':
#                         # for the synthetically defined inputs, the
#                         # ui_input_type and the underlying_input_type
#                         # are both the same. There is nothing else to
#                         # do to derive it.
#                         default_val = input_field_data['underlying_input_default_val']
#                     elif redux_input_data['ui_input_type'] == 'enum' and isinstance(
#                             input_field_data['ui_to_underlying_val_mapping'], dict):
#                         default_val = invert_dict_mapping(input_field_data['ui_to_underlying_val_mapping'])[
#                             input_field_data['underlying_input_default_val']]
#                         print('ui_default_val:', default_val, '; underlying_default_val:', input_field_data['underlying_input_default_val'])
#                     # else:
#                     #     print(f'\nNot Synthetic, input_name: {input_name}')
#                     #     print(input_field_data)
#                     #     print()
#                     #     default_val = input_field_data['underlying_input_default_val']
#                     if default_val:
#                         # We set the prop to have our default value be
#                         # visible in the ui too, not just in the
#                         # underlying input.
#                         set_prop_value(
#                             prop_parent, prop_key, default_val, redux_input_data['ui_input_type'])
#                         if target_attachment_key == 'material_attached':
#                             # We set the underlying input in conformity
#                             # with the value we set in the property.
#                             # There is no need to pass a value to the
#                             # function, it shall be taken from the prop.
#                             set_material_attached_input__at_setup(
#                                 prop_parent, input_name,
#                                 obj__, redux_input_data, material
#                             )
#                         else: # target_attachment_key == 'object_attached':
#                             # Same here
#                             set_geonode_mod_input__at_prop_update(
#                                 obj__, prop_parent, input_name, redux_input_data,
#                                 target_attachment_key, shading_modality_key)
#                         ## ------------------------------------------------------------
#                         # prop_parent, prop_key = ref_input_field_property(
#                         #     obj__, shading_modality_key, library_key, material_name,
#                         #     target_type_name, group_name, input_name)
#                         # set_input__from_data(
#                         #     prop_parent, input_name,
#                         #     {
#                         #         'library': library_key,
#                         #         'material/func_name': material_name,
#                         #         'target_type': target_type_name,
#                         #         'group_name': group_name
#                         #     },
#                         #     input_field_data,
#                         #     shading_modality_key,
#                         #     obj=obj__, material=material)
#                 # if input_field_data['type'] == 'imgtex':
#                 #     # No need to set defaults in the case of image texture properties
#                 #     pass
#                 # else:
#                 #     prop_parent, prop_key = ref_input_field_property(
#                 #         obj__, shading_modality_key, library_key, material_name, target_type_name, group_name, input_name)
#                 #     set_input__from_data(
#                 #         prop_parent, input_name,
#                 #         {
#                 #             'library': library_key,
#                 #             'material/func_name': material_name,
#                 #             'target_type': target_type_name,
#                 #             'group_name': group_name
#                 #         },
#                 #         input_field_data,
#                 #         shading_modality_key,
#                 #         obj=obj__, material=material)
#     # # For the new system (execd):
#     # # object_attached_prop_hierarchy_karte !!!
#     # material_attached_prop_hierarchy_karte
#     # prop_root = 
 
def clear_previous_material(shading_modality_key, obj__):
    # print(f'clear_previous_material({shading_modality_key}, obj__:{obj__.name})')
    # ID Property tagged data is used to the material name and the
    # library key of the material setup. The same information could be
    # obtained more expensively by analyzing the object (it's material
    # and it's modifier stack) and comparing them with the relevant
    # material data structures, but so far this approach seems
    # sufficient.
    if does_dict_have_key_path(obj__,
                               ['liquifeel', f'{shading_modality_key}_shading', 'library']):
        # print('we can remove modifiers')
        prev_mat_library = obj__['liquifeel'][f'{shading_modality_key}_shading']['library']
        prev_material_name = obj__['liquifeel'][f'{shading_modality_key}_shading']['material_name']
        if shading_modality_key == 'slot':
            obj__.data.materials.clear() # make room for the new material
            # remove the previous lqfl material modifiers (if any)
        remove_material_auxiliary_modifiers(
            obj__, prev_mat_library, prev_material_name)

@undo_push(4)
def slot_shade(context, obj__, library_key, material_name):
    # print('slot_shade(context, obj__, library_key, material_name)')
    # print(f'slot_shade(context, {obj__}, {library_key}, {material_name})')
    shading_modality_key = 'slot'
    adjust_render_settings(context)
    if 'liquifeel' not in obj__.keys():
        obj__['liquifeel'] = {}
    # CLEAN THE SLATE
    clear_previous_material(shading_modality_key, obj__)
    # OBJECT TAGGING
    obj__['liquifeel']['slot_shading'] = {
        'library': library_key,
        'material_name': material_name
    }
    # PATTERN PREREQUISITES:
    # solids (so far only UberGlass) have patterns and the pattern is dependent on discrimination between
    # the interior and the exterior of the glass.
    if library_key == 'solids':
        assign_select_outer_geonode_mod(obj__)
    # ASSIGN THE NEW MATERIAL
    if library_key == 'scene':
        material = bpy.data.materials[material_name]
        set_asset_material(obj__, material, shading_modality_key)
        # set_asset_material(obj__, material, shading_modality_key=shading_modality_key)
        # assign_material(obj__, material)
    else:
        material = get_material(library_key, material_name)
        # material = get_material(library_key, material_name).copy()
        set_asset_material(obj__, material, shading_modality_key)
        # set_asset_material(obj__, material, shading_modality_key=shading_modality_key)
        # assign_material(obj__, material)
        maybe_install_material_auxiliary_modifiers(obj__, library_key, material_name, shading_modality_key)
        # ASSIGN RECIPIENT PATTERN (somewhere within this block) !!!
        if library_key == 'solids' and 'Uber Glass' in material_name:
            prop_key_chain = ['liquifeel_input_field_props', shading_modality_key, 'manual']
            img_key = getattr_rec(
                material, prop_key_chain + ['pattern_texture'])
            # img_key = getattr_rec__by_names(
            #     material, shading_modality_key, library_key, material_name, 'Shader Node',
            #     'PatternImage_UV; PatternImage_Box',
            #     'Pattern Texture')
            res_key = getattr_rec(
                material, prop_key_chain + ['pattern_texture_resolution'])
            # res_key = getattr_rec__by_names(
            #     material, shading_modality_key, library_key, material_name, 'Shader Node',
            #     'PatternImage_UV; PatternImage_Box',
            #     'Pattern Texture Resolution')
            # print('-- pattern', 'img_key:', img_key, 'res_key:', res_key)
            node_names = 'PatternImage_UV; PatternImage_Box'
            nodes = [get_material_node(material, node_name.strip()) for node_name in node_names.split(';')]
            # print(f"img_tex_fpath = FPATHS['recipient_pattern_textures'][{img_key}][{res_key}]")
            img_tex_fpath = FPATHS['recipient_pattern_textures'][img_key][res_key]
            img = maybe_load_image(img_tex_fpath)
            assign_pattern(obj__, nodes, img, img_tex_fpath)
        # SET DEFAULT VALUES TO THE TARGET INPUTS (the intermediate
        # properties have them already set)
        assign_default_values_to_target_inputs(
            obj__, material, shading_modality_key, library_key, material_name)

class ShadeActiveObjectViaSlot(bpy.types.Operator):
    bl_idname = 'liquifeel.shade_active_object_via_slot'
    bl_label = 'Shade Active Object Via Slot'
    def execute(self, context):
        obj__ = context.active_object
        library_key, material_name = get_library_key_and_material_name(
            obj__, shading_modality_key='slot')
        # library_key = getattr(obj__.liquifeel_field_inputs.slot_shading, 'library')
        # material_name = getattr(obj__.liquifeel_field_inputs.slot_shading, f'library_{library_key}_material')
        slot_shade(context, obj__, library_key, material_name)
        return {'FINISHED'}
registerable_classes.append(ShadeActiveObjectViaSlot)

# # This is not a priority, though it would be quite nice to have.
# class LinkSlotMaterialsFromActive(bpy.types.Operator):
#     bl_idname = f'liquifeel.link_slot_materials_from_active'
#     bl_label = 'Link Slot Materials From Active'
#     def execute(self, context):
#         active_obj = context.active_object
#         selected_objs = filter(lambda obj: not(obj == active_obj),
#                                context.selected_objects)
#         material = get_asset_material(active_obj, 'slot')

def make_active_asset_material_single_user(context, shading_modality_key):
    obj__ = context.active_object
    og_material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
    mat = og_material.copy()
    set_asset_material(obj__, mat, shading_modality_key)
    update_obj_render_view(context, obj__)
    return mat

# This not currently a priority either, but it is more so than
# Linking from active
class MakeSlotMaterialSingleUser(bpy.types.Operator):
    bl_idname = 'liquifeel.make_slot_material_single_user'
    bl_label = 'Make Slot Material Single User'
    def execute(self, context):
        make_active_asset_material_single_user(context, 'slot')
        return {'FINISHED'}
registerable_classes.append(MakeSlotMaterialSingleUser)

# We want to be able to duplicate an asset and sepparate it's material
# while maintaining the values in the asset properties.
class MakeFillMaterialSingleUser(bpy.types.Operator):
    bl_idname = 'liquifeel.make_fill_material_single_user'
    bl_label = 'Make Fill Material Single User'
    def execute(self, context):
        make_active_asset_material_single_user(context, 'fill')
        # make_active_asset_fill_material_single_user(context)
        return {'FINISHED'}
registerable_classes.append(MakeFillMaterialSingleUser)

## UI --------------------------------------------------------------------------------

## UI DRAWING ---------------------

def draw_drop_dwn__by_redux_data(
        root_layout, text,
        prop_root, prop_key_chain):
    # print()
    # print(f'''draw_drop_dwn__by_redux_data(
    #     root_layout, {text},
    #     {prop_root}, {prop_key_chain}):''')
    # print()
    row = root_layout.row()
    split_row = row.split(
        factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
    split_row.label(text=text)
    split_row.prop(
        *ref_ob_key_pair(
            prop_root, prop_key_chain),
        text='')

# obsolete, shall be removed in the future. we have a new system (execd).
def draw_drop_down__extgen(
        root_layout, text,
        obj__, shading_modality_key, library_key, mat_name, target_type, group_name, input_name,
        prop_key=None):
    row = root_layout.row()
    split_row = row.split(
        factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
    split_row.label(text=text)
    split_row.prop(
        *ref_input_field_property(
            obj__, shading_modality_key, library_key, mat_name, target_type, group_name, input_name,
            prop_key=prop_key),
        text='')

def draw_drop_down__execd(
        root_layout, text, top_level_prop_parent, prop_key_chain):
    row = root_layout.row()
    split_row = row.split(
        factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
    split_row.label(text=text)
    split_row.prop(
        *ref_ob_key_pair(
            top_level_prop_parent, prop_key_chain),
        text='')

def draw_spacing(root_layout):
    spacing_row = root_layout.row()
    spacing_row.scale_y = SPACING_H
    spacing_row.label(text='')

def draw_navigation_and_feedback(context, root_layout):
    tab_row = root_layout.row()
    tab_row.prop(
        context.scene.liquifeel_general_controls, 'main_tabs',
        expand=True, icon_only=False)
    # tab_cycle_row = root_layout.row()
    # split = tab_cycle_row.split(factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
    # feedback_row = split.row()
    # # # DEACTIVATED FOR LACK OF URLS
    # # feedback_row.operator(
    # #     'liquifeel.launch_feedback_form',
    # #     text='',
    # #     icon_value=preview_data['ids']['icons']['like'],
    # # )
    # # feedback_row.operator(
    # #     'liquifeel.launch_feedback_form',
    # #     text='',
    # #     icon_value=preview_data['ids']['icons']['dislike']
    # # )
    # split.operator(
    #     'liquifeel.cycle_tabs',
    #     text=MAIN_TAB_NAMES[getattr(context.scene.liquifeel_general_controls, 'main_tabs')])
    draw_spacing(root_layout)

# def draw_navigation_and_feedback(context, root_layout):
#     tab_row = root_layout.row()
#     tab_row.label(
#         text='Feeling it?')
#     tab_row.prop(
#         context.scene.liquifeel_general_controls, 'main_tabs',
#         expand=True, icon_only=True)
#     tab_cycle_row = root_layout.row()
#     split = tab_cycle_row.split(factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
#     feedback_row = split.row()
#     # # DEACTIVATED FOR LACK OF URLS
#     # feedback_row.operator(
#     #     'liquifeel.launch_feedback_form',
#     #     text='',
#     #     icon_value=preview_data['ids']['icons']['like'],
#     # )
#     # feedback_row.operator(
#     #     'liquifeel.launch_feedback_form',
#     #     text='',
#     #     icon_value=preview_data['ids']['icons']['dislike']
#     # )
#     split.operator(
#         'liquifeel.cycle_tabs',
#         text=MAIN_TAB_NAMES[getattr(context.scene.liquifeel_general_controls, 'main_tabs')])
#     draw_spacing(root_layout)


def draw_discord_launcher(context, root_layout):
    documentation_row = root_layout.row()
    documentation_row.scale_y = SML_H
    documentation_row.operator(
        'liquifeel.launch_discord',
        text='Join Liquifeel Discord',
        icon_value=preview_data['ids']['icons']['discord'],
        emboss=True,
    )
    # draw_spacing(root_layout)

def draw_documentation_launchers(context, root_layout):
    documentation_row = root_layout.row()
    documentation_row.scale_y = SML_H
    documentation_row.operator(
        'liquifeel.launch_website',
        text='Documentation',
        icon_value=preview_data['ids']['icons']['documentation'],
        emboss=True,
    )
    # draw_spacing(root_layout)

# # DEACTIVATED FOR LACK OF URLS
# def draw_documentation_launchers(context, root_layout):
#     documentation_row = root_layout.row()
#     documentation_row.scale_y = SML_H
#     documentation_row.operator(
#         'liquifeel.launch_guide',
#         text='guide',
#         icon_value=preview_data['ids']['icons']['youtube'],
#     )
#     documentation_row.operator(
#         'liquifeel.launch_gallery',
#         text='gallery',
#         icon_value=preview_data['ids']['icons']['gallery'],
#     )
#     draw_spacing(root_layout)

def draw_filled_geometry_ui(context, root_layout):
    obj__ = context.active_object
    box = root_layout.box()
    manual_prop_parent = obj__.liquifeel_input_field_props.geometry.manual
    synthetic_prop_parent = obj__.liquifeel_input_field_props.geometry.synthetic
    box.prop(manual_prop_parent, 'opening_shape')
    lip_threshold_row = box.row()
    if getattr(manual_prop_parent, 'opening_shape') == 'irregular':
        lip_threshold_row.prop(synthetic_prop_parent, 'lip_threshold')
    box.prop(synthetic_prop_parent, 'liquid_amount')
    box.prop(synthetic_prop_parent, 'seal_container')
    draw_hide_controls(obj__, box)

# def draw_filled_geometry_ui(context, root_layout):
#     obj__ = context.active_object
#     box = root_layout.box()
#     box.prop(obj__.liquifeel_field_inputs.fill, 'opening_shape')
#     lip_threshold_row = box.row()
#     if getattr(obj__.liquifeel_field_inputs.fill, 'opening_shape') == 'irregular':
#         lip_threshold_row.prop(obj__.liquifeel_field_inputs.fill, 'lip_threshold')
#     box.prop(obj__.liquifeel_field_inputs.fill, 'liquid_amount')
#     box.prop(obj__.liquifeel_field_inputs.fill, 'seal_container')
#     draw_hide_controls(obj__, box)
#     # draw_spacing(root_layout)

def draw_geometry_ui(context, root_layout):
    if is_active_selected_ob(context):
        obj__ = context.active_object
        if obj__.mode == 'OBJECT':
            if is_obj_filled(obj__):
                draw_filled_geometry_ui(context, root_layout)
            else:
                fill_it_row = root_layout.row()
                fill_it_row.scale_y = LRG_H
                fill_it_row.operator(
                    'liquifeel.fill_active_object',
                    text='Fill active',
                    icon_value=preview_data['ids']['icons']['geometry'],
                )
        else:
            root_layout.label(text='Please enter Object Mode.')
    else:
        root_layout.label(
            text='Please select an object that has one mesh island!')

def draw_imgtex_input(
        root_layout, top_level_prop_parent, redux_input_data, prop_key_chain):
    prop_parent_key_chain = prop_key_chain[:-1]
    # The variables extracted below are most probably these:
    # ['pattern_texture', 'pattern_texture_resolution', 'pattern_library', 'user_pattern_texture']
    img_prop_key, res_prop_key, lib_prop_key, user_img_prop_key = redux_input_data['prop_key']
    lib_key = getattr_rec(
        top_level_prop_parent, prop_parent_key_chain + [lib_prop_key])
    draw_drop_dwn__by_redux_data(
        root_layout, 'Library', top_level_prop_parent, prop_parent_key_chain + [lib_prop_key])
    pattern_selector_prop_key = user_img_prop_key if lib_key == 'user_defined' else img_prop_key
    # We draw the template icon view only if we are outside of the
    # case in which user defined pattern mode is selected and none are
    # present.
    if not(lib_key == 'user_defined' and not(are_user_defined_patterns_present())):
        root_layout.template_icon_view(
            *ref_ob_key_pair(
                top_level_prop_parent, prop_parent_key_chain + [pattern_selector_prop_key]),
            show_labels=True, scale=UI_THUMB_SCALE, scale_popup=POPUP_THUMB_SCALE)
    # Then we decide if we display the resoluton selector or not. If
    # we are in user defined mode, we don't need it.
    if not(lib_key == 'user_defined'):
        root_layout.prop(
            *ref_ob_key_pair(
                top_level_prop_parent, prop_parent_key_chain + [res_prop_key]))
    # If we are in user defined mode, we need to be able to load new
    # patterns though. hence the operator provided below.
    else:
        root_layout.operator('liquifeel.load_user_defined_pattern', text='Load custom pattern image')

def draw_input__extgen(
        shading_modality_key,
        obj__, library_key, mat_name, target_type, group_name, input_name, input_data, root_layout):
    if input_data['type'] == 'imgtex':
        draw_imgtex_input(
            shading_modality_key,
            obj__,
            library_key, mat_name, target_type, group_name, input_name, input_data,
            root_layout)
    elif 'ui_to_underlying_val_mapping' in input_data.keys(): # aka if the underlying prop is of EnumProperty type.
        draw_drop_down__extgen(
            root_layout, input_name,
            obj__, shading_modality_key, library_key, mat_name, target_type, group_name, input_name)
    else:
        slider = input_data['type'] == 'float'
        root_layout.prop(
            *ref_input_field_property(
                obj__, shading_modality_key, library_key, mat_name, target_type, group_name, input_name),
            slider=False)
        # root_layout.prop(
        #     *ref_input_field_property(
        #         obj__, shading_modality_key, library_key, mat_name, target_type, group_name, input_name),
        #     slider=slider)

def get_prop_key_chain(
        redux_input_data, target_attachment_key, main_tab_key,
        declaration_modality_key, shading_modality_key):
    # The two property hierarchies (material attached and object
    # attached) do not have the same structure. In obtaining the
    # property hierarchy key chain (path) i'm taking advantaage of
    # their sole difference. This is a brittle piece of code, if we
    # changed the hierarchy structure, it would cease to work.
    prop_key = redux_input_data['prop_key']
    if target_attachment_key == 'material_attached':
        return [
            'liquifeel_input_field_props',
            shading_modality_key, declaration_modality_key, prop_key]
    elif target_attachment_key == 'object_attached':
        if main_tab_key == 'geometry':
            return [
                'liquifeel_input_field_props',
                main_tab_key, declaration_modality_key, prop_key]
        elif main_tab_key == 'shading':
            return [
                'liquifeel_input_field_props',
                main_tab_key, shading_modality_key, declaration_modality_key, prop_key]

# def get_prop_key_chain(
#         redux_input_data, target_attachment_key, main_tab_key,
#         declaration_modality_key, shading_modality_key):
#     # The two property hierarchies (material attached and object
#     # attached) do not have the same structure. In obtaining the
#     # property hierarchy key chain (path) i'm taking advantaage of
#     # their sole difference. This is a brittle piece of code, if we
#     # changed the hierarchy structure, it would cease to work.
#     if target_attachment_key == 'material_attached':
#         hierarchy_inconsistent_key = shading_modality_key
#     else: # target_attachment_key == 'object_attached':
#         hierarchy_inconsistent_key = main_tab_key
#     prop_key_chain = [
#         'liquifeel_input_field_props',
#         hierarchy_inconsistent_key, declaration_modality_key,
#         redux_input_data['prop_key']]
#     return prop_key_chain

def get_prop_key_chain__from_dep_data(dep_data, main_tab_key, shading_modality_key):
    target_attachment_key = get_target_attachment_key[dep_data['target_type']]
    ui_input_name = dep_data['input_name']
    redux_input_data = REDUX_INPUT_DATA[
        main_tab_key][target_attachment_key][ui_input_name]
    declaration_modality_key = get_declaration_modality_key(redux_input_data)
    prop_key_chain = get_prop_key_chain(
        redux_input_data, target_attachment_key, main_tab_key,
        declaration_modality_key, shading_modality_key)
    return prop_key_chain

def draw_input__execd(
        root_layout, top_level_prop_parent, redux_input_data, field_input_data, prop_key_chain):
    if redux_input_data['underlying_input_type'] == 'imgtex':
        draw_imgtex_input(
            root_layout, top_level_prop_parent, redux_input_data, prop_key_chain)
    elif 'ui_to_underlying_val_mapping' in input_data.keys(): # aka if the underlying prop is of EnumProperty type.
        draw_drop_down__execd(
            root_layout, redux_input_data['ui_input_name'],
            top_level_prop_parent, prop_key_chain)
    else:
        slider = redux_input_data['underlying_input_type'] == 'float'
        root_layout.prop(
            *ref_ob_key_pair(
                top_level_prop_parent, prop_key_chain),
            slider=False)
        # root_layout.prop(
        #     *ref_ob_key_pair(
        #         top_level_prop_parent, prop_key_chain),
        #     slider=slider)

def satisfies_simple_draw_dependency(
        obj__, material, prop_key_chain, dep_data, main_tab_key,
        shading_modality_key=None):
    dep_target_attachment_key = get_target_attachment_key[dep_data['target_type']]
    if dep_target_attachment_key == 'object_attached':
        dep_top_level_prop_parent = obj__
    else: # dep_target_attachment_key == 'material_attached':
        dep_top_level_prop_parent = material
    dep_prop_key_chain = get_prop_key_chain__from_dep_data(
        dep_data, main_tab_key, shading_modality_key)
    dep_val = getattr_rec(dep_top_level_prop_parent, dep_prop_key_chain)
    if 'eqv' in dep_data.keys():
        dep_val = dep_val == dep_data['eqv']
    return dep_val

def satisfies_draw_dependency(
        obj__, material, prop_key_chain, dep_data,
        main_tab_key,
        shading_modality_key=None):
    if isinstance(dep_data, list):
        dep_vals = list(
            map(
                lambda dep_data__: satisfies_simple_draw_dependency(
                    obj__, material, prop_key_chain, dep_data__,
                    main_tab_key,
                    shading_modality_key=shading_modality_key),
                dep_data))
        return all(dep_vals)
    else:
        dep_val = satisfies_simple_draw_dependency(
            obj__, material, prop_key_chain, dep_data,
            main_tab_key,
            shading_modality_key=shading_modality_key)
        return dep_val

def maybe_draw_input(
        root_layout, obj__, redux_input_data, field_input_data, prop_key_chain,
        main_tab_key, target_attachment_key, shading_modality_key=None):
    material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
    if target_attachment_key == 'material_attached':
        top_level_prop_parent = material
    else:
        top_level_prop_parent = obj__
    if 'dependency' in field_input_data.keys():
        dep_data = field_input_data['dependency']
        dep_val = satisfies_draw_dependency(
            obj__, material, prop_key_chain, dep_data,
            main_tab_key,
            shading_modality_key=shading_modality_key)
        if dep_val:
            draw_input__execd(
                root_layout, top_level_prop_parent, redux_input_data, field_input_data, prop_key_chain)
    else:
        draw_input__execd(
            root_layout, top_level_prop_parent, redux_input_data, field_input_data, prop_key_chain)

pattern_ui_input_order = [
    'Pattern',
    'Pattern Texture; Pattern Texture Resolution; Pattern Library; User Pattern Texture',
    'Mapping',
    'UV Name',
    'Use Vertex Group',
    'Vertex Group',
    'Lip Threshold',
    'Patttern Extrusion',
    'Upper Limit',
    'Lower Limit',
    'Pattern Falloff',
    'Pattern Tiling'
]
outside_pattern_ui_input_order = len(pattern_ui_input_order) + 1
def pattern_ui_input_order_sorting_metric(extended_input_data):
    ui_input_name = extended_input_data['input_key']
    if ui_input_name in pattern_ui_input_order:
        return pattern_ui_input_order.index(ui_input_name)
    else:
        return outside_pattern_ui_input_order

def draw_shader_controls(shading_modality_key, obj__, library_key, mat_name, root_layout):
    main_tab_key = 'shading'
    for sorting_tag, inputs_data in SHADING_INPUT_FIELD_DATA_BY_SORTING_TAG[
            library_key][mat_name].items():
        box = root_layout.box()
        box.label(text=sorting_tag)
        if sorting_tag == 'pattern':
            inputs_data = sorted(inputs_data, key=pattern_ui_input_order_sorting_metric)
        for extended_input_data in inputs_data:
            field_input_data = extended_input_data['input_data']
            target_attachment_key = get_target_attachment_key[
                extended_input_data['target_type']]
            ui_input_name = extended_input_data['input_key']
            redux_input_data = REDUX_INPUT_DATA[
                main_tab_key][target_attachment_key][ui_input_name]
            declaration_modality_key = get_declaration_modality_key(redux_input_data)
            prop_key_chain = get_prop_key_chain(
                redux_input_data, target_attachment_key, main_tab_key,
                declaration_modality_key, shading_modality_key)
            maybe_draw_input(
                box, obj__, redux_input_data, field_input_data, prop_key_chain,
                main_tab_key, target_attachment_key, shading_modality_key=shading_modality_key)

def draw_material_link_controls(obj__, context, root_layout, shading_modality_key):
    row = root_layout.row()
    # We need to get the material and count the number of users to
    # display on the make single user button label.
    material = get_asset_material(obj__, shading_modality_key=shading_modality_key)
    split_row = row.split(
        factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
    # # This is not currently a priority...
    # split_row.operator(
    #     f'liquifeel.link_{shading_modality_key}_materials_from_active',
    #     text='Link from Active')
    split_row.label(text='Make single user') # Will probably need to be taken out.
    split_row.operator(
        f'liquifeel.make_{shading_modality_key}_material_single_user',
        text=str(material.users))

def draw_library_selector(obj__, context, root_layout, shading_modality_key):
    row = root_layout.row()
    split = row.split(factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
    split.label(text='Library')
    prop_key_chain = [
        'liquifeel_input_field_props',
        'shading', shading_modality_key, 'manual', 'material_selector', 'library']
    # prop_key_chain = [
    #     'liquifeel_input_field_props', 'shading', 'manual',
    #     f'{shading_modality_key}_material_selector', 'library']
    prop_parent, prop_key = ref_ob_key_pair(obj__, prop_key_chain)
    split.prop(prop_parent, prop_key, text='')

def draw_hide_controls(obj__, root_layout):
    prop_parent = obj__.liquifeel_input_field_props.geometry.manual
    hide_recipient_row = root_layout.row()
    hide_recipient_row.enabled = not(
        getattr(prop_parent, 'hide_liquid'))
    hide_liquid_row = root_layout.row()
    hide_liquid_row.enabled = not(
        getattr(prop_parent, 'hide_recipient'))
    hide_recipient_row.prop(
        prop_parent, 'hide_recipient')
    hide_liquid_row.prop(
        prop_parent, 'hide_liquid')

def draw_scene_shading_ui(obj__, shading_modality_key, context, root_layout):
    draw_library_selector(obj__, context, root_layout, shading_modality_key)
    row = root_layout.row()
    split_row = row.split(
        factor=LEFT_JUSTIFIED_BUTTON_SPLIT_FACTOR)
    split_row.label(text='Scene materials:')
    prop_key_chain = [
        'liquifeel_input_field_props', 'shading', shading_modality_key,
        'manual', 'material_selector', 'scene_material']
    # prop_key_chain = [
    #     'liquifeel_input_field_props', 'shading', 'manual',
    #     f'{shading_modality_key}_material_selector', 'scene_material']
    prop_parent, prop_key = ref_ob_key_pair(
        obj__, prop_key_chain)
    # prop_parent, prop_key = ref_ob_key_pair(obj__,
    #                                         [
    #                                             'liquifeel_field_inputs',
    #                                             f'{shading_modality_key}_shading',
    #                                             f'scene_material'])
    split_row.prop(
        prop_parent, prop_key, text='')
    if is_obj_filled(obj__):
        draw_hide_controls(obj__, root_layout)
        root_layout.prop(
            obj__.liquifeel_input_field_props.geometry.synthetic, 'liquid_amount')

def draw_shading_ui__(shading_modality_key, context, root_layout):
    obj__ = context.active_object
    library_key, mat_name = get_library_key_and_material_name(
        obj__, shading_modality_key=shading_modality_key)
    # library_key = getattr_rec(obj__,
    #                           [
    #                               'liquifeel_field_inputs',
    #                               f'{shading_modality_key}_shading',
    #                               'library'])
    # if is_obj_library_shaded(obj__, library_key, shading_modality_key):
    if is_obj_liquifeel_asset(obj__) and is_obj_library_shaded(
            obj__, library_key, shading_modality_key):
        obj__ = context.active_object
        # if shading_modality_key == 'fill': # So far, we do want to implement this for slot too though.
        draw_material_link_controls(obj__, context, root_layout, shading_modality_key)
        draw_library_selector(obj__, context, root_layout, shading_modality_key)
        material_picker_box = root_layout.box()
        prop_key_chain = [
            'liquifeel_input_field_props',
            'shading', shading_modality_key, 'manual', 'material_selector', f'{library_key}_material']
        # prop_key_chain = [
        #     'liquifeel_input_field_props', 'shading', 'manual',
        #     f'{shading_modality_key}_material_selector', f'{library_key}_material']
        prop_parent, prop_key = ref_ob_key_pair(
            obj__, prop_key_chain)
        material_picker_box.template_icon_view(
            prop_parent, prop_key,
            # *ref_ob_key_pair(obj__,
            #                  [
            #                      'liquifeel_field_inputs',
            #                      f'{shading_modality_key}_shading',
            #                      f'library_{library_key}_material']),
            show_labels=True, scale=UI_THUMB_SCALE, scale_popup=POPUP_THUMB_SCALE)
        # mat_name = getattr_rec(obj__,
        #                        [
        #                            'liquifeel_field_inputs',
        #                            f'{shading_modality_key}_shading',
        #                            f'library_{library_key}_material'])
        material_picker_box.label(
            text=mat_name)
        root_layout.operator(
            f'liquifeel.update_render_view',
            text='Update Render View',
        )
        if is_obj_filled(obj__):
            draw_hide_controls(obj__, root_layout)
            root_layout.prop(obj__.liquifeel_input_field_props.geometry.synthetic, 'liquid_amount')
        draw_shader_controls(shading_modality_key, obj__, library_key, mat_name, root_layout)
    elif library_key == 'scene':
        draw_scene_shading_ui(obj__, shading_modality_key, context, root_layout)
    else:
        draw_library_selector(obj__, context, root_layout, shading_modality_key)
        shade_it_row = root_layout.row()
        shade_it_row.scale_y = LRG_H
        shade_it_row.operator(
            f'liquifeel.shade_active_object_via_{shading_modality_key}',
            text='Shade active',
            icon=MAIN_TAB_BUILTIN_ICONS['shading'],
        )
    # draw_spacing(root_layout)

def draw_slot_shading_ui(context, root_layout):
    draw_shading_ui__('slot', context, root_layout)

def draw_shading_target_selector(obj__, context, root_layout):
    recipient_vs_liquid_tab_row = root_layout.row()
    recipient_vs_liquid_tab_row.scale_y = MID_H
    general_ctrl__ = context.scene.liquifeel_general_controls
    recipient_vs_liquid_tab_row.prop(
        general_ctrl__, 'shading_target', expand=True)
    draw_spacing(root_layout)

def draw_fill_liquid_shading_ui(context, root_layout):
    draw_shading_ui__('fill', context, root_layout)    

def draw_fill_shading_ui(context, root_layout):
    obj__ = context.active_object
    draw_shading_target_selector(obj__, context, root_layout) # recipient or liquid
    general_ctrl__ = context.scene.liquifeel_general_controls
    if getattr(general_ctrl__, 'shading_target') == 'recipient':
        draw_slot_shading_ui(context, root_layout)
    elif getattr(general_ctrl__, 'shading_target') == 'liquid':
        draw_fill_liquid_shading_ui(context, root_layout)
    # draw_spacing(root_layout)

def draw_shading_ui(context, root_layout):
    if is_active_selected_ob(context):
        obj__ = context.active_object
        if is_obj_filled(obj__):
            draw_fill_shading_ui(context, root_layout)
        else:
            draw_slot_shading_ui(context, root_layout)
    else:
        root_layout.label(
            text='Please select an object to shade.')
        # draw_spacing(root_layout)

# # Not implemented yet
# def draw_effects_ui(context, root_layout):
#     if is_active_selected_ob(context):
#         pass
#     else:
#         root_layout.label(
#             text='Please select an object to apply effects to.')
#         draw_spacing(root_layout)

def draw_recipients_ui(context, root_layout):
    root_layout.template_icon_view(
        context.scene.liquifeel_general_controls, 'recipient_asset',
        show_labels=True, scale=UI_THUMB_SCALE, scale_popup=POPUP_THUMB_SCALE)
    asset_key = getattr(context.scene.liquifeel_general_controls, 'recipient_asset')
    root_layout.label(
        text=RECIPIENT_ASSET_NAME_DATA[asset_key]['thumbnail'])
    add_asset_row = root_layout.row()
    add_asset_row.scale_y = MID_H
    add_asset_row.operator(
        'liquifeel.add_asset_to_3d_cursor',
        text='Add Asset To 3D Cursor',
        # icon=MAIN_TAB_BUILTIN_ICONS['shading'], # !!! icon?
    )
    # draw_spacing(root_layout)

main_tab_draw_fs = {
    'geometry': draw_geometry_ui,
    'shading': draw_shading_ui,
    # 'effects': draw_effects_ui, # Not implemented yet
    'recipients': draw_recipients_ui
}

def draw_clear_apply_ui(context, root_layout):
    apply_clear_row = root_layout.row()
    if is_active_selected_ob(context):
        obj__ = context.object
        if is_obj_liquifeel_asset(obj__) and obj__.mode == 'OBJECT':
            apply_clear_row.operator(
                'liquifeel.clear_asset',
                text='Clear',
            )
            apply_clear_row.operator(
                'liquifeel.apply_asset',
                text='Apply',
            )
            draw_spacing(root_layout)
    apply_clear_row.operator(
        'liquifeel.purge_unused_data', text='Clean up')

# def draw_clear_apply_ui(context, root_layout):
#     if is_active_selected_ob(context):
#         obj__ = context.object
#         if is_obj_liquifeel_asset(obj__) and obj__.mode == 'OBJECT':
#             apply_clear_row = root_layout.row()
#             apply_clear_row.operator(
#                 'liquifeel.clear_asset',
#                 text='Clear',
#             )
#             apply_clear_row.operator(
#                 'liquifeel.apply_asset',
#                 text='Apply',
#             )
#             draw_spacing(root_layout)

## PANEL ---------------------

def draw_main_panel(panel__, context):
    # # KEEP
    # panel__.layout.prop(
    #     context.scene.liquifeel_general_controls, 'performance_render_mode')
    draw_spacing(panel__.layout)
    draw_navigation_and_feedback(context, panel__.layout)
    main_tab_draw_fs[getattr(context.scene.liquifeel_general_controls, 'main_tabs')](context, panel__.layout)
    draw_spacing(panel__.layout)
    draw_clear_apply_ui(context, panel__.layout)
    draw_spacing(panel__.layout)
    # draw_discord_launcher(context, panel__.layout)
    draw_documentation_launchers(context, panel__.layout)

class MainPanel(bpy.types.Panel):
    bl_idname = 'OBJECT_PT_liquifeel_main_panel'
    bl_label = 'Liquifeel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Liquifeel'
    def draw_header(self, context):
        self.layout.label(
            text='',
            icon_value=preview_data['ids']['icons']['liquifeel_purple'])
    def draw(self, context):
        draw_main_panel(self, context)
registerable_classes.append(MainPanel)

def get_node_socket_data():
    print('================================================================')
    print('get_node_socket_data()')
    dat = {}
    for tab_key, tab_data in INPUT_FIELD_DATA.items():
        dat[tab_key] = {}
        for lib_key, lib_data in tab_data.items():
            dat[tab_key][lib_key] = {}
            for mat_name, mat_data in lib_data.items():
                dat[tab_key][lib_key][mat_name] = {}
                for target_key, target_data in mat_data.items():
                    dat[tab_key][lib_key][mat_name][target_key] = {}
                    for group_name, group_data in target_data.items():
                        dat[tab_key][lib_key][mat_name][target_key][group_name] = {}
                        for input_name, input_data in group_data.items():
                            # print('----------------------------------------------------------------')
                            # print(tab_key, lib_key, mat_name, target_key, group_name, input_name)
                            dat__ = {}
                            # if target_key == 'Shader NG':
                            if input_data['type'] in ['float', 'int']:
                                ng = index_stripped(bpy.data.node_groups, group_name)
                                input_ob = index_stripped(
                                    ng.interface.items_tree, input_data['underlying_input_name'])
                                if DEV:
                                    debug_buffer.append(input_ob)
                                if hasattr(input_ob, 'min_value') and hasattr(input_ob, 'max_value'):
                                    dat__['min'] = input_ob.min_value
                                    dat__['max'] = input_ob.max_value
                                    dat__['default_val'] = input_ob.default_value
                                    dat__['socket_type'] = input_ob.socket_type
                                # print(dat__)
                                # elif target_key == 'GeoNode':
                                dat[tab_key][lib_key][mat_name][target_key][group_name][input_name] = dat__
    with open(FPATHS['node_socket_data'], 'w') as f:
        json.dump(dat, f, indent=2)
    return dat

class GetBoundingData(bpy.types.Operator):
    bl_idname = 'liquifeel.get_node_socket_data'
    bl_label = 'Get Bounding Data'
    def execute(self, context):
        dat = get_node_socket_data()
        pprint(dat)
        return {'FINISHED'}
if DEV:
    registerable_classes.append(GetBoundingData)

class DevPanel(bpy.types.Panel):
    bl_idname = 'OBJECT_PT_dev_panel'
    bl_label = 'Liquifeel dev'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Liquifeel'
    def draw(self, context):
        self.layout.operator('liquifeel.get_node_socket_data')
if DEV:
    registerable_classes.append(DevPanel)

## REGISTRATION --------------------------------------------------------------------------------

def get_classes():
    return registerable_classes

if DEV:
    spec = importlib.util.spec_from_file_location(
        'repl',
        '/home/feral/.config/blender/4.0/scripts/addons/calculusrex_repl/__init__.py')
    repl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(repl)
    def repl_ns():
        return globals()
    dev_aux_registration = lambda: repl.register(ns=repl_ns)
    dev_aux_unregistration = lambda: repl.unregister()

def register():
    print()
    print('LIQUIFEEL: register()')
    classes_to_register = get_classes()
    for cls in classes_to_register:
        print('registering class:', cls)
        bpy.utils.register_class(cls)

    bpy.types.Scene.liquifeel_general_controls = bpy.props.PointerProperty(type=GeneralUIControls)
    bpy.types.Scene.liquifeel_misc_data = bpy.props.PointerProperty(type=MiscData)
    # bpy.types.Object.liquifeel_field_inputs = bpy.props.PointerProperty(type=FieldInputProps)
    bpy.types.Object.liquifeel_input_field_props = bpy.props.PointerProperty(
        type=ObjectAttached_InputProps)
    bpy.types.Material.liquifeel_input_field_props = bpy.props.PointerProperty(
        type=MaterialAttached_InputProps)

    if DEV:
        dev_aux_registration()
    translate.register()
    # # Animation
    # bpy.app.handlers.frame_change_post.append(animation_prop_update_handler)
    
def unregister():
    print()
    print('LIQUIFEEL: unregister()')
    classes_to_unregister = get_classes()
    for cls in classes_to_unregister:
        print('unregistering class:', cls)
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.liquifeel_general_controls
    del bpy.types.Scene.liquifeel_misc_data
    # del bpy.types.Object.liquifeel_field_inputs

    if DEV:
        dev_aux_unregistration()

    # # Animation
    # if animation_prop_update_handler in bpy.app.handlers.frame_change_post:
    #     bpy.app.handlers.frame_change_post.remove(animation_prop_update_handler)
    translate.unregister()
if __name__ == '__main__':
    register()
